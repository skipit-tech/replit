// js/stripe-background.js
// This file handles communication with Stripe services

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'createCheckoutSession') {
      const { planId, successUrl, cancelUrl } = message;
      
      // Using direct fetch instead of Firebase Functions for better extension compatibility
      fetch('https://your-firebase-function-url.cloudfunctions.net/createCheckoutSession', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          planId,
          successUrl,
          cancelUrl,
          userId: message.userId
        })
      })
      .then(response => response.json())
      .then(data => {
        sendResponse({ success: true, data });
      })
      .catch(error => {
        console.error('Error creating checkout session:', error);
        sendResponse({ success: false, error: error.message });
      });
      
      return true; // Important: indicates we'll respond asynchronously
    }
    
    if (message.action === 'verifyPayment') {
      // Similar fetch to verify payment with your backend
      return true;
    }
  });