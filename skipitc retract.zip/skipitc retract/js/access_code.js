// Function to initialize access codes
function initializeAccessCodes() {
    // Pre-generated list of access codes (randomly generated)
    const initialCodes = [
        "skipittestzD8kFpA2", "skipittestXeB7nM5q", "skipittesttR9jGcY3", "skipittesthK6vLpZ8", "skipittestbS4wPmN2",
        "skipittestgF5jKrT9", "skipittestpQ3xV7dH", "skipittestyZ8sW2mB", "skipittestnC6tF4xR", "skipittestaL7vD3jK",
        "skipittesterR9bN5mP", "skipittestcX6tY8zA", "skipittestwH3pM7jF", "skipittestuQ9vB5nG", "skipittestfS2xD6kR",
        "skipittestjL4zH7tP", "skipittestmV9bN3qS", "skipittestkT6dR8xZ", "skipittestsF3jL5yH", "skipittestdP7gB2nM",
        "skipittestvC8mT4qR", "skipittestrH5pX9zL", "skipittestqW2jK6bN", "skipittestoA9tF3xZ", "skipittestiY5vD7mS",
        "skipittestlX3cB8nP", "skipittestxJ6fM2tR", "skipittestoP9sD4yH", "skipittestuT7mN3wL", "skipittestiK5bZ8qF",
        "skipittestgH2vP6jS", "skipittestdX9cM4tB", "skipittestaF3kR7nZ", "skipittestsJ5vL2xP", "skipittestqN7bM3wR",
        "skipittestoY4hC9tF", "skipittestiD6gK3xZ", "skipittesteB8vN5jL", "skipittestwR2sP7mQ", "skipittestuT5dF9yH"
      ];
      
    
    const metadata = {};
    const timestamp = new Date().toISOString();
    
    // Add metadata for each code
    initialCodes.forEach(code => {
      metadata[code] = {
        created: timestamp,
        used: false
      };
    });
    
    // Save to storage
    chrome.storage.local.set({
      validAccessCodes: initialCodes,
      accessCodeMetadata: metadata
    }, () => {
      console.log('Access codes initialized');
    });
  }