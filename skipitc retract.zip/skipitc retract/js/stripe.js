const functions = require('firebase-functions');
const admin = require('firebase-admin');
const stripe = require('stripe')('your_stripe_secret_key');

admin.initializeApp();

exports.createCheckoutSession = functions.https.onCall(async (data, context) => {
  // Ensure user is authenticated
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'User must be logged in');
  }

  const userId = context.auth.uid;
  
  // Create a Stripe checkout session
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    line_items: [{
      price: data.priceId, // Stripe Price ID for subscription
      quantity: 1,
    }],
    mode: 'subscription',
    success_url: data.successUrl,
    cancel_url: data.cancelUrl,
    client_reference_id: userId,
    metadata: {
      userId: userId
    }
  });

  return { id: session.id };
});