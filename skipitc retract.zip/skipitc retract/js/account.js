document.addEventListener('DOMContentLoaded', () => {
    const goldUpgradeButton = document.querySelector('.upgrade-gold');

    const toggleSubscription = (isUpgraded) => {
        const goldPlanSubscribedLabel = document.querySelector('.gold-plan .subscribed-label');
        const freePlanSubscribedLabel = document.querySelector('.free-plan .subscribed-label');

        if (isUpgraded) {
            // User upgraded to Gold
            goldUpgradeButton.textContent = 'Cancel';
            goldUpgradeButton.classList.remove('upgrade-button');
            goldUpgradeButton.classList.add('cancel-button');

            if (freePlanSubscribedLabel) {
                freePlanSubscribedLabel.style.display = 'none'; // Hide the label in the free plan
            }

            if (goldPlanSubscribedLabel) {
                goldPlanSubscribedLabel.style.display = 'block'; // Show the label in the gold plan
            }

            chrome.storage.sync.set({ isGoldUpgraded: true }); // Store upgrade status
        } else {
            // User canceled Gold subscription
            goldUpgradeButton.textContent = 'Upgrade';
            goldUpgradeButton.classList.remove('cancel-button');
            goldUpgradeButton.classList.add('upgrade-button');

            if (goldPlanSubscribedLabel) {
                goldPlanSubscribedLabel.style.display = 'none'; // Hide the label in the gold plan
            }

            if (freePlanSubscribedLabel) {
                freePlanSubscribedLabel.style.display = 'block'; // Show the label in the free plan
            }

            chrome.storage.sync.set({ isGoldUpgraded: false }); // Reset upgrade status
        }
    };

    goldUpgradeButton.addEventListener('click', () => {
        chrome.storage.sync.get('isGoldUpgraded', (data) => {
            const isGoldUpgraded = data.isGoldUpgraded;
            toggleSubscription(!isGoldUpgraded); // Toggle between upgrade and downgrade
        });
    });

    // Initialize button state based on stored value
    chrome.storage.sync.get('isGoldUpgraded', (data) => {
        toggleSubscription(data.isGoldUpgraded || false);
    });
});