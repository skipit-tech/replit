let triggerWarnings = [];

const HereditaryTriggerWarnings = [
  {
    startTime: 164, // 2:44
    endTime: 170, // 2:50
    warning: "Death Discussion",
    summary: "Family members are solemnly preparing to attend grandmother's funeral, with a sense of complicated grief."
  },
  {
    startTime: 208, // 3:28
    endTime: 215, // 3:35
    warning: "Parental Frustration",
    summary: "Mother discovers daughter slept outside in freezing weather and reacts with distress and anger."
  },
  {
    startTime: 358, // 5:58
    endTime: 361, // 6:01
    warning: "Grief",
    summary: "Young character questions whether their emotional response to death is appropriate, showing detachment."
  },
  {
    startTime: 594, // 9:54
    endTime: 601, // 10:01
    warning: "Disturbing Discussion",
    summary: "Mother reveals unsettling information about child's infancy, suggesting something unnatural."
  },
  {
    startTime: 617, // 10:17
    endTime: 625, // 10:25
    warning: "Disturbing Imagery",
    summary: "Child discovers mother in a trance-like state at night, creating an atmosphere of dread."
  },
  {
    startTime: 771, // 12:51
    endTime: 775, // 12:55
    warning: "Psychological Distress",
    summary: "Character admits to experiencing frightening hallucinations in their workspace."
  },
  {
    startTime: 857, // 14:17
    endTime: 860, // 14:20
    warning: "Shocking Moment",
    summary: "Sudden loud noise disrupts classroom, startling students and creating tension."
  },
  {
    startTime: 1107, // 18:27
    endTime: 1114, // 18:34
    warning: "Grief Group",
    summary: "Woman attends grief support group, reluctantly sharing about her mother's recent death."
  },
  {
    startTime: 1200, // 20:00
    endTime: 1209, // 20:09
    warning: "Mental Illness Discussion",
    summary: "Character reveals traumatic family history involving father's death by starvation due to severe depression."
  },
  {
    startTime: 1209, // 20:09
    endTime: 1219, // 20:19
    warning: "Suicide Discussion",
    summary: "Graphic description of brother's suicide by hanging and disturbing blame directed at the mother."
  },
  {
    startTime: 1887, // 31:27
    endTime: 1891, // 31:31
    warning: "Medical Emergency",
    summary: "Teenage girl experiences severe anaphylactic reaction in car after accidental nut consumption."
  },
  {
    startTime: 2114, // 35:14
    endTime: 2125, // 35:25
    warning: "Graphic Accident",
    summary: "Extremely disturbing car accident resulting in graphic decapitation of a child."
  },
  {
    startTime: 2291, // 38:11
    endTime: 2297, // 38:17
    warning: "Intense Grief",
    summary: "Mother discovers daughter's mutilated remains and experiences complete emotional breakdown."
  },
  {
    startTime: 2358, // 39:18
    endTime: 2370, // 39:30
    warning: "Suicidal Ideation",
    summary: "Mother screams in unbearable grief, expressing desire to die after seeing daughter's body."
  },
  {
    startTime: 3465, // 57:45
    endTime: 3470, // 57:50
    warning: "Child Loss",
    summary: "Woman recounts tragic drowning of both her son and young grandson in emotional conversation."
  },
  {
    startTime: 3953, // 65:53
    endTime: 3957, // 65:57
    warning: "Parental Rejection",
    summary: "Mother confesses to son that she never wanted to be pregnant with him and attempted to miscarry."
  },
  {
    startTime: 4579, // 76:19
    endTime: 4583, // 76:23
    warning: "Self-Harm",
    summary: "Woman attempts to burn a book but mysteriously catches fire herself in disturbing supernatural scene."
  },
  {
    startTime: 5012, // 83:32
    endTime: 5020, // 83:40
    warning: "Possession",
    summary: "Teenage boy violently convulses and injures himself during demonic possession at school."
  },
  {
    startTime: 5571, // 92:51
    endTime: 5577, // 92:57
    warning: "Disturbing Imagery",
    summary: "Mother possessed by supernatural entity crawls across ceiling in contorted position."
  },
  {
    startTime: 5784, // 96:24
    endTime: 5790, // 96:30
    warning: "Graphic Self-Harm",
    summary: "Possessed mother decapitates herself with piano wire in extremely graphic scene."
  }
];

const theSubstituteTriggerWarnings = [
  {
    startTime: 195, // in seconds (3:15)
    endTime: 220, // in seconds (3:40)
    warning: "War Violence + Death Reference",
    summary: "Flashback scene of a military operation in Cuba where several team members were killed. Jonathan Shale and his surviving comrades watch news reports about their teammates' deaths while the government denies involvement."
  },
  {
    startTime: 367, // in seconds (6:07)
    endTime: 390, // in seconds (6:30)
    warning: "Verbal Threats + Intimidation",
    summary: "Student Juan Lacas confronts teacher Jane Hetzko, using aggressive language and making intimidating threats. The confrontation escalates when Lacas invades her personal space in a threatening manner."
  },
  {
    startTime: 480, // in seconds (8:00)
    endTime: 508, // in seconds (8:28)
    warning: "Harassment + Sexual Harassment",
    summary: "A group of men verbally harass Jane Hetzko when she's entering her car, using sexually explicit language and making her uncomfortable. The situation quickly escalates into a dangerous confrontation."
  },
  {
    startTime: 845, // in seconds (14:05)
    endTime: 880, // in seconds (14:40)
    warning: "Homelessness + Vulnerability",
    summary: "Sheryl is shown being woken up by security while sleeping in a public space, indicating her housing insecurity. She's forced to leave immediately, highlighting her vulnerable situation."
  },
  {
    startTime: 955, // in seconds (15:55)
    endTime: 990, // in seconds (16:30)
    warning: "Physical Assault + Injury",
    summary: "Jane Hetzko is shown severely injured in the hospital after being attacked. Shale visits her and they discuss her assault, which involved breaking her kneecap in a calculated attack."
  },
  {
    startTime: 1245, // in seconds (20:45)
    endTime: 1280, // in seconds (21:20)
    warning: "Drug Dealing Discussion",
    summary: "Shale meets with a potential employer who offers him work protecting drug shipments. The conversation includes explicit references to illegal activities and potential violence against law enforcement."
  },
  {
    startTime: 1722, // in seconds (28:42)
    endTime: 1755, // in seconds (29:15)
    warning: "Classroom Violence + Intimidation",
    summary: "Shale, now posing as a substitute teacher, physically confronts students when they challenge his authority. He breaks a student's nose and threatens others to establish control of the classroom."
  },
  {
    startTime: 2080, // in seconds (34:40)
    endTime: 2115, // in seconds (35:15) 
    warning: "Gun Violence + Weapons",
    summary: "Shale discusses violence in Vietnam with students, showing disturbing comfort with discussing killing. The conversation includes references to weapons and glorification of combat experience."
  },
  {
    startTime: 2526, // in seconds (42:06)
    endTime: 2565, // in seconds (42:45)
    warning: "Implied Sexual Predation",
    summary: "At a party, Rodney shows disturbing photographs to other men and discusses young women in objectifying ways, revealing predatory behaviors through his comments and attitudes."
  },
  {
    startTime: 2850, // in seconds (47:30)
    endTime: 2875, // in seconds (47:55)
    warning: "Racial Tension + Confrontation",
    summary: "Shale and Darrell Sherman have a heated confrontation about racial issues when Shale suggests Principal Claude Rolle is involved in criminal activity. Sherman accuses Shale of racist motivations."
  },
  {
    startTime: 3080, // in seconds (51:20)
    endTime: 3110, // in seconds (51:50)
    warning: "Ambush + Weapons",
    summary: "Students affiliated with the KOD gang plan an armed ambush against Shale, showing weapons and discussing how they will attack him. They coordinate their positions and prepare for violence."
  },
  {
    startTime: 3195, // in seconds (53:15)
    endTime: 3250, // in seconds (54:10)
    warning: "School Violence + Weapons",
    summary: "A violent confrontation erupts in the school library as Shale encounters armed gang members. He disarms them and uses school equipment as weapons in a chaotic struggle for control."
  },
  {
    startTime: 3270, // in seconds (54:30)
    endTime: 3310, // in seconds (55:10)
    warning: "Implied Death + Aftermath of Violence",
    summary: "The aftermath of the library confrontation is shown, with injured students and destroyed property. There's an implication that serious harm or death occurred during the violent incident."
  },
  {
    startTime: 3860, // in seconds (1:04:20)
    endTime: 3900, // in seconds (1:05:00),
    warning: "Surveillance + Intimidation",
    summary: "Johnny Glades receives information about Shale's activities through surveilled phone calls. He threatens violence against a subordinate who failed to accurately report information, creating an atmosphere of fear."
  },
  {
    startTime: 4082, // in seconds (1:08:02)
    endTime: 4115, // in seconds (1:08:35),
    warning: "Home Invasion + Hostage Situation",
    summary: "Armed men break into Jane Hetzko's home, taking her hostage while she's still recovering from her injuries. They threaten her and use her to try to trap Shale."
  },
  {
    startTime: 4190, // in seconds (1:09:50)
    endTime: 4225, // in seconds (1:10:25),
    warning: "Elder Abuse + Threat to Bystander",
    summary: "An elderly landlady is threatened during a violent confrontation in Jane's apartment. She's used as leverage in a hostage situation, placing a vulnerable bystander in immediate danger."
  },
  {
    startTime: 4520, // in seconds (1:15:20)
    endTime: 4560, // in seconds (1:16:00),
    warning: "Kidnapping + Child Endangerment",
    summary: "Lisa Rodriguez, a student who witnessed criminal activity, is captured by Rolle's men. Jerome, another student, narrowly escapes but both teenagers are placed in extreme danger for their knowledge."
  },
  {
    startTime: 4685, // in seconds (1:18:05)
    endTime: 4730, // in seconds (1:18:50),
    warning: "School Shootout + Gun Violence",
    summary: "A major gunfight erupts at the school between Shale's team and Rolle's drug operation. Multiple armed combatants exchange gunfire in school hallways, with bullets damaging school property."
  },
  {
    startTime: 5040, // in seconds (1:24:00)
    endTime: 5080, // in seconds (1:24:40),
    warning: "Intense Violence + Hand-to-Hand Combat",
    summary: "Shale and Principal Rolle engage in a brutal hand-to-hand fight in a classroom. The prolonged, vicious combat includes use of classroom objects as weapons and shows graphic physical trauma."
  },
  {
    startTime: 5245, // in seconds (1:27:25)
    endTime: 5280, // in seconds (1:28:00),
    warning: "Drug References + Drug Dealing",
    summary: "The final confrontation reveals the extent of the school drug operation, with explicit discussion of how drugs were distributed through the school system using student gangs as intermediaries."
  }
];

const criminalMindsS1E1TriggerWarnings = [
  {
    startTime: 130, // in seconds (2:10)
    endTime: 157, // in seconds (2:37)
    warning: "Abuse",
    summary: "The man hits the woman unconscious in the car."
  },
  {
    startTime: 205, // in seconds (3:25)
    endTime: 219, // in seconds (3:39)
    warning: "Substance Use",
    summary: "The detective takes a shot of tequila with his trainees."
  },
  {
    startTime: 240, // in seconds (4:00)
    endTime: 255, // in seconds (4:15)
    warning: "Violence",
    summary: "Photos of the victims of the footpath killer are displayed."
  },
  {
    startTime: 302, // in seconds (5:02)
    endTime: 309, // in seconds (5:09)
    warning: "Violence",
    summary: "Another photo of a victim of the footpath killer is shown to the detective."
  },
  {
    startTime: 461, // in seconds (7:41)
    endTime: 495, // in seconds (8:15)
    warning: "Abuse",
    summary: "The kidnapped victim is seen locked up in a cage, with tape over her eyes."
  },
  {
    startTime: 637, // in seconds (10:37)
    endTime: 640, // in seconds (10:40)
    warning: "Violence",
    summary: "A photo of a strangled victim with a belt around her neck is shown to the detective."
  },
  {
    startTime: 1982, // in seconds (33:02)
    endTime: 1988, // in seconds (33:08)
    warning: "saba",
    summary: "The kidnapped woman is shown, still in the cage."
  },
];

const TheMenuTriggerWarnings = [
  {
    startTime: 236, // in seconds (3:56)
    endTime: 238, // in seconds (3:58)
    warning: "Profanity",
    summary: "Tyler enthusiastically praises Chef Slowik's food using explicit language that demonstrates his obsession with the dining experience."
  },
  {
    startTime: 408, // in seconds (6:48)
    endTime: 411, // in seconds (6:51)
    warning: "Crude Language",
    summary: "Margot uses a vulgar metaphor comparing the pretentious food conversation to a mountain of excrement, showing her disdain for the elitist atmosphere."
  },
  {
    startTime: 427, // in seconds (7:07)
    endTime: 429, // in seconds (7:09)
    warning: "Self-Deprecation",
    summary: "Actor George Diaz refers to himself in a self-deprecating manner regarding his foodie status while trying to impress the restaurant staff."
  },
  {
    startTime: 463, // in seconds (7:43)
    endTime: 466, // in seconds (7:46)
    warning: "Threatening Language",
    summary: "Elsa uses disturbing medical language to describe bacteria entering the bloodstream and spreading to spinal membranes if food is improperly aged, creating an uncomfortable atmosphere."
  },
  {
    startTime: 505, // in seconds (8:25)
    endTime: 507, // in seconds (8:27)
    warning: "Violent Language",
    summary: "Elsa describes the kitchen's food preparation process using violent terminology that creates an unsettling tone during the restaurant tour."
  },
  {
    startTime: 860, // in seconds (14:20)
    endTime: 863, // in seconds (14:23)
    warning: "Profanity",
    summary: "Tyler mockingly describes wealthy people's leisure activities using crude language, revealing his elitist attitude toward others."
  },
  {
    startTime: 1107, // in seconds (18:27)
    endTime: 1109, // in seconds (18:29)
    warning: "Emotional Distress",
    summary: "Tyler becomes emotionally overwhelmed while tasting the food, prompting his dining companion to point out his crying, creating an awkward social situation."
  },
  {
    startTime: 1199, // in seconds (19:59)
    endTime: 1201, // in seconds (20:01)
    warning: "Emotional Outburst",
    summary: "Ted expresses frustration about his companion's critique of food, dismissing their concerns with an emotional outburst that reveals tension between them."
  },
  {
    startTime: 1400, // in seconds (23:20)
    endTime: 1403, // in seconds (23:23)
    warning: "Crude Language",
    summary: "A diner complains about Chef Slowik's deliberate absence of bread using vulgar language, showing growing dissatisfaction with the conceptual dining experience."
  },
  {
    startTime: 1456, // in seconds (24:16)
    endTime: 1458, // in seconds (24:18)
    warning: "Verbal Abuse",
    summary: "Lillian Bloom points out to her dining companion that Chef Slowik is intentionally insulting his guests through his food presentation and concepts."
  },
  {
    startTime: 1605, // in seconds (26:45)
    endTime: 1607, // in seconds (26:47)
    warning: "Social Awkwardness",
    summary: "A dining accident occurs when a guest spills something at the table, creating an uncomfortable moment as Margot tries to diffuse the tension."
  },
  {
    startTime: 1817, // in seconds (30:17)
    endTime: 1819, // in seconds (30:19)
    warning: "Domestic Violence Reference",
    summary: "Chef Slowik shares a disturbing childhood memory where his mother became angry and screamed at his father during a violent domestic altercation."
  },
  {
    startTime: 1827, // in seconds (30:27)
    endTime: 1829, // in seconds (30:29)
    warning: "Child Trauma",
    summary: "Chef Slowik reveals childhood trauma describing how he begged his father to stop during a domestic violence incident, suggesting severe psychological impact."
  },
  {
    startTime: 2098, // in seconds (34:58)
    endTime: 2101, // in seconds (35:01)
    warning: "Physical Violence",
    summary: "Richard becomes agitated and demands to return food to the kitchen using profanity, escalating tensions in the dining room as staff watches."
  },
  {
    startTime: 2109, // in seconds (35:09)
    endTime: 2112, // in seconds (35:12)
    warning: "Verbal Abuse",
    summary: "Tyler verbally attacks Margot for wanting to return food, calling her a child and demonstrating controlling behavior that reveals their strained relationship."
  },
  {
    startTime: 2222, // in seconds (37:02)
    endTime: 2223, // in seconds (37:03)
    warning: "Self-Harm Reference",
    summary: "Chef Slowik expresses emotional vulnerability by describing how criticism wounds him, showing his fragile psychological state beneath his controlling exterior."
  },
  {
    startTime: 2410, // in seconds (40:10)
    endTime: 2414, // in seconds (40:14)
    warning: "Psychological Manipulation",
    summary: "Chef Slowik manipulates his staff by comparing his life pressures to theirs, using false equivalence to justify his abusive behavior toward them."
  },
  {
    startTime: 2414, // in seconds (40:14)
    endTime: 2417, // in seconds (40:17)
    warning: "Psychological Manipulation",
    summary: "Chef Slowik continues his psychological manipulation by emphasizing the pressure to create perfect food, establishing a toxic work environment."
  },
  {
    startTime: 2685, // in seconds (44:45)
    endTime: 2687, // in seconds (44:47)
    warning: "Verbal Distress",
    summary: "During the finger-cutting scene, a character exclaims about another person's pain, highlighting the escalating violent atmosphere in the restaurant."
  },
  {
    startTime: 3125, // in seconds (52:05)
    endTime: 3129, // in seconds (52:09)
    warning: "Crude Language",
    summary: "Chef Slowik uses a vulgar digestive analogy to describe his art being consumed, revealing his contempt for his customers in disturbing terms."
  },
  {
    startTime: 3181, // in seconds (53:01)
    endTime: 3183, // in seconds (53:03)
    warning: "Profanity",
    summary: "Diners react with shock and profanity when Chef Slowik reveals something disturbing, indicating the escalating dangerous situation they're in."
  },
  {
    startTime: 3356, // in seconds (55:56)
    endTime: 3358, // in seconds (55:58)
    warning: "Derogatory Language",
    summary: "Chef Slowik uses derogatory terminology to describe service workers when telling Margot where she belongs, revealing class prejudice."
  },
  {
    startTime: 3964, // in seconds (66:04)
    endTime: 3967, // in seconds (66:07)
    warning: "Fear",
    summary: "Chef Slowik announces that the planned menu cannot continue, creating fearful tension among the diners who sense the dangerous situation unfolding."
  },
  {
    startTime: 4044, // in seconds (67:24)
    endTime: 4046, // in seconds (67:26)
    warning: "Verbal Abuse",
    summary: "Chef Slowik verbally attacks Tyler with insults about his entitlement, publicly humiliating him before escalating to physical threats."
  },
  {
    startTime: 4189, // in seconds (69:49)
    endTime: 4191, // in seconds (69:51)
    warning: "Crude Language",
    summary: "Chef makes a disturbing scatological comment that combines crude language with threatening undertones, showing his deteriorating mental state."
  },
  {
    startTime: 4996, // in seconds (83:16)
    endTime: 4998, // in seconds (83:18)
    warning: "Psychological Intimidation",
    summary: "Chef Slowik psychologically torments his captive diners by questioning why they didn't fight back harder, adding to their distress and fear."
  },
  {
    startTime: 5027, // in seconds (83:47)
    endTime: 5029, // in seconds (83:49)
    warning: "Self-Harm",
    summary: "A character shows disturbing levels of identification with their professional role rather than their humanity, indicating psychological damage."
  },
  {
    startTime: 5428, // in seconds (90:28)
    endTime: 5430, // in seconds (90:30)
    warning: "Crude Language",
    summary: "Margot criticizes Chef's food preparation style using crude language in a tense confrontation that will determine her survival."
  }
];

const whiplashTriggerWarnings = [
  {
    startTime: 270, // 4:30
    endTime: 275, // 4:35
    warning: "Verbal Abuse",
    summary: "Fletcher insults a student's weight and playing ability, causing emotional distress."
  },
  {
    startTime: 410, // 6:50
    endTime: 420, // 7:00
    warning: "Intimidation",
    summary: "Fletcher creates tense atmosphere during band audition, deliberately intimidating students."
  },
  {
    startTime: 588, // 9:48
    endTime: 594, // 9:54
    warning: "Verbal Humiliation",
    summary: "Fletcher publicly humiliates a band member about being out of tune in front of entire ensemble."
  },
  {
    startTime: 715, // 11:55
    endTime: 728, // 12:08
    warning: "Homophobic Language",
    summary: "Fletcher uses homophobic slurs when addressing and insulting students in the band."
  },
  {
    startTime: 1040, // 17:20
    endTime: 1046, // 17:26
    warning: "Psychological Abuse",
    summary: "Fletcher throws a chair violently at a student during rehearsal."
  },
  {
    startTime: 1282, // 21:22
    endTime: 1303, // 21:43
    warning: "Verbal Harassment",
    summary: "Fletcher belittles and brings a student to tears, making deeply personal attacks."
  },
  {
    startTime: 1440, // 24:00
    endTime: 1456, // 24:16
    warning: "Slurs",
    summary: "Fletcher uses racial and homophobic slurs while berating students."
  },
  {
    startTime: 1600, // 26:40
    endTime: 1620, // 27:00
    warning: "Physical Violence",
    summary: "Fletcher repeatedly slaps a student's face while yelling about tempo."
  },
  {
    startTime: 1818, // 30:18
    endTime: 1835, // 30:35
    warning: "Emotional Manipulation",
    summary: "Andrew is shown becoming obsessed with practicing until his hands bleed."
  },
  {
    startTime: 2075, // 34:35
    endTime: 2090, // 34:50
    warning: "Self-Harm",
    summary: "Andrew practices drums until his hands are raw and bloody, bandaging them to continue."
  },
  {
    startTime: 2450, // 40:50
    endTime: 2465, // 41:05
    warning: "Relationship Abuse",
    summary: "Andrew emotionally manipulates and breaks up with his girlfriend due to toxic ambition."
  },
  {
    startTime: 3030, // 50:30
    endTime: 3060, // 51:00
    warning: "Verbal Abuse",
    summary: "Fletcher makes cruel remarks about a former student's suicide."
  },
  {
    startTime: 3600, // 60:00
    endTime: 3635, // 60:35
    warning: "Car Accident",
    summary: "Andrew is in a serious car accident but still attempts to perform while injured."
  },
  {
    startTime: 3750, // 62:30
    endTime: 3780, // 63:00
    warning: "Physical Violence",
    summary: "Andrew physically attacks Fletcher on stage during a performance."
  },
  {
    startTime: 4030, // 67:10
    endTime: 4055, // 67:35
    warning: "Depression",
    summary: "Andrew shown in deep depression after being expelled from music school."
  },
  {
    startTime: 4320, // 72:00
    endTime: 4340, // 72:20
    warning: "Betrayal",
    summary: "Fletcher deliberately sabotages Andrew's comeback performance."
  },
  {
    startTime: 4750, // 79:10
    endTime: 4765, // 79:25
    warning: "Parental Conflict",
    summary: "Andrew confronts his father about lack of support for his musical ambitions."
  },
  {
    startTime: 5365, // 89:25
    endTime: 5390, // 89:50
    warning: "Mental Breakdown",
    summary: "Andrew experiences a breakdown on stage during an important performance."
  },
  {
    startTime: 5680, // 94:40
    endTime: 5690, // 94:50
    warning: "Extreme Pressure",
    summary: "Fletcher's intimidation causes Andrew extreme psychological distress during finale."
  },
  {
    startTime: 6000, // 100:00
    endTime: 6120, // 102:00
    warning: "Toxic Relationship",
    summary: "The final drum solo sequence shows the culmination of the abusive teacher-student relationship."
  }
];

const insideOutTriggerWarnings = [
  {
    startTime: 441, // in seconds (7:21)
    endTime: 452, // in seconds (7:32)
    warning: "Moving",
    summary: "Put up the for sale sign and packs the car."
  },
  {
    startTime: 592, // in seconds (9:52)
    endTime: 606, // in seconds (10:06)
    warning: "Moving",
    summary: "Moving van stuff is delayed, which disappoints Riley, her parents bicker a little."
  },
  {
    startTime: 657, // in seconds (10:57)
    endTime: 668, // in seconds (11:08)
    warning: "Abandonment",
    summary: "Her dad leaves for work, fear and sadness start overthinking and stressing her out."
  },
  {
    startTime: 737, // in seconds (12:17)
    endTime: 764, // in seconds (12:44)
    warning: "Depression ",
    summary: "Sadness touches a memory and makes it sad."
  },
  {
    startTime: 783, // in seconds (13:03)
    endTime: 800, // in seconds (13:20)
    warning: "Depression ",
    summary: "Starts losing interest in her favorite things."
  },
  {
    startTime: 817, // in seconds (13:37)
    endTime: 829, // in seconds (13:49)
    warning: "Depression",
    summary: "Sadness nearly touches one of Riley's core memories and starts saying negative things about herself."
  },
  {
      startTime: 961, // in seconds (16:01)
      endTime: 1027, // in seconds (17:07)
      warning: "Fear",
      summary: "Fear gets freaked out by her dad's upset tone among other things, Riley starts to get anxious and experiencing a lot of mixed emotions and arguing."
  },
  {
      startTime: 1117, // in seconds (18:37)
      endTime: 1127, // in seconds (18:47)
      warning: "Fear + Dreaming",
      summary: "Riley has a distressing dream with her house being haunted and a dead mouse."
  },
  {
      startTime: 1409, // in seconds (23:29)
      endTime: 1506, // in seconds (25:06)
      warning: "Emotional Distress + Public Embarrassment",
      summary: "Distressing situation with sadness creating a core memory and then it leading to Joy and Sadness getting sucked up into the tube, also led to Riley crying at school."
  },
  {
      startTime: 1735, // in seconds (28:55)
      endTime: 1785, // in seconds (29:45)
      warning: "Argument",
      summary: "She had an argument with her dad which he then sends her to her room."
  },
  {
      startTime: 1873, // in seconds (31:13)
      endTime: 1903, // in seconds (31:43)
      warning: "Peril",
      summary: "Riley's goofball island starts to break down while Sadness and Joy are trying to head back to headquarters."
  },
  {
      startTime: 2172, // in seconds (36:12)
      endTime: 2195, // in seconds (36:35)
      warning: "Abandonment",
      summary: "Riley's old friend makes a new friend which makes her feel alone and jealous, she hangs up on her friend."
  },
  {
      startTime: 2774, // in seconds (46:14)
      endTime: 2804, // in seconds (46:44)
      warning: "Public Embarrassment + Argument",
      summary: "Riley isn't able to access hockey island and in return messes up her hockey tryouts - anger takes over and she gets off the ice and yells at her mom."
  },
  {
      startTime: 2870, // in seconds (47:50)
      endTime: 2961, // in seconds (49:21)
      warning: "Peril + Abandonment",
      summary: "Bing Bong's ship goes over the side and Bing Bong starts getting really anxious thinking that Riley no longer likes or cares about him, Sadness validates his feelings."
  },
  {
      startTime: 3293, // in seconds (54:53)
      endTime: 3309, // in seconds (55:09)
      warning: "Bad Dream",
      summary: "Dog split in half, bad dream."
  },
  {
      startTime: 3525, // in seconds (58:45)
      endTime: 3580, // in seconds (59:40)
      warning: "Fear",
      summary: "Spooky clown wakes her up."
  },
  {
      startTime: 3658, // in seconds (1:00:58)
      endTime: 3660, // in seconds (1:01:00)
      warning: "Abandonment + Running Away",
      summary: "Riley gets the idea to runaway."
  },
  {
      startTime: 3753, // in seconds (1:02:33)
      endTime: 3784, // in seconds (1:03:04)
      warning: "Stealing",
      summary: "Riley steals her mom's credit card to move away."
  },
  {
      startTime: 3842, // in seconds (1:04:02)
      endTime: 3981, // in seconds (1:06:21)
      warning: "Abandonment + Running Away + Peril",
      summary: "Riley starts packing her stuff to runaway, Joy gets dropped into the forgotten pit after almost abandoning Sadness."
  },
  {
      startTime: 4346, // in seconds (1:12:26)
      endTime: 4393, // in seconds (1:13:13)
      warning: "Loss",
      summary: "Bing Bong sacrifices himself to protect Riley and help Joy get back to HQ."
  },
  {
      startTime: 4433, // in seconds (1:13:53)
      endTime: 4597, // in seconds (1:16:37) 
      warning: "Abandonment + Running Away + Peril",
      summary: "Riley gets on the bus and Joy and Sadness struggle to get home."
  },
  {
      startTime: 4731, // in seconds (1:18:51)
      endTime: 4767, // in seconds (1:19:27)
      warning: "Abandonment + Running Away",
      summary: "Riley is on the bus."
  },
  {
      startTime: 4799, // in seconds (1:19:59)
      endTime: 4810, // in seconds (1:20:10)
      warning: "Stressed Parents + Missing Kid",
      summary: "Riley's parents freak out a bit when she gets home which stresses her out."
  },
  {
      startTime: 4890, // in seconds (1:21:30)
      endTime: 4962, // in seconds (1:22:42)
      warning: "Grief + Sadness",
      summary: "Riley starts crying about missing home and such which is sad."
  }
];

const babadook2014TriggerWarnings = [
  {
    startTime: 71, // in seconds (1:11)
    endTime: 118, // in seconds (1:58)
    warning: "Automobile accident",
    summary: "Amelia has an intense dream about the fatal car accident that took her husband's life."
  },
  {
    startTime: 360, // in seconds (6:00)
    endTime: 376, // in seconds (6:16)
    warning: "Weapon at school",
    summary: "Admin at Sam's school show Amelia a homemade crossbow he has smuggled in his backpack."
  },
  {
    startTime: 673, // in seconds (11:13)
    endTime: 756, // in seconds (12:36)
    warning: "Fear",
    summary: "Amelia and Sam read the Babadook book and he is traumatized by the mention of death."
  },
  {
    startTime: 870, // in seconds (14:30)
    endTime: 953, // in seconds (15:53)
    warning: "Sexual content",
    summary: "Amelia uses a vibrator and Sam interrupts her."
  },
  {
    startTime: 1347, // in seconds (22:27)
    endTime: 1392, // in seconds (23:12)
    warning: "Family Arguing",
    summary: "Sam is furious when Amelia disciplines him and yells at her."
  },
  {
    startTime: 1542, // in seconds (25:42)
    endTime: 1566, // in seconds (26:06)
    warning: "Family Arguing + Violence",
    summary: "Amelia confronts Sam with a decayed family photo and he shoves her backward."
  },
  {
    startTime: 1863, // in seconds (31:03)
    endTime: 1912, // in seconds (31:52)
    warning: "Emotional Distress + Fear",
    summary: "Sam has a seizure in the car."
  },
  {
    startTime: 2237, // in seconds (37:17)
    endTime: 2289, // in seconds (38:09)
    warning: "Murder/Suicide + Cruelty to Animals",
    summary: "Amelia finds the book repaired and filled with more terrifying pages including a drawing of the dog’s death."
  },
  {
    startTime: 2501, // in seconds (41:41)
    endTime: 2533, // in seconds (42:13)
    warning: "Insect Infestation",
    summary: "Amelia tears away wallpaper behind the fridge, leaving a hole through which cockroaches swarm."
  },
  {
    startTime: 2810, // in seconds (46:50)
    endTime: 2829, // in seconds (47:09)
    warning: "Supernatural Peril",
    summary: "The Babadook sneaks into Amelia's bedroom as she lies helpless beside Sam."
  },
  {
    startTime: 3066, // in seconds (51:06)
    endTime: 3126, // in seconds (52:06)
    warning: "Emotional Distress + Profanity",
    summary: "Exhausted, Amelia yells at Sam to 'eat shit!'"
  },
  {
    startTime: 3021, // in seconds (50:21)
    endTime: 3036,  // in seconds (50:36)
    warning: "Emotional Distress + Profanity",
    summary: "Exhausted, Amelia yells at Sam to 'eat shit!'"
  },
  {
    startTime: 3135, // in seconds (52:15)
    endTime: 3163, // in seconds (52:43)
    warning: "Insect Infestation + Peril",
    summary: "Amelia drives but is distracted by cockroaches crawling in her lap. She spots the Babadook in the mirror and accidentally crashes the car."
  },
  {
    startTime: 3176, // in seconds (52:56)
    endTime: 3184, // in seconds (53:04)
    warning: "Profanity",
    summary: "The driver of the other car calls Amelia a 'crazy bitch.'"
  },
  {
    startTime: 3207, // in seconds (53:27)
    endTime: 3266, // in seconds (54:26)
    warning: "Depression",
    summary: "Amelia sits in the bathtub, fully clothed while Sam tries to connect with her."
  },
  {
    startTime: 3276, // in seconds (54:36)
    endTime: 3322, // in seconds (55:22)
    warning: "Depression + Family Argument",
    summary: "When Sam touches his father's violin, Amelia yells at him."
  },
  {
    startTime: 3473, // in seconds (57:53)
    endTime: 3512, // in seconds (58:32)
    warning: "Emotional Distress + Fear/Violence",
    summary: "Furious, Amelia grabs a kitchen knife, cuts the phone cord, and threatens Sam."
  },
  {
    startTime: 3591, // in seconds (59:51)
    endTime: 3613, // in seconds (1:00:13)
    warning: "Violence + Gore",
    summary: "Amelia watches TV, glances at Sam who is covered in blood, apparently stabbed to death."
  },
  {
    startTime: 3882, // in seconds (1:04:42)
    endTime: 3904, // in seconds (1:04:04)
    warning: "Supernatural Peril",
    summary: "Amelia turns to see the Babadook in the kitchen; it thrusts its knife fingers out."
  },
  {
    startTime: 4011, // in seconds (1:06:51)
    endTime: 4034, // in seconds (1:07:14)
    warning: "Violence + Cruelty to Animals",
    summary: "Amelia freaks out and grabs the dog, after a struggle she breaks its neck."
  },
  {
    startTime: 4046, // in seconds (1:07:26)
    endTime: 4079, // in seconds (1:07:59)
    warning: "Gore",
    summary: "Amelia jerks a bloody tooth from her own jaw."
  },
  {
    startTime: 4124, // in seconds (1:08:44)
    endTime: 4244, // in seconds (1:10:44)
    warning: "Violence/Emotional Distress + Profanity",
    summary: "Amelia threatens Sam, calling him a 'little shit.' She forces her way into the room."
  },
  {
    startTime: 4244, // in seconds (1:10:44)
    endTime: 4247, // in seconds (1:10:47)
    warning: "Violence + Cruelty to Animals",
    summary: "Sam discovers the dog's dead body."
  },
  {
    startTime: 4293, // in seconds (1:11:33)
    endTime: 4381, // in seconds (1:13:01)
    warning: "Violence + Mental Illness",
    summary: "Amelia confesses to Sam that she hasn't been 'right' since his father died. He stabs her and tackles her."
  },
  {
    startTime: 4396, // in seconds (1:13:16)
    endTime: 4540, // in seconds (1:15:40)
    warning: "Violence + Gore",
    summary: "Amelia tries to strangle Sam but he tells her he loves her and she vomits black bile."
  },
  {
    startTime: 4562, // in seconds (1:16:02)
    endTime: 4604, // in seconds (1:16:44)
    warning: "Supernatural Peril",
    summary: "Sam flies backward up the stairs propelled by an invisible force which tosses him around the room."
  },
  {
    startTime: 4562, // in seconds (1:16:02)
    endTime: 4604,  // in seconds (1:16:44)
    warning: "Supernatural Peril",
    summary: "Sam flies backward up the stairs propelled by an invisible force which tosses him around the room and against the wall."
  },
  {
    startTime: 4657, // in seconds (1:17:37)
    endTime: 4678,  // in seconds (1:17:58)
    warning: "Gore",
    summary: "Dad appears and his head is sliced in half."
  },
  {
    startTime: 4751, // in seconds (1:19:11)
    endTime: 4784,  // in seconds (1:19:44)
    warning: "Supernatural Peril + Profanity",
    summary: "Amelia faces the Babadook and vows to 'fucking kill' it. Sam is nearly blown into the air but the Babadook retreats."
  },
  {
    startTime: 5052, // in seconds (1:24:12)
    endTime: 5097,  // in seconds (1:24:57)
    warning: "Insect Infestation",
    summary: "Amelia feeds a bowl of worms to the Babadook."
  }
];

const CarryOnTriggerWarnings = [
  {
    startTime: 108, // in seconds (01:48)
    endTime: 120, // in seconds (02:00)
    warning: "Criminal Activity",
    summary: "Yuri and his associate discuss the illegal acquisition of a chemical weapon called Novichok, revealing a dangerous black market transaction that sets up the film's central threat."
  },
  {
    startTime: 255, // in seconds (04:15)
    endTime: 262, // in seconds (04:22)
    warning: "Pregnancy Discussion",
    summary: "Ethan and Nora discuss their unplanned pregnancy, with Ethan suggesting anxiety about sudden life changes and potential unpreparedness for parenthood."
  },
  {
    startTime: 354, // in seconds (05:54)
    endTime: 360, // in seconds (06:00)
    warning: "Gun Violence Reference",
    summary: "Ethan practices pretending to be shot by Walter, foreshadowing dangerous situations while revealing their casual attitude toward violence."
  },
  {
    startTime: 439, // in seconds (07:19)
    endTime: 444, // in seconds (07:24)
    warning: "Career Disappointment",
    summary: "Nora encourages Ethan to reapply to the police academy, revealing his disappointment about his unfulfilled professional aspirations and career trajectory."
  },
  {
    startTime: 617, // in seconds (10:17)
    endTime: 621, // in seconds (10:21)
    warning: "Workplace Anxiety",
    summary: "Supervisor makes threatening comments to TSA officers about job security and stressful working conditions on Christmas Eve, creating an atmosphere of tension."
  },
  {
    startTime: 865, // in seconds (14:25)
    endTime: 870, // in seconds (14:30)
    warning: "Verbal Confrontation",
    summary: "Sarkowski denies Ethan a promotion with condescending language that minimizes his worth, creating a humiliating workplace interaction."
  },
  {
    startTime: 1142, // in seconds (19:02)
    endTime: 1147, // in seconds (19:07)
    warning: "Death Threat",
    summary: "Ethan receives a threatening phone call from an anonymous caller with life-or-death stakes, establishing the coercive situation that drives the plot."
  },
  {
    startTime: 1247, // in seconds (20:47)
    endTime: 1256, // in seconds (20:56)
    warning: "Hostage Situation",
    summary: "Ethan learns that his pregnant girlfriend Nora is being held at gunpoint by the caller's associates, creating an impossible moral dilemma about whether to comply with terrorists."
  },
  {
    startTime: 1293, // in seconds (21:33)
    endTime: 1299, // in seconds (21:39)
    warning: "Lethal Threat",
    summary: "The anonymous caller tells Ethan if he doesn't comply with demands, Nora will be killed, establishing life-threatening stakes."
  },
  {
    startTime: 1567, // in seconds (26:07)
    endTime: 1573, // in seconds (26:13)
    warning: "Graphic Violence Reference",
    summary: "The anonymous caller tells Ethan a disturbing story about throat-slitting children as a metaphor, using vivid and threatening language to intimidate him."
  },
  {
    startTime: 1837, // in seconds (30:37)
    endTime: 1843, // in seconds (30:43)
    warning: "Sudden Death",
    summary: "Officer Lionel Williams has a sudden fatal medical emergency (heart attack) caused by the anonymous caller, creating a shocking moment of violence."
  },
  {
    startTime: 2042, // in seconds (34:02)
    endTime: 2052, // in seconds (34:12)
    warning: "Forced Violence",
    summary: "Ethan is coerced by the caller into sabotaging Jason's career by planting alcohol on him, forced to commit harmful acts by threatening Nora's life."
  },
  {
    startTime: 2190, // in seconds (36:30)
    endTime: 2195, // in seconds (36:35)
    warning: "Chemical Weapons",
    summary: "The anonymous caller describes the Novichok nerve agent to Ethan in graphic detail, including the horrific effects it has on the body, creating disturbing imagery of suffering."
  },
  {
    startTime: 2351, // in seconds (39:11)
    endTime: 2359, // in seconds (39:19)
    warning: "Gunshot",
    summary: "Ethan is forced to shoot Sarkowski, with the sound and aftermath creating a shocking moment of violence that changes the trajectory of the story."
  },
  {
    startTime: 3162, // in seconds (52:42)
    endTime: 3171, // in seconds (52:51)
    warning: "Bomb Threat",
    summary: "The anonymous caller (now revealed to be the man in the bomber hat) threatens to detonate a bomb in the airport that would kill thousands of people if Ethan doesn't comply."
  },
  {
    startTime: 3267, // in seconds (54:27)
    endTime: 3274, // in seconds (54:34)
    warning: "Forced Murder",
    summary: "Ethan is ordered to shoot his boss in the surveillance room, creating an intense scene of coercion and moral conflict with life-or-death consequences."
  },
  {
    startTime: 3391, // in seconds (56:31)
    endTime: 3400, // in seconds (56:40)
    warning: "Physical Assault",
    summary: "Ethan and a woman (later identified as Jesse) engage in physical violence in a confined space, with sounds of struggle and injury creating an intense scene of conflict."
  },
  {
    startTime: 4247, // in seconds (70:47)
    endTime: 4254, // in seconds (70:54)
    warning: "Explosive Device",
    summary: "Ethan attempts to disarm a bomb with guidance from the bomber while Jesse watches, in a tense sequence where failure would result in mass casualties."
  },
  {
    startTime: 4544, // in seconds (75:44)
    endTime: 4550, // in seconds (75:50)
    warning: "Physical Combat",
    summary: "Ethan and the bomber engage in a violent struggle in an aircraft cargo hold, with life-threatening stakes and intense physical violence."
  },
  {
    startTime: 4740, // in seconds (79:00)
    endTime: 4748, // in seconds (79:08)
    warning: "Plane Emergency",
    summary: "The airplane captain declares an emergency after discovering Ethan and the bomber fighting in the cargo hold, creating a tense situation where hundreds of lives are at risk including Congresswoman Turner."
  }
];
  
const HowToTrainYourDragonTriggerWarnings = [
  {
    startTime: 135, // in seconds (02:15) - adjusted from 00:01:53,697 (+38)
    endTime: 140, // in seconds (02:20) - adjusted from 00:01:58,534 (+38)
    warning: "Reference to Violence",
    summary: "Hiccup narrates that Chief Stoick the Vast supposedly popped a dragon's head clean off its shoulders when he was a baby, establishing the violent relationship between Vikings and dragons."
  },
  {
    startTime: 288, // in seconds (04:48) - adjusted from 00:04:10,304 (+38)
    endTime: 295, // in seconds (04:55) - adjusted from 00:04:17,222 (+38)
    warning: "Destructive Technology",
    summary: "Hiccup's invention malfunctions and causes damage in the village, highlighting both his ingenuity and his tendency to create chaos, reinforcing his status as an outcast."
  },
  {
    startTime: 457, // in seconds (07:37) - adjusted from 00:06:59,563 (+38)
    endTime: 463, // in seconds (07:43) - adjusted from 00:07:05,734 (+38)
    warning: "Parental Conflict",
    summary: "Stoick harshly reprimands Hiccup in front of the entire village, telling him that every time he steps outside, disaster follows, showing the public humiliation he regularly faces."
  },
  {
    startTime: 517, // in seconds (08:37) - adjusted from 00:07:59,563 (+38)
    endTime: 525, // in seconds (08:45) - adjusted from 00:08:07,071 (+38)
    warning: "Emotional Rejection",
    summary: "Stoick tells Hiccup 'You're many things, but a dragon killer is not one of them,' delivering a clear message that Hiccup fails to meet his father's expectations of Viking identity."
  },
  {
    startTime: 698, // in seconds (11:38) - adjusted from 00:11:00,881 (+38)
    endTime: 705, // in seconds (11:45) - adjusted from 00:11:07,967 (+38)
    warning: "Self-Deprecation",
    summary: "Gobber tells Hiccup, 'It's not so much what you look like, it's what's inside that he can't stand,' reinforcing Hiccup's negative self-image and sense of rejection."
  },
  {
    startTime: 834, // in seconds (13:54) - adjusted from 00:13:16,015 (+38)
    endTime: 843, // in seconds (14:03) - adjusted from 00:13:25,304 (+38)
    warning: "Intent to Kill",
    summary: "Hiccup approaches the downed Night Fury with a knife, declaring 'I'm going to kill you, dragon' and 'I'll cut out your heart and take it to my father,' showing his desperation for approval."
  },
  {
    startTime: 985, // in seconds (16:25) - adjusted from 00:15:47,208 (+38)
    endTime: 993, // in seconds (16:33) - adjusted from 00:15:55,362 (+38)
    warning: "Forced Combat Training",
    summary: "Stoick ignores Hiccup's confession that he doesn't want to fight dragons and forces him into dragon training, dismissing his son's feelings and pushing him toward violence."
  },
  {
    startTime: 1121, // in seconds (18:41) - adjusted from 00:18:03,244 (+38)
    endTime: 1128, // in seconds (18:48) - adjusted from 00:18:10,286 (+38)
    warning: "Bullying",
    summary: "The young Viking recruits mock Hiccup when he joins dragon training, with Tuffnut asking 'who let him in' and others making derisive comments about his capabilities."
  },
  {
    startTime: 1156, // in seconds (19:16) - adjusted from 00:18:38,765 (+38)
    endTime: 1163, // in seconds (19:23) - adjusted from 00:18:45,147 (+38)
    warning: "Life-Threatening Situation",
    summary: "Gobber releases a Gronckle dragon during training without preparation, putting the untrained teenagers in immediate danger as part of their learning experience."
  },
  {
    startTime: 1227, // in seconds (20:27) - adjusted from 00:19:49,730 (+38)
    endTime: 1235, // in seconds (20:35) - adjusted from 00:19:57,100 (+38)
    warning: "Harsh Criticism",
    summary: "Astrid and others criticize Hiccup during training review, stating he's 'never where he should be' and generally dismissing his presence, reinforcing his outsider status."
  },
  {
    startTime: 1676, // in seconds (27:56) - adjusted from 00:27:18,326 (+38)
    endTime: 1683, // in seconds (28:03) - adjusted from 00:27:25,386 (+38)
    warning: "Frightened Animal",
    summary: "Toothless is severely frightened by an eel Hiccup offers, showing extreme fear response and establishing the dragon's vulnerability despite being considered a fearsome creature."
  },
  {
    startTime: 1948, // in seconds (32:28) - adjusted from 00:31:50,023 (+38)
    endTime: 1956, // in seconds (32:36) - adjusted from 00:31:58,023 (+38)
    warning: "Aggressive Confrontation",
    summary: "Astrid aggressively confronts Hiccup about his sudden improvement in dragon training, pinning him down and demanding answers while threatening him physically."
  },
  {
    startTime: 2033, // in seconds (33:53) - adjusted from 00:33:15,158 (+38)
    endTime: 2040, // in seconds (34:00) - adjusted from 00:33:22,286 (+38)
    warning: "Graphic Injury Description",
    summary: "Gobber graphically describes losing his hand and leg to dragons, claiming one dragon swallowed his hand whole and another took his leg, glorifying dismemberment as part of Viking culture."
  },
  {
    startTime: 2247, // in seconds (37:27) - adjusted from 00:36:49,805 (+38)
    endTime: 2254, // in seconds (37:34) - adjusted from 00:36:56,970 (+38)
    warning: "Animal Cruelty Reference",
    summary: "Gobber states that 'a downed dragon is a dead dragon,' highlighting the Vikings' historical practice of deliberately maiming dragons to kill them more easily."
  },
  {
    startTime: 2572, // in seconds (42:52) - adjusted from 00:42:14,428 (+38)
    endTime: 2580, // in seconds (43:00) - adjusted from 00:42:22,456 (+38)
    warning: "Parental Rejection",
    summary: "Stoick tells Hiccup 'you're not a Viking, you're not my son' after discovering he befriended a dragon, completely disowning him in a moment of anger and disappointment."
  },
  {
    startTime: 2800, // in seconds (46:40) - adjusted from 00:46:02,011 (+38)
    endTime: 2808, // in seconds (46:48) - adjusted from 00:46:10,259 (+38)
    warning: "Self-Deprecation",
    summary: "Hiccup expresses extreme self-criticism and regret, stating he should have killed Toothless when he had the chance, believing it 'would have been better for everyone.'"
  },
  {
    startTime: 3234, // in seconds (53:54) - adjusted from 00:53:16,646 (+38)
    endTime: 3243, // in seconds (54:03) - adjusted from 00:53:25,689 (+38)
    warning: "Captivity and Restraint",
    summary: "Toothless is captured, chained and muzzled by the Vikings after trying to protect Hiccup, portrayed in a distressing scene of a sentient creature being forcibly restrained."
  },
  {
    startTime: 3448, // in seconds (57:28) - adjusted from 00:56:50,264 (+38)
    endTime: 3455, // in seconds (57:35) - adjusted from 00:56:57,263 (+38)
    warning: "Imminent Danger",
    summary: "Vikings approach the dragon nest, unaware of the massive dragon waiting inside, putting the entire village in extreme danger due to Stoick's stubborn vendetta."
  },
  {
    startTime: 3772, // in seconds (1:02:52) - adjusted from 00:62:14,142 (+38)
    endTime: 3780, // in seconds (1:03:00) - adjusted from 00:62:22,017 (+38)
    warning: "Massive Creature Threat",
    summary: "The massive Red Death dragon emerges from the mountain, putting all the Vikings in mortal danger as it towers over them, creating an atmosphere of terror and hopelessness."
  },
  {
    startTime: 4247, // in seconds (1:10:47) - adjusted from 00:70:09,168 (+38)
    endTime: 4257, // in seconds (1:10:57) - adjusted from 00:70:19,701 (+38)
    warning: "Severe Injury",
    summary: "Gobber reveals that Hiccup lost part of his leg in the battle, showing the physical consequences of heroism and drawing a parallel between Hiccup and Toothless both having prosthetics."
  }
];

const ITTriggerWarnings = [
  {
    startTime: 329, // in seconds (05:29) - adjusted from 00:05:34,440 (-5)
    endTime: 355, // in seconds (05:55) - adjusted from 00:06:00,960 (-5)
    warning: "Child in Danger",
    summary: "Georgie approaches the storm drain and encounters Pennywise the clown, who engages him in disturbing conversation that builds tension and creates a sense of impending danger."
  },
  {
    startTime: 529, // in seconds (08:49) - adjusted from 00:08:54,440 (-5)
    endTime: 545, // in seconds (09:05) - adjusted from 00:09:10,950 (-5)
    warning: "Child Violence",
    summary: "Pennywise attacks young Georgie violently, with Georgie's cries for help and his final scream for Billy, showing the brutal attack on a child."
  },
  {
    startTime: 606, // in seconds (10:06) - adjusted from 00:10:11,840 (-5)
    endTime: 641, // in seconds (10:41) - adjusted from 00:10:46,640 (-5)
    warning: "Animal Cruelty",
    summary: "Mike's grandfather forces him to kill a sheep with a bolt gun while giving him a disturbing lecture about life and death, showing graphic animal slaughter."
  },
  {
    startTime: 713, // in seconds (11:53) - adjusted from 00:11:58,480 (-5)
    endTime: 750, // in seconds (12:30) - adjusted from 00:12:35,120 (-5)
    warning: "Bullying",
    summary: "Henry Bowers and his gang harass the Losers' Club members, using homophobic slurs and threatening language while taking Stan's kippah and throwing it like a frisbee."
  },
  {
    startTime: 724, // in seconds (12:04) - adjusted from 00:12:08,920 (-5)
    endTime: 757, // in seconds (12:37) - adjusted from 00:12:41,759 (-5)
    warning: "Sexual Harassment",
    summary: "Gretta and other female bullies harass Beverly in the school bathroom, calling her a slut and trash, dumping garbage over her stall, showing severe verbal harassment with sexual undertones."
  },
  {
    startTime: 1207, // in seconds (20:07) - adjusted from 00:20:12,160 (-5)
    endTime: 1237, // in seconds (20:37) - adjusted from 00:20:42,240 (-5)
    warning: "Child Missing",
    summary: "The children discuss Betty Ripsom's disappearance while seeing her mother waiting outside the school, highlighting the growing number of missing children in Derry."
  },
  {
    startTime: 1375, // in seconds (22:55) - adjusted from 00:23:00,280 (-5)
    endTime: 1407, // in seconds (23:27) - adjusted from 00:23:32,080 (-5)
    warning: "Extreme Bullying",
    summary: "Henry Bowers and his gang chase Ben, pin him down, and physically assault him, with Henry attempting to carve his name into Ben's stomach with a knife."
  },
  {
    startTime: 1711, // in seconds (28:31) - adjusted from 00:28:36,360 (-5)
    endTime: 1744, // in seconds (29:04) - adjusted from 00:29:09,040 (-5)
    warning: "Graphic Injury",
    summary: "The Losers' Club helps Ben treat his serious stomach wound from Henry's knife attack, showing bloody injury and Eddie's anxious reaction to potential infection."
  },
  {
    startTime: 2035, // in seconds (33:55) - adjusted from 00:34:00,720 (-5)
    endTime: 2049, // in seconds (34:09) - adjusted from 00:34:14,120 (-5)
    warning: "Parental Control",
    summary: "Beverly's father displays controlling behavior, interrogating her about being with boys and invading her privacy by searching through her underwear drawer and poem."
  },
  {
    startTime: 2292, // in seconds (38:12) - adjusted from 00:38:17,920 (-5)
    endTime: 2317, // in seconds (38:37) - adjusted from 00:38:42,120 (-5)
    warning: "Disturbing Imagery",
    summary: "Eddie encounters a leper at the abandoned house on Neibolt Street, a decomposing, diseased figure that represents his fears of illness and contamination."
  },
  {
    startTime: 2555, // in seconds (42:35) - adjusted from 00:42:40,120 (-5)
    endTime: 2590, // in seconds (43:10) - adjusted from 00:43:15,360 (-5)
    warning: "Blood and Gore",
    summary: "Beverly experiences blood erupting violently from her bathroom sink, covering her and the entire bathroom in a grotesque scene that her father cannot see."
  },
  {
    startTime: 3095, // in seconds (51:35) - adjusted from 00:51:40,720 (-5)
    endTime: 3137, // in seconds (52:17) - adjusted from 00:52:22,160 (-5)
    warning: "Sexual Abuse Implication",
    summary: "Beverly's father corners her in their apartment with disturbing dialogue asking if she's 'still his girl' while touching her face, strongly implying sexual abuse."
  },
  {
    startTime: 3422, // in seconds (57:02) - adjusted from 00:57:07,160 (-5)
    endTime: 3455, // in seconds (57:35) - adjusted from 00:57:40,680 (-5)
    warning: "Jump Scare",
    summary: "The projector scene where Pennywise suddenly appears in the family slides and breaks through into the room, terrifying the children with a sudden apparition that grows to enormous size."
  },
  {
    startTime: 3685, // in seconds (01:01:25) - adjusted from 01:01:30,400 (-5)
    endTime: 3708, // in seconds (01:01:48) - adjusted from 01:01:53,520 (-5)
    warning: "Domestic Violence",
    summary: "Beverly's father physically assaults her when she stands up to him, grabbing her violently and escalating to a physically abusive confrontation that ends with Beverly hitting him with a toilet tank lid."
  },
  {
    startTime: 4332, // in seconds (01:12:12) - adjusted from 01:12:17,160 (-5)
    endTime: 4412, // in seconds (01:13:32) - adjusted from 01:13:37,560 (-5)
    warning: "Supernatural Horror",
    summary: "The encounter at the Neibolt house where the children face multiple manifestations of Pennywise, including a scene where Eddie falls through the floor and breaks his arm."
  },
  {
    startTime: 4632, // in seconds (01:17:12) - adjusted from 01:17:17,880 (-5)
    endTime: 4656, // in seconds (01:17:36) - adjusted from 01:17:41,400 (-5)
    warning: "Medical Abuse",
    summary: "Eddie confronts his mother about his fake medications, revealing she's been giving him placebos and lying about his conditions for years out of controlling behavior."
  },
  {
    startTime: 4925, // in seconds (01:22:05) - adjusted from 01:22:10,680 (-5)
    endTime: 4954, // in seconds (01:22:34) - adjusted from 01:22:39,280 (-5)
    warning: "Attempted Murder",
    summary: "Henry Bowers attempts to kill Mike, holding him at knifepoint while making racist comments and revealing he burned down Mike's family home, before the Losers intervene."
  },
  {
    startTime: 5374, // in seconds (01:29:34) - adjusted from 01:29:39,720 (-5)
    endTime: 5407, // in seconds (01:30:07) - adjusted from 01:30:12,160 (-5)
    warning: "Child Kidnapping",
    summary: "Beverly is found captured by Pennywise, suspended in a catatonic state at the monster's lair surrounded by the floating bodies of missing children from Derry."
  },
  {
    startTime: 5785, // in seconds (01:36:25) - adjusted from 01:36:30,720 (-5)
    endTime: 5820, // in seconds (01:37:00) - adjusted from 01:37:05,120 (-5)
    warning: "Child Endangerment",
    summary: "Pennywise threatens to kill all the children one by one, offering to spare the others if they sacrifice Bill, putting them in an impossible moral situation that tests their loyalty."
  },
  {
    startTime: 5949, // in seconds (01:39:09) - adjusted from 01:39:14,880 (-5)
    endTime: 6015, // in seconds (01:40:15) - adjusted from 01:40:20,400 (-5)
    warning: "Intense Violence",
    summary: "The climactic battle against Pennywise where the Losers' Club fights back against the monster, featuring graphic violence as they attack the creature with various weapons, culminating in the defeat of the entity."
  }
];

const despicableMeTriggerWarnings = [
  {
    startTime: 225, // 3:45
    endTime: 240, // 4:00
    warning: "Bullying",
    summary: "Maxime Le Mal mocks Gru with insulting comments about his appearance, calling him a 'bald loser with a dad bod' in front of a crowd, causing public humiliation."
  },
  {
    startTime: 397, // 6:37
    endTime: 407, // 6:47
    warning: "Weapon Display",
    summary: "Gru pulls out a goop grenade and attempts to use it against Maxime Le Mal during a confrontation, showing casual use of weapons in a public setting."
  },
  {
    startTime: 489, // 8:09
    endTime: 502, // 8:22
    warning: "Death Threats",
    summary: "Maxime Le Mal screams at Gru as he's being arrested, making explicit threats about exterminating him, creating an atmosphere of intense hostility."
  },
  {
    startTime: 600, // 10:00
    endTime: 616, // 10:16
    warning: "Parental Rejection",
    summary: "Gru Jr. repeatedly shows clear dislike for his father despite Gru's enthusiastic attempts to bond, even spitting up food on him, showing distressing parental rejection."
  },
  {
    startTime: 732, // 12:12
    endTime: 747, // 12:27
    warning: "Home Displacement",
    summary: "The family is forced to leave their home and Lucky (Agnes's pet) behind due to safety concerns, causing emotional distress especially for Agnes who must abandon her beloved pet."
  },
  {
    startTime: 855, // 14:15
    endTime: 872, // 14:32
    warning: "Physical Violence",
    summary: "Minions engage in chaotic and destructive behavior, with Phil, Ron, and Ralph causing property damage and getting into physical altercations with each other."
  },
  {
    startTime: 1104, // 18:24
    endTime: 1121, // 18:41
    warning: "Child Distress",
    summary: "Agnes refuses to use her fake identity at karate class because she doesn't want to lie, leading to her being punished by being sent to the corner of disgrace and reflection by Sensei O'Sullivan."
  },
  {
    startTime: 1156, // 19:16
    endTime: 1168, // 19:28
    warning: "Child Endangerment",
    summary: "Sensei O'Sullivan releases a dangerous situation during karate class, putting the untrained children at immediate risk as part of their learning experience without proper preparation."
  },
  {
    startTime: 1227, // 20:27
    endTime: 1235, // 20:35
    warning: "Verbal Harassment",
    summary: "Children at karate class criticize Edith (now called Blair), stating she's never where she should be and generally dismissing her presence, reinforcing her outsider status."
  },
  {
    startTime: 1389, // 23:09
    endTime: 1403, // 23:23
    warning: "Fire Hazard",
    summary: "Lucy accidentally causes a fire at the salon while attempting to dye Melora's hair, putting multiple people in danger and triggering the fire alarm as the situation escalates."
  },
  {
    startTime: 1947, // 32:27
    endTime: 1958, // 32:38
    warning: "Blackmail",
    summary: "Poppy blackmails Gru by threatening to expose his true identity unless he helps her with a criminal heist, creating a situation where Gru is forced into illegal activity."
  },
  {
    startTime: 2090, // 34:50
    endTime: 2107, // 35:07
    warning: "Animal Transformation",
    summary: "Maxime Le Mal uses his device to transform a dog into a cockroach during his testing of the Roachification Ray, showing transformation of an animal without concern for its wellbeing."
  },
  {
    startTime: 2957, // 49:17
    endTime: 2975, // 49:35
    warning: "Dangerous Animals",
    summary: "Gru and the children break into the school to steal Lenny the honey badger, a dangerous animal that Gru warns is a vicious monster that eats bees and cobras for breakfast."
  },
  {
    startTime: 3123, // 52:03
    endTime: 3140, // 52:20
    warning: "Dangerous Driving",
    summary: "Gru and Poppy engage in reckless driving and dangerous activities while trying to escape from Principal Übelschlecht, putting themselves and others at risk on the road."
  },
  {
    startTime: 3849, // 1:04:09
    endTime: 3870, // 1:04:30
    warning: "Home Invasion",
    summary: "Valentina (Maxime's girlfriend) shows up at Gru's house looking for him, confronting his children and attempting to gain entry under false pretenses, threatening their safety."
  },
  {
    startTime: 4106, // 1:08:26
    endTime: 4126, // 1:08:46
    warning: "Physical Fighting",
    summary: "Principal Übelschlecht attacks Gru in his home, engaging in a physical altercation in front of the children while attempting to retrieve Lenny the honey badger, putting the whole family at risk."
  },
  {
    startTime: 4265, // 1:11:05
    endTime: 4290, // 1:11:30
    warning: "Child Abduction",
    summary: "Maxime Le Mal kidnaps Gru Jr., taking the baby away while laughing maniacally and taunting Gru, telling him the baby now belongs to him and will never see his father again."
  },
  {
    startTime: 4561, // 1:16:01
    endTime: 4585, // 1:16:25
    warning: "Falling Hazard",
    summary: "Gru nearly falls to his death from Maxime's flying ship while trying to save his son, creating a tense life-threatening scenario with dramatic visuals of Gru hanging from a great height."
  },
  {
    startTime: 4892, // 1:21:32
    endTime: 4910, // 1:21:50
    warning: "Parent-Child Peril",
    summary: "Maxime threatens Gru Jr.'s safety from a great height, putting the baby in extreme danger while taunting Gru about being unable to save his child, creating intense emotional distress."
  },
  {
    startTime: 5051, // 1:24:11
    endTime: 5070, // 1:24:30
    warning: "Parent-Child Separation",
    summary: "During a life-threatening situation, Gru tells Junior he loves him while facing possible death, creating an emotional moment that addresses fears of parental loss and abandonment."
  }
];

const schindlersListTriggerWarnings = [
  {
    startTime: 1155, // 19:15
    endTime: 1185, // 19:45
    warning: "Dehumanization",
    summary: "Jewish people are forced to register, having their names called out and documented while being treated as mere numbers in a chaotic and distressing scene at a processing center."
  },
  {
    startTime: 1907, // 31:47
    endTime: 1937, // 32:17
    warning: "Forced Displacement",
    summary: "Jewish families are forcibly evicted from their homes with limited belongings, creating a scene of chaos and distress as they're relocated to the ghetto."
  },
  {
    startTime: 2034, // 33:54
    endTime: 2058, // 34:18
    warning: "Abuse of Power",
    summary: "Nazi official Amon Goeth displays sadistic behavior, berating workers and shooting a female engineer in cold blood for correcting construction flaws, demonstrating random and unprovoked violence."
  },
  {
    startTime: 2452, // 40:52
    endTime: 2475, // 41:15
    warning: "Sexual Harassment",
    summary: "Helen Hirsch, Goeth's Jewish maid, describes being beaten for discarding bones and the unpredictable nature of abuse, highlighting the powerlessness of victims under Nazi control."
  },
  {
    startTime: 2950, // 49:10
    endTime: 2985, // 49:45
    warning: "Mass Violence",
    summary: "During the liquidation of the Krakow ghetto, Nazi soldiers force Jewish residents from their homes and apartments with extreme brutality, creating terrifying chaos."
  },
  {
    startTime: 3243, // 54:03
    endTime: 3280, // 54:40
    warning: "Child Endangerment",
    summary: "Children desperately hide from Nazi soldiers during the ghetto liquidation, crawling through toilet openings and hiding in dangerous places to avoid capture."
  },
  {
    startTime: 3565, // 59:25
    endTime: 3595, // 59:55
    warning: "Shooting Violence",
    summary: "A Nazi soldier randomly shoots and kills a Jewish woman walking with a bundle, witnessed by other prisoners who note the complete arbitrariness of the killing."
  },
  {
    startTime: 3710, // 1:01:50
    endTime: 3740, // 1:02:20
    warning: "Sexual Assault",
    summary: "Amon Goeth attempts to sexually assault his Jewish maid Helen Hirsch, toying with her emotions before suddenly turning violent and beating her."
  },
  {
    startTime: 4250, // 1:10:50
    endTime: 4290, // 1:11:30
    warning: "Mass Execution",
    summary: "Bodies of executed Jews are exhumed and burned to hide evidence of Nazi atrocities, with disturbing images of corpses being processed."
  },
  {
    startTime: 4487, // 1:14:47
    endTime: 4527, // 1:15:27
    warning: "Dead Bodies",
    summary: "Piles of exhumed corpses are shown being burned on massive pyres as Nazis attempt to destroy evidence of mass killings, with ash and smoke visible throughout the camp."
  },
  {
    startTime: 4833, // 1:20:33
    endTime: 4863, // 1:21:03
    warning: "Medical Experimentation",
    summary: "Jewish prisoners undergo degrading physical examinations as part of the selection process, with Nazi doctors coldly evaluating who will live and who will die."
  },
  {
    startTime: 5030, // 1:23:50
    endTime: 5060, // 1:24:20
    warning: "Child Separation",
    summary: "Children are forcibly separated from their parents during selections, with mothers desperately trying to keep their children close as officials tear families apart."
  },
  {
    startTime: 5163, // 1:26:03
    endTime: 5193, // 1:26:33
    warning: "Mass Deportation",
    summary: "Jewish prisoners are loaded onto trains bound for concentration camps, with families being separated and people crammed into cattle cars under inhumane conditions."
  },
  {
    startTime: 5300, // 1:28:20
    endTime: 5330, // 1:28:50
    warning: "Gas Chamber",
    summary: "Jewish women are led to shower rooms they fear are gas chambers, creating intense anxiety as they're stripped, shaved, and processed while uncertain if they will survive."
  },
  {
    startTime: 5555, // 1:32:35
    endTime: 5585, // 1:33:05
    warning: "Child Trauma",
    summary: "Children hide in latrine waste to avoid capture, forced to submerge themselves in sewage out of desperation to survive the camp selections."
  },
  {
    startTime: 6058, // 1:40:58
    endTime: 6088, // 1:41:28
    warning: "Murder",
    summary: "Amon Goeth casually shoots prisoners from his villa balcony as morning exercise, treating the murder of human beings as sport while they perform forced labor below."
  },
  {
    startTime: 7080, // 1:58:00
    endTime: 7110, // 1:58:30
    warning: "Suicidal Ideation",
    summary: "Schindler breaks down emotionally about not saving more people, holding his Nazi pin and car as symbols of lives he could have saved, expressing deep regret and survivor's guilt."
  },
  {
    startTime: 7263, // 2:01:03
    endTime: 7293, // 2:01:33
    warning: "Starving Prisoners",
    summary: "Emaciated Jewish prisoners are shown in their striped uniforms after liberation, highlighting the extreme physical toll of imprisonment and near-starvation conditions they survived."
  },
  {
    startTime: 7446, // 2:04:06
    endTime: 7476, // 2:04:36
    warning: "Emotional Distress",
    summary: "In the film's conclusion, Schindler Jews visit his grave in Jerusalem, placing stones as a Jewish mourning tradition, revisiting the trauma they endured and honoring the man who saved them."
  },
  {
    startTime: 4675, // 1:17:55
    endTime: 4705, // 1:18:25
    warning: "Psychological Torture",
    summary: "Nazi officers psychologically torment Jewish prisoners through unpredictable violence and arbitrary rules, creating an atmosphere of constant terror where survival seems impossible."
  }
];

const womanOfTheHourTriggerWarnings = [
  {
    startTime: 275, // in seconds (4:35)
    endTime: 305, // in seconds (5:05)
    warning: "Violence + Strangulation",
    summary: "Rodney physically attacks Sarah in a remote outdoor location. The scene shows him assaulting and strangling her while she desperately fights back, depicting a brutal murder."
  },
  {
    startTime: 375, // in seconds (6:15)
    endTime: 400, // in seconds (6:40)
    warning: "Dismissive Behavior + Verbal Humiliation",
    summary: "Sarah's audition is harshly critiqued by casting directors who speak negatively about her while she's still present, making demeaning comments about her appearance and acting abilities."
  },
  {
    startTime: 531, // in seconds (8:51)
    endTime: 555, // in seconds (9:15)
    warning: "Emotional Manipulation",
    summary: "Terry compliments Sheryl's acting abilities excessively while she's clearly upset about her failed audition, creating an uncomfortable dynamic where he's using her vulnerability to appear supportive."
  },
  {
    startTime: 670, // in seconds (11:10)
    endTime: 695, // in seconds (11:35)
    warning: "Sexual Harassment + Unwanted Advances",
    summary: "Terry makes a sudden romantic advance toward Sheryl at the bar, creating an uncomfortable situation where she's clearly surprised and unsettled by his actions."
  },
  {
    startTime: 848, // in seconds (14:08)
    endTime: 880, // in seconds (14:40)
    warning: "Homelessness",
    summary: "Sheryl is shown being woken up by a police officer while sleeping on a public bench, indicating her housing insecurity. She's forced to leave the area immediately."
  },
  {
    startTime: 905, // in seconds (15:05)
    endTime: 930, // in seconds (15:30)
    warning: "Theft",
    summary: "Sheryl steals items from a store and runs away when confronted by an employee, highlighting her desperate circumstances and financial struggles."
  },
  {
    startTime: 1020, // in seconds (17:00)
    endTime: 1050, // in seconds (17:30)
    warning: "Harassment + Unwanted Photography",
    summary: "Rodney takes photographs of Sheryl without her consent or knowledge while she's sitting alone, invading her privacy before approaching her with manipulative compliments."
  },
  {
    startTime: 1283, // in seconds (21:23)
    endTime: 1315, // in seconds (21:55)
    warning: "Sexual Objectification",
    summary: "Lisa and other production staff discuss changing Sheryl's outfit to something more revealing for The Dating Game, with a male producer commenting they should 'use her body' because 'she's got it.'"
  },
  {
    startTime: 1726, // in seconds (28:46)
    endTime: 1750, // in seconds (29:10)
    warning: "Violence + Murder Discussion",
    summary: "Charlie is shown on the phone in her new apartment before Rodney breaks in and brutally attacks her. The scene depicts him murdering another woman using the same methods shown earlier."
  },
  {
    startTime: 2030, // in seconds (33:50)
    endTime: 2055, // in seconds (34:15)
    warning: "Graphic Violence + Asphyxiation",
    summary: "The scene revisits Charlie's murder by Rodney, showing him strangling her while she desperately tries to escape. There are disturbing sounds of choking and struggle."
  },
  {
    startTime: 2525, // in seconds (42:05)
    endTime: 2550, // in seconds (42:30)
    warning: "Sexual Predation + Manipulation",
    summary: "Rodney shows disturbing photographs of young women to other men at a party, discussing them in objectifying ways and revealing predatory behaviors through his comments and attitudes."
  },
  {
    startTime: 2880, // in seconds (48:00)
    endTime: 2910, // in seconds (48:30)
    warning: "Rejection of Sexual Assault Claims",
    summary: "Laura tries to report Rodney to authorities as the man who assaulted her friend Alison, but her concerns are dismissed by the security guard who manipulates her into waiting for a producer who doesn't exist."
  },
  {
    startTime: 3090, // in seconds (51:30)
    endTime: 3120, // in seconds (52:00)
    warning: "Verbal Abuse + Humiliation",
    summary: "The Dating Game host Ed Burke becomes increasingly hostile toward Sheryl for her questions, whispering harsh comments about never wanting to see her again while maintaining a public facade."
  },
  {
    startTime: 3540, // in seconds (59:00)
    endTime: 3570, // in seconds (59:30)
    warning: "Stalking + Intimidation",
    summary: "After Sheryl rejects Rodney's advances and refuses to give him her real number, he follows her to her car in a threatening manner, creating an atmosphere of danger and menace."
  },
  {
    startTime: 3850, // in seconds (1:04:10)
    endTime: 3880, // in seconds (1:04:40)
    warning: "Psychological Distress + Trauma",
    summary: "Laura becomes extremely upset when Ken questions the validity of her recognition of Rodney, showing signs of retraumatization as she tries to convince him about the danger Rodney poses."
  },
  {
    startTime: 4290, // in seconds (1:11:30)
    endTime: 4320, // in seconds (1:12:00)
    warning: "Sexual Manipulation + Coercion",
    summary: "Amy, a homeless young woman, is shown in a vulnerable position with Rodney who is manipulating her with false affection and psychological tactics to gain her trust despite his violent intentions."
  },
  {
    startTime: 4550, // in seconds (1:15:50)
    endTime: 4585, // in seconds (1:16:25)
    warning: "Forced Restraint + Kidnapping",
    summary: "Amy is shown bound with ropes as Rodney's captive, begging to be freed while he takes disturbing photographs of her in this vulnerable state."
  },
  {
    startTime: 4816, // in seconds (1:20:16)
    endTime: 4850, // in seconds (1:20:50)
    warning: "Deception + False Identity",
    summary: "Rodney convinces Amy that the ropes were part of a roleplay and manipulates her into believing they have a romantic connection, gaslighting her about the dangerous situation she's in."
  },
  {
    startTime: 5154, // in seconds (1:25:54)
    endTime: 5190, // in seconds (1:26:30)
    warning: "Police Arrest + Violence",
    summary: "Police officers forcefully apprehend Rodney on the roadside, tackling him to the ground and restraining him while he violently resists arrest, showing his true violent nature."
  },
  {
    startTime: 5397, // in seconds (1:29:57)
    endTime: 5420, // in seconds (1:30:20)
    warning: "Aftermath of Sexual Assault + Trauma",
    summary: "A traumatized Amy is seen in the police car after being rescued from Rodney, showing the psychological impact of her captivity and near-death experience as she processes what happened."
  }
];

const eternalSunshineOfTheSpotlessMindTriggerWarnings = [
  {
    startTime: 375, // in seconds (6:15)
    endTime: 400, // in seconds (6:40)
    warning: "Social Anxiety + Awkward Interaction",
    summary: "Joel and Clementine have their first conversation on the train, with Joel feeling uncomfortable and struggling with social anxiety as Clementine's forward personality challenges his reserved nature."
  },
  {
    startTime: 606, // in seconds (10:06)
    endTime: 631, // in seconds (10:31)
    warning: "Alcohol Use",
    summary: "Clementine brings Joel to a bar and orders alcoholic drinks, saying the alcohol will make the 'seduction part less repugnant,' making Joel visibly uncomfortable with her directness."
  },
  {
    startTime: 795, // in seconds (13:15)
    endTime: 835, // in seconds (13:55)
    warning: "Dangerous Behavior + Risk-Taking",
    summary: "Clementine convinces Joel to follow her onto the frozen Charles River despite his concerns about the ice breaking. She dismisses his safety worries while they engage in risky behavior."
  },
  {
    startTime: 1051, // in seconds (17:31)
    endTime: 1075, // in seconds (17:55)
    warning: "Memory Manipulation + Medical Procedure",
    summary: "Joel discovers a medical organization called Lacuna, which offers a procedure to erase specific memories from people's minds, revealing the disturbing concept that drives the film's narrative."
  },
  {
    startTime: 1378, // in seconds (22:58)
    endTime: 1407, // in seconds (23:27)
    warning: "Emotional Distress + Betrayal",
    summary: "Joel visits Lacuna's office and learns that Clementine has had him erased from her memory, causing him intense emotional distress and feelings of betrayal and abandonment."
  },
  {
    startTime: 1845, // in seconds (30:45)
    endTime: 1875, // in seconds (31:15)
    warning: "Suicidal Ideation + Depression",
    summary: "Joel, emotionally devastated after learning about Clementine's memory erasure, decides to undergo the same procedure, exhibiting signs of depression and emotional numbness while preparing for the process."
  },
  {
    startTime: 2298, // in seconds (38:18)
    endTime: 2328, // in seconds (38:48),
    warning: "Verbal Abuse + Relationship Conflict",
    summary: "Inside Joel's memories, he and Clementine have an intense argument where they exchange cruel insults, with Joel saying something especially hurtful about Clementine's character that leaves her devastated."
  },
  {
    startTime: 2376, // in seconds (39:36)
    endTime: 2400, // in seconds (40:00),
    warning: "Sexual Misconduct + Invasion of Privacy",
    summary: "Patrick, a Lacuna technician, confesses to Stan that he stole Clementine's underwear while she was unconscious during her memory erasure procedure, exhibiting deeply inappropriate behavior."
  },
  {
    startTime: 2511, // in seconds (41:51)
    endTime: 2545, // in seconds (42:25),
    warning: "Emotional Abuse + Degradation",
    summary: "In a memory being erased, Joel and Clementine argue viciously, with Joel making cruel remarks about Clementine's lifestyle and personality, highlighting the toxic aspects of their relationship."
  },
  {
    startTime: 2730, // in seconds (45:30)
    endTime: 2765, // in seconds (46:05),
    warning: "Childhood Trauma + Bullying",
    summary: "Joel's memories regress to a traumatic childhood scene where he's being bullied by other children while Clementine observes, showing him in a vulnerable state of humiliation that has shaped his personality."
  },
  {
    startTime: 3063, // in seconds (51:03)
    endTime: 3093, // in seconds (51:33),
    warning: "Infidelity + Professional Misconduct",
    summary: "Mary kisses Dr. Mierzwiak, revealing an inappropriate relationship between them despite his marriage, creating a complex ethical breach given the power dynamics in their professional relationship."
  },
  {
    startTime: 3426, // in seconds (57:06)
    endTime: 3456, // in seconds (57:36),
    warning: "Identity Loss + Existential Crisis",
    summary: "Joel realizes his memories of Clementine are rapidly disappearing and begins to panic, trying desperately to stop the procedure as he experiences the disturbing sensation of losing part of himself."
  },
  {
    startTime: 3770, // in seconds (1:02:50)
    endTime: 3795, // in seconds (1:03:15),
    warning: "Suicidal Ideation + Substance Abuse",
    summary: "During a memory of conflict, Clementine exhibits self-destructive behavior while intoxicated, driving Joel's car recklessly and showing disregard for her own safety, alarming Joel."
  },
  {
    startTime: 3960, // in seconds (1:06:00)
    endTime: 3990, // in seconds (1:06:30),
    warning: "Child Endangerment + Neglect",
    summary: "Mary and Stan behave recklessly and unprofessionally while conducting the procedure on Joel, taking drugs and becoming distracted, potentially endangering their unconscious patient."
  },
  {
    startTime: 4182, // in seconds (1:09:42)
    endTime: 4207, // in seconds (1:10:07),
    warning: "Sexual Harassment + Unwanted Advances",
    summary: "Mary makes uncomfortable advances toward Dr. Mierzwiak, who is married, putting him in an awkward position and revealing her inappropriate feelings despite their professional relationship."
  },
  {
    startTime: 4347, // in seconds (1:12:27)
    endTime: 4377, // in seconds (1:12:57),
    warning: "Psychological Manipulation + Gaslighting",
    summary: "Patrick uses information and techniques from Joel's erased memories to manipulate Clementine into a relationship, mimicking Joel's behavior and words without her knowledge of their origin."
  },
  {
    startTime: 4815, // in seconds (1:20:15)
    endTime: 4845, // in seconds (1:20:45),
    warning: "Non-Consensual Procedure + Medical Ethics",
    summary: "Dr. Mierzwiak reveals that Mary previously underwent the memory erasure procedure without her current knowledge, raising serious questions about medical ethics and consent."
  },
  {
    startTime: 5095, // in seconds (1:24:55)
    endTime: 5125, // in seconds (1:25:25),
    warning: "Body Image Issues + Self-Loathing",
    summary: "Clementine shares a deeply personal childhood memory about feeling ugly and hating herself, revealing long-standing insecurities and self-esteem issues that continue to affect her as an adult."
  },
  {
    startTime: 5340, // in seconds (1:29:00)
    endTime: 5370, // in seconds (1:29:30),
    warning: "Loss + Grief",
    summary: "Joel experiences intense grief as his last memories of Clementine begin to disappear, realizing too late that he wants to keep these moments but is unable to stop the erasure process."
  },
  {
    startTime: 6145, // in seconds (1:42:25)
    endTime: 6180, // in seconds (1:43:00),
    warning: "Emotional Distress + Relationship Anxiety",
    summary: "Joel and Clementine confront the reality of their situation after listening to their recorded sessions, facing the painful truths of how they once felt about each other and the likely challenges ahead if they start anew."
  }
];

const mississippiBurningTriggerWarnings = [
  {
    startTime: 295, // 4:55
    endTime: 335, // 5:35
    warning: "Racial Violence + Murder",
    summary: "Three civil rights workers are chased on a rural road at night by men in vehicles. The scene culminates in their murder, showing the brutal consequences of racism in 1960s Mississippi."
  },
  {
    startTime: 430, // 7:10
    endTime: 470, // 7:50
    warning: "Racial Slurs",
    summary: "Sheriff Stuckey and Deputy Pell use racist language when first meeting FBI agents Ward and Anderson, immediately establishing the hostile racial climate of the town where they're investigating."
  },
  {
    startTime: 510, // 8:30
    endTime: 540, // 9:00
    warning: "Verbal Harassment",
    summary: "Anderson experiences hostility from local law enforcement as he tries to investigate the missing civil rights workers. Sheriff Stuckey dismisses the case as a publicity stunt created by Martin Luther King."
  },
  {
    startTime: 720, // 12:00
    endTime: 750, // 12:30
    warning: "Racial Discrimination",
    summary: "When Ward and Anderson enter a local diner, they encounter segregated seating. Ward attempts to sit in the colored section but is warned off by the waitress, demonstrating the entrenched segregation."
  },
  {
    startTime: 780, // 13:00
    endTime: 815, // 13:35
    warning: "Racial Intimidation",
    summary: "Agent Anderson attempts to question a Black patron at the diner, but the man is visibly terrified and refuses to speak, revealing the atmosphere of fear that prevents Black residents from cooperating with authorities."
  },
  {
    startTime: 880, // 14:40
    endTime: 915, // 15:15
    warning: "Hate Speech + Racism",
    summary: "Mayor Tilman speaks to the FBI agents, expressing deeply racist views about the local Black community while insisting they were happy before outside agitators came. He uses dehumanizing language to describe Black citizens."
  },
  {
    startTime: 1020, // 17:00
    endTime: 1080, // 18:00
    warning: "Nighttime Intimidation + Ku Klux Klan",
    summary: "Ward and Anderson observe a Ku Klux Klan meeting and covertly take photos of participants' car plates, revealing the prevalence of organized hate groups in the community."
  },
  {
    startTime: 1150, // 19:10
    endTime: 1200, // 20:00
    warning: "Racial Violence + Assault",
    summary: "A group of white men assault a Black man at night after coming to his home. The man's brother Fennis watches in terror as they beat him for potentially speaking to the FBI agents."
  },
  {
    startTime: 1230, // 20:30
    endTime: 1275, // 21:15
    warning: "Violent Threats",
    summary: "White men threaten a Black resident named Hollis, warning him that he'll be killed if he speaks to the FBI about what he witnessed. The scene demonstrates how violence maintains the code of silence in the town."
  },
  {
    startTime: 1300, // 21:40
    endTime: 1360, // 22:40
    warning: "Discussion of Racism + Childhood Trauma",
    summary: "Agent Anderson shares a personal story about his father's racism, recounting how his father poisoned a Black neighbor's mule out of jealousy and resentment, revealing the generational nature of racial hatred."
  },
  {
    startTime: 1380, // 23:00
    endTime: 1425, // 23:45
    warning: "Hate Crime + Arson",
    summary: "A bomb or explosive device detonates near where Ward and Anderson are staying, followed by a vehicle quickly leaving the scene. The attack demonstrates the violent resistance to their investigation."
  },
  {
    startTime: 1490, // 24:50
    endTime: 1520, // 25:20
    warning: "Verbal Intimidation",
    summary: "Mayor Tilman confronts Agent Ward at the motel the FBI has taken over, using threatening language about outsiders while suggesting violence against them is inevitable if they continue their investigation."
  },
  {
    startTime: 1720, // 28:40
    endTime: 1750, // 29:10
    warning: "Hate Speech",
    summary: "Local men in a barbershop openly discuss their racist views with Agent Anderson, who is undercover. They use slurs and derogatory language while Clayton Townley (local Klan leader) is present."
  },
  {
    startTime: 1940, // 32:20
    endTime: 2000, // 33:20
    warning: "Racist Ideology",
    summary: "Clayton Townley gives a public speech promoting white supremacy, declaring that they reject Jews, Catholics, and Black people while claiming to protect Anglo-Saxon democracy and the American way."
  },
  {
    startTime: 2130, // 35:30
    endTime: 2190, // 36:30
    warning: "Intimidation + Threats",
    summary: "In a local social club, Deputy Pell and others threaten Agent Anderson with violence, using slurs and telling him to leave town. They make explicit death threats against Black residents who might try to vote."
  },
  {
    startTime: 2350, // 39:10
    endTime: 2400, // 40:00
    warning: "Physical Violence",
    summary: "Agent Anderson has a violent confrontation with Deputy Pell at a bar, pinning him down and threatening him after Pell makes racist remarks and threatens violence against civil rights activists."
  },
  {
    startTime: 2550, // 42:30
    endTime: 2590, // 43:10
    warning: "Religious Intolerance + Arson",
    summary: "Ward and Anderson visit a Black church that was burned down, as this event motivated the three missing civil rights workers to return to the community before their disappearance."
  },
  {
    startTime: 2740, // 45:40
    endTime: 2780, // 46:20
    warning: "Hate Crime + Home Invasion",
    summary: "A group of white men in trucks terrorize a Black family at night, attacking their home and causing them to flee in terror. The assault demonstrates the impunity with which racists operate."
  },
  {
    startTime: 2905, // 48:25
    endTime: 2945, // 49:05
    warning: "Violent Assault + Hate Crime",
    summary: "A young Black boy named Aaron is brutally attacked after leaving church. The attackers specifically warn him against talking to the FBI, showing how violence enforces silence in the community."
  },
  {
    startTime: 3145, // 52:25
    endTime: 3190, // 53:10
    warning: "Slurs + Hate Speech",
    summary: "Local white residents being interviewed use extremely offensive racial slurs and express violently racist views, openly declaring their hatred of Black people and civil rights activists."
  },
  {
    startTime: 3640, // 1:00:40
    endTime: 3680, // 1:01:20
    warning: "Domestic Violence",
    summary: "Clinton Pell violently attacks his wife after discovering she spoke with FBI agents. The scene shows her being thrown across the room, highlighting how the violence of racism extends into domestic settings."
  },
  {
    startTime: 3750, // 1:02:30
    endTime: 3800, // 1:03:20
    warning: "Discovery of Bodies",
    summary: "FBI agents discover the bodies of the three missing civil rights workers buried in an earthen dam on a farm, confirming their murder and ending the search portion of their investigation."
  },
  {
    startTime: 4080, // 1:08:00
    endTime: 4120, // 1:08:40
    warning: "Racial Violence + Threats",
    summary: "Agent Anderson confronts Deputy Pell about his role in the murders, using physical intimidation and revealing details about Pell's involvement with the Klan in the killing of the civil rights workers."
  },
  {
    startTime: 4290, // 1:11:30
    endTime: 4320, // 1:12:00
    warning: "Suicide",
    summary: "The scene shows the aftermath of a man's death by hanging in his home, strongly implied to be a suicide. The death is connected to the investigation of the civil rights workers' murders."
  },
  {
    startTime: 4510, // 1:15:10
    endTime: 4550, // 1:15:50
    warning: "Verbal Assault + Slurs",
    summary: "Mrs. Pell is confronted by white residents who call her a 'n***** lover' for cooperating with the FBI. The harassment demonstrates the social consequences for whites who break racial solidarity."
  },
  {
    startTime: 4720, // 1:18:40
    endTime: 4760, // 1:19:20
    warning: "Torture + Intimidation",
    summary: "Agent Ward allows a specialist to use psychological torture techniques on Mayor Tilman, threatening him with a razor blade while telling a disturbing story about racial violence to extract information."
  },
  {
    startTime: 4960, // 1:22:40
    endTime: 5000, // 1:23:20
    warning: "Kidnapping + Threats",
    summary: "FBI agents engage in highly questionable tactics, abducting local Klan member Lester Cowens and staging a mock lynching to terrorize him into providing information about the murders."
  },
  {
    startTime: 5340, // 1:29:00
    endTime: 5370, // 1:29:30
    warning: "Home Invasion + Attack",
    summary: "Men in Klan-like outfits break into Lester Cowens' home at night, terrifying him with gunshots and leaving him cowering before they depart. The scene shows how the Klan punishes those who might talk."
  },
  {
    startTime: 5470, // 1:31:10
    endTime: 5510, // 1:31:50
    warning: "Physical Assault",
    summary: "Agent Anderson engages in a violent physical confrontation with Deputy Pell, beating him severely while questioning him about his involvement in the murders of the civil rights workers."
  },
  {
    startTime: 5750, // 1:35:50
    endTime: 5800, // 1:36:40
    warning: "Civil Rights Funeral",
    summary: "A Black minister delivers a passionate speech at the funeral of the murdered civil rights worker, expressing anger and frustration at the violence against Black Americans while mourners grieve."
  }
];

const theSecretLifeOfPetsTriggerWarnings = [
  {
    startTime: 183, // 3:03
    endTime: 194, // 3:14
    warning: "Abandonment",
    summary: "Max explains his daily struggle with Katie leaving for work, showing his separation anxiety as he tries various tricks to make her stay but ultimately watches her leave every day."
  },
  {
    startTime: 657, // 10:57
    endTime: 668, // 11:08
    warning: "Abandonment",
    summary: "Katie leaves for work, causing Fear and Sadness to start overwhelming Max as he realizes he's now alone with Duke, triggering his anxiety about being left behind."
  },
  {
    startTime: 737, // 12:17
    endTime: 764, // 12:44
    warning: "Depression",
    summary: "Sadness begins affecting Max's core memories, making him lose interest in his favorite activities as his emotional state deteriorates with Duke's presence."
  },
  {
    startTime: 817, // 13:37
    endTime: 829, // 13:49
    warning: "Depression",
    summary: "Sadness nearly touches one of Max's core memories while he starts saying negative things about himself, showing his declining self-worth."
  },
  {
    startTime: 1735, // 28:55
    endTime: 1785, // 29:45
    warning: "Family Conflict",
    summary: "Max has an argument with an authority figure who then sends him to his room as punishment, creating tension in the household."
  },
  {
    startTime: 2172, // 36:12
    endTime: 2195, // 36:35
    warning: "Friendship Loss + Jealousy",
    summary: "Max's old friend has made a new friend, making Max feel alone and jealous. In his hurt, he hangs up on his friend, ending their conversation abruptly."
  },
  {
    startTime: 2540, // 42:20
    endTime: 2580, // 43:00
    warning: "Threat + Intimidation",
    summary: "Snowball the rabbit and his gang of discarded pets threaten Max and Duke, using intimidating language about being abandoned pets seeking revenge against humans."
  },
  {
    startTime: 2685, // 44:45
    endTime: 2720, // 45:20
    warning: "Violence + Gang Intimidation",
    summary: "Snowball's gang surrounds Max and Duke in the sewers, with the discarded pets making violent threats and discussing their hatred for humans who abandoned them."
  },
  {
    startTime: 2950, // 49:10
    endTime: 2985, // 49:45
    warning: "Violence + Death Threats",
    summary: "Snowball forces Max and Duke to prove they're not house pets by telling detailed stories about killing their owners, creating a threatening interrogation scenario."
  },
  {
    startTime: 3270, // 54:30
    endTime: 3310, // 55:10
    warning: "Violence + Snake Attack",
    summary: "Max and Duke are forced to face the sacred snake as an initiation test, with the dangerous animal being used to threaten and potentially harm them."
  },
  {
    startTime: 4011, // 1:06:51
    endTime: 4034, // 1:07:14
    warning: "Animal Death + Violence",
    summary: "In a disturbing scene, a character breaks the neck of a dog during a violent struggle, showing graphic animal death and brutality."
  },
  {
    startTime: 4124, // 1:08:44
    endTime: 4147, // 1:09:07
    warning: "Threat + Profanity",
    summary: "A character threatens another, calling them a derogatory name and making violent threats while trying to force entry into a room where someone is hiding."
  },
  {
    startTime: 4293, // 1:11:33
    endTime: 4320, // 1:12:00
    warning: "Violence + Mental Breakdown",
    summary: "A character confesses they haven't been right since losing someone, leading to a violent confrontation where someone gets stabbed during the struggle."
  },
  {
    startTime: 4562, // 1:16:02
    endTime: 4584, // 1:16:24
    warning: "Supernatural Violence",
    summary: "A character is violently thrown backward up stairs by an invisible supernatural force and tossed around the room against walls."
  },
  {
    startTime: 4751, // 1:19:11
    endTime: 4784, // 1:19:44
    warning: "Confrontation + Profanity",
    summary: "A character faces a threatening entity, using profanity and vowing to kill it while another character is nearly blown into the air by supernatural forces."
  },
  {
    startTime: 5190, // 1:26:30
    endTime: 5220, // 1:27:00
    warning: "Chase + Pursuit",
    summary: "Characters are being chased through the sewers by Snowball's gang, with the discarded pets hunting them down while making violent threats."
  },
  {
    startTime: 5570, // 1:32:50
    endTime: 5600, // 1:33:20
    warning: "Water Peril + Near Drowning",
    summary: "Duke struggles in water and appears to be drowning while Max desperately tries to save him, creating a life-threatening situation in the river."
  },
  {
    startTime: 5870, // 1:37:50
    endTime: 5900, // 1:38:20
    warning: "Rescue Mission + Danger",
    summary: "Gidget leads a dangerous rescue mission to save Max, with multiple animals putting themselves at risk in the hostile sewer environment."
  },
  {
    startTime: 6180, // 1:43:00
    endTime: 6220, // 1:43:40
    warning: "Bridge Collapse + Peril",
    summary: "Characters face extreme danger during a dramatic scene on the Brooklyn Bridge, with structural collapse and life-threatening situations affecting multiple animals."
  },
  {
    startTime: 6400, // 1:46:40
    endTime: 6440, // 1:47:20
    warning: "Emotional Reunion + Forgiveness",
    summary: "Max and Duke have an emotional conversation about their relationship, with Max thanking Duke for saving his life and both characters processing their traumatic experiences together."
  }
];

const barbieTriggerWarnings = [
  {
    startTime: 831, // 13:51
    endTime: 849, // 14:09
    warning: "Existential Crisis",
    summary: "Barbie suddenly asks the other Barbies if they've ever thought about death during their perfect party, creating an uncomfortable moment that disrupts the perpetually happy atmosphere."
  },
  {
    startTime: 929, // 15:29
    endTime: 987, // 16:27
    warning: "Relationship Conflict",
    summary: "Ken expresses his desire to stay overnight at Barbie's Dream House as her boyfriend, but Barbie rejects him, leading to tension about their undefined relationship and Ken's feelings of rejection."
  },
  {
    startTime: 1043, // 17:23
    endTime: 1089, // 18:09
    warning: "Body Horror + Physical Changes",
    summary: "Barbie wakes up with flat feet instead of her signature high-heeled pose, experiencing her first physical imperfection and realizing something is fundamentally wrong with her perfect existence."
  },
  {
    startTime: 1149, // 19:09
    endTime: 1189, // 19:49
    warning: "Public Embarrassment + Physical Malfunction",
    summary: "Barbie falls from her roof and experiences public shame for the first time when other Barbies witness her clumsiness and flat feet, marking her loss of perfection."
  },
  {
    startTime: 1345, // 22:25
    endTime: 1384, // 23:04
    warning: "Body Image Issues",
    summary: "Weird Barbie reveals that Barbie is developing cellulite on her thigh, explaining that these physical imperfections will spread and make her increasingly upset and emotional unless she fixes the problem."
  },
  {
    startTime: 1434, // 23:54
    endTime: 1493, // 24:53
    warning: "Forced Journey + Loss of Control",
    summary: "Weird Barbie forces Barbie to choose between accepting the truth about the universe or staying ignorant, manipulating the situation so Barbie has no real choice but to go to the Real World."
  },
  {
    startTime: 1752, // 29:12
    endTime: 1792, // 29:52
    warning: "Sexual Harassment + Objectification",
    summary: "Construction workers catcall and make sexually suggestive comments to Barbie and Ken when they arrive in the Real World, making Barbie feel uncomfortable and self-conscious for the first time."
  },
  {
    startTime: 1868, // 31:08
    endTime: 1907, // 31:47
    warning: "Gender Role Shock",
    summary: "Barbie is confused and disturbed to discover that the Real World operates differently from Barbie Land, with men holding positions of power instead of women, contradicting everything she believed about gender equality."
  },
  {
    startTime: 2387, // 39:47
    endTime: 2442, // 40:42
    warning: "Verbal Abuse + Harsh Criticism",
    summary: "Teenager Sasha brutally criticizes Barbie, calling her a fascist who represents everything wrong with beauty standards and capitalism, crushing Barbie's belief that she helps women feel empowered."
  },
  {
    startTime: 2572, // 42:52
    endTime: 2612, // 43:32
    warning: "Emotional Breakdown + Crying",
    summary: "Barbie experiences her first emotional breakdown, crying uncontrollably after being rejected and criticized, learning what it feels like to be genuinely hurt and misunderstood."
  },
  {
    startTime: 2830, // 47:10
    endTime: 2890, // 48:10
    warning: "Corporate Manipulation + Forced Compliance",
    summary: "Mattel executives attempt to force Barbie into a large box to return her to her doll state, using manipulative language while dismissing her concerns about Ken and her desire to see women in leadership positions."
  },
  {
    startTime: 3240, // 54:00
    endTime: 3300, // 55:00
    warning: "Identity Crisis + Self-Doubt",
    summary: "Gloria reveals she created Barbie's existential crisis through her own depression and conflicted feelings about motherhood, explaining the psychic connection that's been causing Barbie's emotional turmoil."
  },
  {
    startTime: 3588, // 59:48
    endTime: 3648, // 1:00:48
    warning: "Dystopian Transformation",
    summary: "Barbie returns to Barbie Land to discover that Ken has transformed it into a patriarchal society where all the Barbies serve the Kens, completely reversing the power structure she knew and loved."
  },
  {
    startTime: 3708, // 1:01:48
    endTime: 3768, // 1:02:48
    warning: "Loss of Home + Property Theft",
    summary: "Ken has taken over Barbie's Dream House and converted it into his 'Mojo Dojo Casa House,' stripping away her pink aesthetic and replacing it with masculine décor, symbolically erasing her identity."
  },
  {
    startTime: 3948, // 1:05:48
    endTime: 4008, // 1:06:48
    warning: "Emotional Manipulation + Gaslighting",
    summary: "Ken emotionally manipulates Barbie by describing how the Real World made him feel important and respected, using his pain to justify taking over her world and dismissing her feelings about the changes."
  },
  {
    startTime: 4308, // 1:11:48
    endTime: 4368, // 1:12:48
    warning: "Depression + Hopelessness",
    summary: "Barbie falls into a deep depression, lying on the ground in despair and telling Gloria and Sasha to leave her alone, feeling completely defeated and unable to fight for her world."
  },
  {
    startTime: 4500, // 1:15:00
    endTime: 4590, // 1:16:30
    warning: "Societal Pressure + Impossible Standards",
    summary: "Gloria delivers a powerful monologue about the impossible standards placed on women, describing the contradictory expectations that make it literally impossible to be a woman in society without failing someone's expectations."
  },
  {
    startTime: 4665, // 1:17:45
    endTime: 4725, // 1:18:45
    warning: "Self-Worth Crisis + Inadequacy",
    summary: "Barbie breaks down about not being smart, accomplished, or special enough, expressing deep insecurity about her worth and abilities compared to other versions of herself who achieved great things."
  },
  {
    startTime: 5070, // 1:24:30
    endTime: 5130, // 1:25:30
    warning: "Emotional Confrontation + Relationship End",
    summary: "Barbie apologizes to Ken for taking him for granted but explains that she doesn't love him romantically, leading to Ken's emotional breakdown as he realizes his entire identity was built around her attention."
  },
  {
    startTime: 5490, // 1:31:30
    endTime: 5550, // 1:32:30
    warning: "Mortality + Human Vulnerability",
    summary: "Ruth Handler explains to Barbie that choosing to become human means accepting death, discomfort, and all the painful aspects of mortality, making Barbie confront the reality of what she's choosing."
  }
];

const matildaTriggerWarnings = [
  {
    startTime: 147, // 2:27
    endTime: 180, // 3:00
    warning: "Child Neglect",
    summary: "The Wormwood parents are so busy and self-absorbed that they completely forget they have a daughter, showing Matilda being ignored and left to fend for herself as a toddler."
  },
  {
    startTime: 268, // 4:28
    endTime: 294, // 4:54
    warning: "Educational Neglect + Verbal Dismissal",
    summary: "When four-year-old Matilda asks her father for a book to read, he dismisses her request and tells her to watch television instead, showing the family's anti-intellectual attitude."
  },
  {
    startTime: 465, // 7:45
    endTime: 502, // 8:22
    warning: "Age Denial + Emotional Neglect",
    summary: "Matilda's parents refuse to acknowledge her correct age, calling her a liar when she says she's six, and dismiss her desire to go to school because they need her to sign for packages."
  },
  {
    startTime: 544, // 9:04
    endTime: 574, // 9:34
    warning: "Sibling Bullying + Name-calling",
    summary: "Matilda's brother Michael throws marshmallows at her and repeatedly calls her 'dipface,' showing the hostile family environment where she faces mockery from all sides."
  },
  {
    startTime: 634, // 10:34
    endTime: 684, // 11:24
    warning: "Threat of Physical Punishment",
    summary: "Harry threatens to punish Matilda for being smart, introducing the disturbing concept that intelligence is something to be punished for in their household."
  },
  {
    startTime: 894, // 14:54
    endTime: 944, // 15:44
    warning: "Criminal Activity + Child Exposure",
    summary: "Harry takes his son Michael to work to teach him how to cheat customers, showing children being deliberately exposed to and trained in illegal business practices."
  },
  {
    startTime: 959, // 15:59
    endTime: 999, // 16:39
    warning: "Verbal Abuse + Intimidation",
    summary: "When Matilda points out that her father's business practices are illegal, Harry responds by shouting that he's smart and she's dumb, using intimidation to silence her moral objections."
  },
  {
    startTime: 1081, // 18:01
    endTime: 1121, // 18:41
    warning: "Public Humiliation + Physical Restraint",
    summary: "Harry gets his hat stuck to his head with super glue (Matilda's revenge) and experiences public embarrassment at a restaurant, though this serves as comeuppance for his treatment of his daughter."
  },
  {
    startTime: 1156, // 19:16
    endTime: 1196, // 19:56
    warning: "Authoritarian Control + Book Destruction",
    summary: "Harry establishes harsh family rules and destroys Matilda's library book, showing extreme controlling behavior and destruction of educational materials as punishment."
  },
  {
    startTime: 1332, // 22:12
    endTime: 1372, // 22:52
    warning: "Child Abuse Threat + Intimidation",
    summary: "Principal Trunchbull tells Harry she believes in using physical punishment on children, saying 'Use the rod, beat the child' and calling all children mistakes and brats."
  },
  {
    startTime: 1438, // 23:58
    endTime: 1468, // 24:28
    warning: "Physical Violence + Child Endangerment",
    summary: "Students describe how Principal Trunchbull physically throws children, with one student being thrown over the school fence by her pigtails in a hammer-throw motion."
  },
  {
    startTime: 1505, // 25:05
    endTime: 1545, // 25:45
    warning: "Torture Device + Physical Abuse",
    summary: "Students explain 'The Chokey,' a torture device disguised as punishment - a narrow closet with nails sticking out and jagged edges designed to cause pain and fear."
  },
  {
    startTime: 1582, // 26:22
    endTime: 1655, // 27:35
    warning: "Physical Violence + Child Abuse",
    summary: "Principal Trunchbull grabs student Amanda Thripp by her pigtails and spins her around before throwing her over the school fence, demonstrating extreme physical abuse disguised as discipline."
  },
  {
    startTime: 1966, // 32:46
    endTime: 2016, // 33:36
    warning: "Verbal Abuse + Humiliation",
    summary: "Matilda's mother Zinnia dismisses Miss Honey's concerns about Matilda's exceptional abilities, making cruel comments about educated people and prioritizing appearance over intelligence."
  },
  {
    startTime: 2282, // 38:02
    endTime: 2350, // 39:10
    warning: "Forced Eating + Public Humiliation",
    summary: "Principal Trunchbull forces student Bruce Bogtrotter to eat an enormous chocolate cake in front of the entire school as punishment, creating a situation designed to make him sick."
  },
  {
    startTime: 2590, // 43:10
    endTime: 2650, // 44:10
    warning: "False Accusation + Verbal Abuse",
    summary: "Principal Trunchbull falsely accuses Matilda of putting a newt in her water pitcher and verbally abuses her, calling her corrupt and claiming absolute authority over the children."
  },
  {
    startTime: 3234, // 53:54
    endTime: 3294, // 54:54
    warning: "Family Backstory + Death",
    summary: "Miss Honey reveals her tragic backstory about living with her abusive aunt Trunchbull after her father's mysterious death, which police ruled a suicide but she doubts."
  },
  {
    startTime: 3654, // 60:54
    endTime: 3714, // 61:54
    warning: "Home Invasion + Supernatural Activity",
    summary: "Matilda uses her telekinetic powers to terrorize Trunchbull in her own home, moving objects and writing threatening messages to defend Miss Honey, escalating to supernatural revenge."
  },
  {
    startTime: 4374, // 72:54
    endTime: 4434, // 73:54
    warning: "Supernatural Confrontation + Public Display",
    summary: "During Trunchbull's interrogation of the class, Matilda uses her powers to write a message on the blackboard claiming to be Miss Honey's dead father, creating a terrifying supernatural confrontation."
  },
  {
    startTime: 4740, // 79:00
    endTime: 4800, // 80:00
    warning: "Family Abandonment + Adoption",
    summary: "When the FBI closes in, Matilda's parents prepare to flee the country and readily agree to let Miss Honey adopt Matilda, showing their willingness to abandon their daughter without hesitation."
  }
];


const theBreakfastClubTriggerWarnings = [
  {
    startTime: 1107, // 18:27
    endTime: 1127, // 18:47
    warning: "Verbal Abuse + Intimidation",
    summary: "Principal Vernon aggressively confronts the students in the library, using his authority to intimidate and belittle them while establishing the oppressive atmosphere of their detention."
  },
  {
    startTime: 1400, // 23:20
    endTime: 1430, // 23:50
    warning: "Authority Abuse + Intimidation", 
    summary: "Principal Vernon threatens the students with additional detention time and uses his position of power to psychologically pressure them into submission."
  },
  {
    startTime: 1722, // 28:42
    endTime: 1755, // 29:15
    warning: "Physical Confrontation + Intimidation",
    summary: "Bender physically challenges another student's authority in the classroom, creating tension through aggressive posturing and confrontational behavior."
  },
  {
    startTime: 2080, // 34:40
    endTime: 2115, // 35:15
    warning: "Verbal Confrontation + Aggression",
    summary: "Students engage in heated verbal exchanges that escalate into personal attacks, with characters using harsh language to defend themselves and attack others."
  },
  {
    startTime: 2526, // 42:06
    endTime: 2565, // 42:45
    warning: "Harassment + Verbal Abuse",
    summary: "Bender makes inappropriate and harassing comments toward Claire, using crude language and sexual innuendo to make her uncomfortable and assert dominance."
  },
  {
    startTime: 2850, // 47:30
    endTime: 2875, // 47:55
    warning: "Confrontation + Threats",
    summary: "Principal Vernon and Bender engage in a power struggle where Vernon makes implicit threats about Bender's future while Bender challenges his authority."
  },
  {
    startTime: 3080, // 51:20
    endTime: 3110, // 51:50
    warning: "Physical Intimidation + Threats",
    summary: "The confrontation between Vernon and Bender escalates to physical intimidation, with Vernon using his size and position to threaten the student."
  },
  {
    startTime: 3195, // 53:15
    endTime: 3250, // 54:10
    warning: "Verbal Abuse + Psychological Manipulation",
    summary: "Vernon verbally attacks Bender's character and background, using psychological tactics to break down the student's defenses and self-worth."
  },
  {
    startTime: 3422, // 57:02
    endTime: 3455, // 57:35
    warning: "Domestic Violence Discussion",
    summary: "Bender reveals details about physical abuse at home, describing violent encounters with his father that have shaped his rebellious and defensive behavior."
  },
  {
    startTime: 3640, // 1:00:40
    endTime: 3680, // 1:01:20
    warning: "Parental Abuse + Trauma Discussion",
    summary: "Bender provides graphic details about abuse he suffers at home, including physical violence from his father, revealing the source of his anger and behavioral issues."
  },
  {
    startTime: 3860, // 1:04:20
    endTime: 3900, // 1:05:00
    warning: "Emotional Abuse + Family Dysfunction",
    summary: "Andrew describes the intense pressure from his father to win at all costs, revealing emotional manipulation and the psychological damage caused by unrealistic parental expectations."
  },
  {
    startTime: 4082, // 1:08:02
    endTime: 4115, // 1:08:35
    warning: "Bullying + Physical Violence",
    summary: "Andrew confesses to severely bullying another student by taping his buttocks together while the victim begged for mercy, showing the cycle of abuse and peer violence."
  },
  {
    startTime: 4190, // 1:09:50
    endTime: 4225, // 1:10:25
    warning: "Victim Trauma + Humiliation",
    summary: "Andrew describes the aftermath of his bullying incident, detailing how the victim was left humiliated and traumatized, highlighting the lasting impact of peer abuse."
  },
  {
    startTime: 4520, // 1:15:20
    endTime: 4560, // 1:16:00
    warning: "Suicidal Ideation + Self-Harm",
    summary: "Brian reveals he brought a gun to school with suicidal intentions after receiving his first failing grade, showing the extreme pressure he faces to maintain perfect academic performance."
  },
  {
    startTime: 4685, // 1:18:05
    endTime: 4730, // 1:18:50
    warning: "Mental Health Crisis + Academic Pressure",
    summary: "Brian breaks down emotionally while explaining how academic failure led him to contemplate suicide, revealing the devastating impact of perfectionist expectations on student mental health."
  },
  {
    startTime: 4832, // 1:20:32
    endTime: 4862, // 1:20:52
    warning: "Parental Neglect + Emotional Abuse",
    summary: "Allison describes her dysfunctional home life where her parents ignore her existence, leading her to act out with compulsive lying and attention-seeking behaviors."
  },
  {
    startTime: 4925, // 1:22:05
    endTime: 4954, // 1:22:34
    warning: "Identity Crisis + Self-Harm Discussion",
    summary: "Allison reveals she engages in self-destructive behaviors and compulsive lying as coping mechanisms for feeling invisible and unloved at home."
  },
  {
    startTime: 5040, // 1:24:00
    endTime: 5080, // 1:24:40
    warning: "Emotional Breakdown + Vulnerability",
    summary: "Claire breaks down and admits to the social pressures she faces to maintain her popular image, revealing the emotional cost of trying to meet everyone's expectations."
  },
  {
    startTime: 5245, // 1:27:25
    endTime: 5280, // 1:28:00
    warning: "Social Pressure + Identity Struggle",
    summary: "Claire describes the impossible standards she must maintain to keep her social status, highlighting how peer pressure and societal expectations damage self-worth and authentic relationships."
  },
  {
    startTime: 5374, // 1:29:34
    endTime: 5407, // 1:30:07
    warning: "Social Rejection + Future Anxiety",
    summary: "The students confront the reality that their bond may not survive returning to their separate social groups on Monday, facing the painful truth about social hierarchies and peer pressure."
  }
];

const singTriggerWarnings = [
  {
    startTime: 75, // 1:15
    endTime: 138, // 2:18
    warning: "Performance Anxiety",
    summary: "Young Buster Moon falls in love with theater after watching a performance as a child, but the narrator hints at his future struggles and failures in the entertainment industry, setting up themes of dreams versus harsh reality."
  },
  {
    startTime: 183, // 3:03
    endTime: 241, // 4:01
    warning: "Financial Stress + Workplace Harassment",
    summary: "Buster Moon faces angry creditors and unpaid stage crew members pounding on his door, while his secretary Miss Crawly tries to manage calls from the bank about bounced paychecks, showing severe financial distress."
  },
  {
    startTime: 301, // 5:01
    endTime: 361, // 6:01
    warning: "Criminal Activity + Family Pressure",
    summary: "Johnny participates in a robbery with his father Big Daddy's gang, showing conflict between his criminal family obligations and his secret passion for music, while police sirens wail in pursuit."
  },
  {
    startTime: 368, // 6:08
    endTime: 434, // 7:14
    warning: "Domestic Overwhelm + Gender Roles",
    summary: "Rosita struggles as an overworked mother of 25 piglets, dealing with household chaos while her husband Norman dismisses her singing abilities and ignores her dreams, highlighting domestic isolation."
  },
  {
    startTime: 462, // 7:42
    endTime: 522, // 8:42
    warning: "Creative Suppression + Relationship Control",
    summary: "Ash's boyfriend Lance criticizes her singing and tells her to stick to backing vocals only, showing controlling behavior that stifles her artistic expression and individual talent."
  },
  {
    startTime: 528, // 8:48
    endTime: 576, // 9:36
    warning: "Social Anxiety + Family Pressure",
    summary: "Meena celebrates her birthday with her family, but her grandfather pressures her to overcome her shyness and join a choir or band, while she struggles with severe stage fright despite her incredible voice."
  },
  {
    startTime: 586, // 9:46
    endTime: 718, // 11:58
    warning: "Confrontation + Public Humiliation",
    summary: "Mike the mouse aggressively confronts a street performer about payment, creates a public scene by searching his belongings, and calls him a liar in front of onlookers, showing Mike's volatile and confrontational personality."
  },
  {
    startTime: 1380, // 23:00
    endTime: 1425, // 23:45
    warning: "Explosive Incident + Property Damage",
    summary: "A bomb or explosive device detonates near where Buster and Eddie are staying, followed by a vehicle quickly leaving the scene, demonstrating violent resistance to Buster's theater plans."
  },
  {
    startTime: 1629, // 27:09
    endTime: 1674, // 27:54
    warning: "Criminal Planning + Family Crime",
    summary: "Big Daddy reveals a detailed heist plan to steal $25 million in gold from a ship, assigning Johnny as the getaway driver for what he calls 'the last job we ever need to do,' pressuring Johnny into deeper criminal involvement."
  },
  {
    startTime: 1681, // 28:01
    endTime: 1736, // 28:56
    warning: "Childcare Crisis + Abandonment",
    summary: "Rosita desperately tries to find a nanny for her 25 children so she can pursue her dreams, but potential caregivers hang up when they learn about the number of kids, leaving her feeling trapped and unsupported."
  },
  {
    startTime: 1920, // 32:00
    endTime: 1980, // 33:00
    warning: "Power Outage + Technical Crisis",
    summary: "The theater loses power during rehearsals because Buster hasn't paid the electric bill, forcing the performers to practice in darkness with only glow sticks, highlighting the theater's desperate financial situation."
  },
  {
    startTime: 2086, // 34:46
    endTime: 2147, // 35:47
    warning: "Performance Pressure + Stage Fright",
    summary: "Meena attempts to audition but becomes paralyzed by stage fright, unable to sing despite the music playing, while Mike impatiently criticizes her and calls her useless, showing the cruelty of performance pressure."
  },
  {
    startTime: 2527, // 42:07
    endTime: 2584, // 43:04
    warning: "Infidelity + Relationship Betrayal",
    summary: "Ash returns home to find her boyfriend Lance with another porcupine named Becky, discovering his infidelity and realizing he's replaced her both personally and professionally while she was working on her dreams."
  },
  {
    startTime: 2779, // 46:19
    endTime: 2845, // 47:25
    warning: "Gambling + Criminal Threats",
    summary: "Mike cheats at cards in a high-stakes game with dangerous bears, getting caught with hidden cards and forced to flee when the criminal bears threaten him, showing the consequences of his dishonest behavior."
  },
  {
    startTime: 3431, // 57:11
    endTime: 3492, // 58:12
    warning: "Family Disappointment + Criminal Conflict",
    summary: "Johnny confesses to his imprisoned father Big Daddy that he wants to be a singer instead of a criminal, leading to his father's complete rejection and disowning him, saying he's 'nothing like me and never will be.'"
  },
  {
    startTime: 3893, // 64:53
    endTime: 3950, // 65:50
    warning: "Emotional Breakdown + Performance Failure",
    summary: "Ash breaks down crying during rehearsal while wearing the pop princess costume, unable to perform the assigned song after discovering Lance's betrayal, showing her emotional devastation and loss of confidence."
  },
  {
    startTime: 4020, // 67:00
    endTime: 4080, // 68:00
    warning: "Violence + Criminal Threats",
    summary: "The criminal bears break into the theater looking for Mike and their money, confronting Buster aggressively and threatening violence when they discover the prize money is fake, escalating to property destruction."
  },
  {
    startTime: 4080, // 68:00
    endTime: 4200, // 70:00
    warning: "Catastrophic Flood + Building Collapse",
    summary: "The glass water tank cracks and explodes, causing massive flooding that destroys the theater completely. Characters scream and flee as the building collapses around them, with Buster desperately trying to save his father's legacy."
  },
  {
    startTime: 4668, // 77:48
    endTime: 4728, // 78:48
    warning: "Dreams Crushed + Depression",
    summary: "Buster falls into deep depression after losing the theater, calling himself and Meena 'fools' for believing in their dreams, telling her they 'don't have what it takes' and crushing her hopes of performing."
  },
  {
    startTime: 4965, // 82:45
    endTime: 5036, // 83:56
    warning: "Chase Scene + Criminal Pursuit",
    summary: "Mike is chased through the city by the vengeful criminal bears who want their money, leading to a dangerous pursuit through traffic and buildings as Mike desperately tries to escape their violent retribution."
  }
];

const allQuietOnTheWesternFrontTriggerWarnings = [
  {
    startTime: 242, // 4:02
    endTime: 302, // 5:02
    warning: "War Violence + Death",
    summary: "Intense World War I battle sequence showing machine gun fire, explosions, and soldiers screaming in combat. Paul Baumer and his classmates experience their first taste of brutal trench warfare with casualties and violence."
  },
  {
    startTime: 378, // 6:18
    endTime: 482, // 8:02
    warning: "Injury + Medical Trauma",
    summary: "Franz Kemmerich is wounded in battle with a serious leg injury. Paul and Albert help carry him to safety while he screams in pain, showing the immediate aftermath of battlefield injuries."
  },
  {
    startTime: 554, // 9:14
    endTime: 627, // 10:27
    warning: "Military Propaganda + Nationalism",
    summary: "A teacher delivers an intense patriotic speech to young students about serving the Kaiser and Fatherland, using rhetoric about Iron Youth becoming Iron Heroes and pressuring them to see military service as their sacred duty."
  },
  {
    startTime: 780, // 13:00
    endTime: 840, // 14:00
    warning: "Military Pressure + Peer Influence",
    summary: "Students celebrate graduation while their teacher pressures Paul Baumer about enlisting, emphasizing duty to the Fatherland and making it clear the entire class is expected to serve together as 'one man.'"
  },
  {
    startTime: 1020, // 17:00
    endTime: 1084, // 18:04
    warning: "Medical Trauma + Amputation",
    summary: "Paul visits Franz Kemmerich in the hospital, where Franz complains of pain in his amputated leg. The conversation reveals the extent of his injury while he remains in denial about his condition."
  },
  {
    startTime: 1197, // 19:57
    endTime: 1280, // 21:20
    warning: "Death + Grief",
    summary: "Franz Kemmerich dies in the hospital after giving his boots to Müller. Paul desperately calls for a doctor, but medical staff treat the death matter-of-factly, mentioning it's the seventeenth death that day."
  },
  {
    startTime: 1680, // 28:00
    endTime: 1748, // 29:08
    warning: "Alcohol Use + Military Culture",
    summary: "Himmelstoss reveals he's been called to active duty while the young men celebrate with drinking and singing. The scene shows the culture of alcohol consumption as they prepare to leave for war."
  },
  {
    startTime: 1923, // 32:03
    endTime: 2387, // 39:47
    warning: "Military Abuse + Hazing",
    summary: "Corporal Himmelstoss subjects the new recruits to brutal and repetitive military training exercises, including crawling through mud and exhausting drills, establishing his sadistic control over the young soldiers."
  },
  {
    startTime: 2503, // 41:43
    endTime: 2566, // 42:46
    warning: "Violence + Revenge",
    summary: "The soldiers get revenge on Himmelstoss by beating him while he's drunk, showing the cycle of abuse and violence that military training has created among the men."
  },
  {
    startTime: 2880, // 48:00
    endTime: 2970, // 49:30
    warning: "Animal Cruelty + War Trauma",
    summary: "Wounded horses scream in agony after an artillery attack. Soldiers struggle to shoot the suffering animals while Detering becomes emotionally distraught, crying about the wrongness of using horses in war."
  },
  {
    startTime: 3301, // 55:01
    endTime: 3409, // 56:49
    warning: "Gas Attack + Chemical Warfare",
    summary: "Soldiers experience a poison gas attack, frantically putting on gas masks while Paul narrates about the horrific effects of gas weapons, including patients coughing up their burnt lungs in hospitals."
  },
  {
    startTime: 3420, // 57:00
    endTime: 3540, // 59:00
    warning: "Death + Child Soldiers",
    summary: "New young recruits die because of their inexperience, with Paul noting that five to ten new soldiers die for every veteran. A young recruit dies, and Paul observes he was 'just a baby.'"
  },
  {
    startTime: 4500, // 1:15:00
    endTime: 4620, // 1:17:00
    warning: "Hand-to-Hand Combat + Killing",
    summary: "Paul becomes trapped in a shell crater with a French soldier and stabs him with a knife. The French soldier dies slowly while Paul watches, creating an intimate and traumatic killing experience."
  },
  {
    startTime: 4680, // 1:18:00
    endTime: 4890, // 1:21:30
    warning: "Guilt + Remorse",
    summary: "Paul talks to the dying French soldier Gerard Duval, expressing guilt and remorse about killing him. He promises to write to the man's family and reflects on their shared humanity and the horror of war."
  },
  {
    startTime: 5400, // 1:30:00
    endTime: 5460, // 1:31:00
    warning: "Parental Grief + Blame",
    summary: "Mrs. Kemmerich confronts Paul about her son's death, asking why Paul is alive when Franz is dead. She demands the truth about how Franz died, creating intense emotional pressure and guilt."
  },
  {
    startTime: 6120, // 1:42:00
    endTime: 6360, // 1:46:00
    warning: "Intimacy + War Relief",
    summary: "Paul and other soldiers spend time with French women, seeking emotional and physical comfort. The scene shows soldiers trying to find human connection and tenderness amid the brutality of war."
  },
  {
    startTime: 6540, // 1:49:00
    endTime: 6660, // 1:51:00
    warning: "Severe Injury + Medical Treatment",
    summary: "Paul and Albert are wounded and taken to a Catholic hospital. The scene shows the medical realities of war injuries and the hospital's efficiency in processing wounded and dying soldiers."
  },
  {
    startTime: 7080, // 1:58:00
    endTime: 7200, // 2:00:00
    warning: "Depression + Suicidal Ideation",
    summary: "Albert asks Paul to get him a gun, expressing his desire to end his life rather than live with his amputation. The conversation reveals the psychological trauma and despair of wounded soldiers."
  },
  {
    startTime: 7920, // 2:12:00
    endTime: 8040, // 2:14:00
    warning: "Family Illness + Emotional Distress",
    summary: "Paul returns home to find his mother seriously ill with cancer. The family tries to maintain normalcy while dealing with her deteriorating condition and Paul's traumatic war experiences."
  },
  {
    startTime: 8940, // 2:29:00
    endTime: 9000, // 2:30:00
    warning: "Death of Friend + Final Loss",
    summary: "Kat dies from a head wound while Paul carries him to safety, not realizing his friend has been killed by shrapnel. Paul discovers Kat is dead when they reach the medical station, representing the final loss of his closest companion."
  }
];

const talkToMeTriggerWarnings = [
  {
    startTime: 0, // 0:00
    endTime: 58, // 0:58
    warning: "Violence + Knife Threats",
    summary: "Duckett becomes increasingly agitated at a party, eventually threatening people with a knife while claiming to see things others cannot, creating a dangerous situation that ends with people fleeing."
  },
  {
    startTime: 181, // 3:01
    endTime: 243, // 4:03
    warning: "Death Discussion + Grief",
    summary: "The film opens with Mia dealing with painful reminders of loss, including having her deceased mother's contact information still saved in her phone, highlighting ongoing grief and the difficulty of letting go."
  },
  {
    startTime: 396, // 6:36
    endTime: 492, // 8:12
    warning: "Animal Death + Euthanasia",
    summary: "Mia and Riley encounter a severely injured kangaroo on the roadside. After debating whether to call for help, Mia makes the difficult decision to end the animal's suffering, showing the moral complexity of mercy killing."
  },
  {
    startTime: 642, // 10:42
    endTime: 687, // 11:27
    warning: "Grief + Death Anniversary",
    summary: "Mia reveals it's the second anniversary of her mother's death, expressing her ongoing struggle with grief and her complicated relationship with her father following the loss."
  },
  {
    startTime: 828, // 13:48
    endTime: 888, // 14:48
    warning: "Supernatural Ritual + Occult Activity",
    summary: "The group prepares to use an embalmed hand for a supernatural ritual, with detailed explanation of the dangerous rules including the critical 90-second time limit to prevent permanent possession."
  },
  {
    startTime: 1086, // 18:06
    endTime: 1200, // 20:00
    warning: "Supernatural Possession + Disturbing Behavior",
    summary: "Mia undergoes her first possession experience, with an unknown spirit taking control of her body. She speaks in an altered voice and exhibits disturbing behavior while her friends time the dangerous ritual."
  },
  {
    startTime: 1272, // 21:12
    endTime: 1398, // 23:18
    warning: "Violent Threats + Supernatural Aggression",
    summary: "During a second possession, the malevolent spirit controlling Mia becomes increasingly violent, making graphic threats about tearing people apart while her body convulses unnaturally."
  },
  {
    startTime: 1620, // 27:00
    endTime: 1680, // 28:00
    warning: "Grief Manipulation + False Comfort",
    summary: "Mia communicates with what she believes is her deceased mother through the supernatural ritual, receiving emotional comfort that may be manipulation by malevolent spirits exploiting her grief."
  },
  {
    startTime: 1908, // 31:48
    endTime: 2034, // 33:54
    warning: "Child Manipulation + Supernatural Deception",
    summary: "Young Riley is manipulated into participating in the supernatural ritual, with the entity pretending to be Mia's mother and expressing false love and pride to maintain emotional control over him."
  },
  {
    startTime: 2034, // 33:54
    endTime: 2244, // 37:24
    warning: "Child Possession + Supernatural Horror",
    summary: "Riley becomes possessed by a malevolent spirit during the ritual. The possession goes dangerously over the 90-second limit as the entity takes control of the young boy's body and refuses to leave."
  },
  {
    startTime: 2646, // 44:06
    endTime: 2766, // 46:06
    warning: "Self-Harm + Violent Injury",
    summary: "Riley, while under supernatural influence, violently injures himself by repeatedly slamming his head and body against hard surfaces, causing severe physical trauma while the spirit maintains control."
  },
  {
    startTime: 2784, // 46:24
    endTime: 2844, // 47:24
    warning: "Medical Emergency + Child Trauma",
    summary: "Riley is hospitalized in critical condition following his supernatural possession and self-inflicted injuries, with medical staff struggling to treat his severe wounds while his family faces the traumatic aftermath."
  },
  {
    startTime: 3276, // 54:36
    endTime: 3336, // 55:36
    warning: "Supernatural Hallucinations + Psychological Horror",
    summary: "Mia begins experiencing disturbing supernatural encounters in her daily life, with apparitions of her deceased mother appearing and attempting to communicate, blurring reality and hallucination."
  },
  {
    startTime: 3576, // 59:36
    endTime: 3696, // 1:01:36
    warning: "Family Secrets + Emotional Trauma",
    summary: "Mia's father reveals a devastating truth through her mother's final letter, disclosing that her death was intentional suicide rather than accidental, completely shattering Mia's understanding of her loss."
  },
  {
    startTime: 3936, // 1:05:36
    endTime: 4056, // 1:07:36
    warning: "Suicide Discussion + Mental Health",
    summary: "The revelation of the mother's suicide note forces Mia and her father to confront the painful reality of mental illness and intentional self-harm, adding layers of guilt and trauma to their grief."
  },
  {
    startTime: 4356, // 1:12:36
    endTime: 4476, // 1:14:36
    warning: "Supernatural Manipulation + False Guidance",
    summary: "Mia encounters what appears to be her mother's spirit, but the entity manipulates her emotions and provides dangerous guidance, suggesting that ending Riley's life would be merciful."
  },
  {
    startTime: 4656, // 1:17:36
    endTime: 4776, // 1:19:36
    warning: "Child Endangerment + Supernatural Influence",
    summary: "Under supernatural manipulation, Mia begins to believe that Riley would be better off dead, setting up a dangerous situation where she might harm the hospitalized child."
  },
  {
    startTime: 4776, // 1:19:36
    endTime: 4896, // 1:21:36
    warning: "Attempted Murder + Child Harm",
    summary: "Mia, influenced by malevolent spirits, attempts to suffocate Riley with a pillow in his hospital bed, believing she is ending his supernatural torment while actually trying to kill him."
  },
  {
    startTime: 4896, // 1:21:36
    endTime: 4956, // 1:22:36
    warning: "Violence + Physical Confrontation",
    summary: "Hospital staff and Riley's family intervene to stop Mia's attack on Riley, leading to a violent confrontation as they try to protect the injured child from further harm."
  },
  {
    startTime: 4956, // 1:22:36
    endTime: 5016, // 1:23:36
    warning: "Death + Tragic Consequences",
    summary: "The film reaches its tragic climax as the supernatural forces claim their ultimate victim, demonstrating the deadly price of dabbling with occult rituals and the embalmed hand's curse."
  }
];

const americanGangsterTriggerWarnings = [
  {
    startTime: 108, // 1:48
    endTime: 255, // 4:15
    warning: "Violence + Death",
    summary: "Bumpy Johnson, Frank Lucas's mentor and boss, collapses and dies suddenly in a store while discussing business philosophy with Frank, marking the end of an era in Harlem's criminal hierarchy."
  },
  {
    startTime: 255, // 4:15
    endTime: 315, // 5:15
    warning: "Grief + Funeral",
    summary: "Bumpy Johnson's funeral attracts major crime figures and politicians, with news coverage highlighting his complex legacy as both a folk hero and ruthless criminal in Harlem."
  },
  {
    startTime: 437, // 7:17
    endTime: 527, // 8:47
    warning: "Violence + Shooting",
    summary: "Detective Jay shoots and kills a drug dealer during an undercover operation that goes wrong, leading to a violent confrontation and Jay calling Richie Roberts for help covering up the incident."
  },
  {
    startTime: 724, // 12:04
    endTime: 987, // 16:27
    warning: "Drug Money + Police Corruption",
    summary: "Richie Roberts and his partner discover nearly $1 million in cash during a drug bust, leading to intense debate about whether to keep the money or turn it in, highlighting police corruption temptations."
  },
  {
    startTime: 1138, // 18:58
    endTime: 1218, // 20:18
    warning: "Violence + Intimidation",
    summary: "Tango Black attempts to extort Frank Lucas for 20% of his drug profits, using threats and intimidation while claiming control over Harlem territory previously controlled by Bumpy Johnson."
  },
  {
    startTime: 1704, // 28:24
    endTime: 1764, // 29:24
    warning: "Drug Trade + International Crime",
    summary: "Frank Lucas travels to Southeast Asia to establish a direct heroin supply chain, meeting with dangerous drug suppliers in the Golden Triangle region during the Vietnam War."
  },
  {
    startTime: 1845, // 30:45
    endTime: 1925, // 32:05
    warning: "Drug Smuggling + Military Involvement",
    summary: "Frank arranges to smuggle pure heroin from Vietnam using military transport planes and personnel, exploiting the chaos of war to establish his drug empire with his cousin Nate's help."
  },
  {
    startTime: 1980, // 33:00
    endTime: 2100, // 35:00
    warning: "Police Shooting + Cover-up",
    summary: "Jay calls Richie for help after shooting a drug dealer, and they stage an elaborate cover-up involving faking the victim's survival to avoid a riot, demonstrating police corruption and violence."
  },
  {
    startTime: 2340, // 39:00
    endTime: 2430, // 40:30
    warning: "Drug Manufacturing + Distribution",
    summary: "Frank establishes his Blue Magic heroin operation with higher purity than competitors, using his brothers and cousins as distributors while maintaining strict quality control over his product."
  },
  {
    startTime: 3226, // 53:46
    endTime: 3316, // 55:16
    warning: "Execution + Public Violence",
    summary: "Frank Lucas shoots and kills Tango Black in broad daylight in front of multiple witnesses, demonstrating his willingness to use extreme violence to maintain control over his territory."
  },
  {
    startTime: 3720, // 62:00
    endTime: 3810, // 63:30
    warning: "Drug Overdose + Addiction",
    summary: "The devastating effects of Frank's pure heroin are shown through users overdosing and dying from the potent Blue Magic brand, highlighting the deadly consequences of the drug trade."
  },
  {
    startTime: 4320, // 72:00
    endTime: 4410, // 73:30
    warning: "Family Separation + Legal Issues",
    summary: "Richie Roberts faces custody battle and family separation due to his dangerous job and lifestyle, with his ex-wife and child moving away because of safety concerns related to his police work."
  },
  {
    startTime: 4680, // 78:00
    endTime: 4770, // 79:30
    warning: "Domestic Violence + Family Conflict",
    summary: "Frank becomes increasingly paranoid and violent, threatening family members and associates while struggling to maintain control over his expanding criminal empire as law enforcement closes in."
  },
  {
    startTime: 5400, // 90:00
    endTime: 5490, // 91:30
    warning: "Police Corruption + Bribery",
    summary: "Corrupt Detective Trupo demands regular payments from Frank Lucas, representing the widespread police corruption that allows the drug trade to flourish while honest cops like Richie face isolation."
  },
  {
    startTime: 6120, // 102:00
    endTime: 6210, // 103:30
    warning: "Violence + Assassination Attempt",
    summary: "Frank's car is shot up in an assassination attempt, likely by rival dealers or the Corsican mob he's put out of business, forcing him to realize the dangerous enemies his success has created."
  },
  {
    startTime: 6600, // 110:00
    endTime: 6690, // 111:30
    warning: "Drug Manufacturing + Criminal Operation",
    summary: "Law enforcement discovers Frank's sophisticated heroin processing operation hidden in military coffins, revealing the full scope of his international drug smuggling network using Vietnam War casualties."
  },
  {
    startTime: 7320, // 122:00
    endTime: 7410, // 123:30
    warning: "Police Raid + Violence",
    summary: "Richie Roberts leads a massive coordinated raid on Frank's drug operation, resulting in armed confrontations, arrests of Frank's family members, and the dismantling of his criminal empire."
  },
  {
    startTime: 7980, // 133:00
    endTime: 8070, // 134:30
    warning: "Arrest + Family Impact",
    summary: "Frank Lucas is arrested at his mother's church, with law enforcement taking him into custody while his family watches, showing how his criminal activities ultimately destroy his personal relationships."
  },
  {
    startTime: 8580, // 143:00
    endTime: 8670, // 144:30
    warning: "Cooperation + Betrayal",
    summary: "Frank agrees to cooperate with law enforcement, providing information about corrupt police officers and organized crime figures in exchange for a reduced sentence, betraying former associates."
  },
  {
    startTime: 9300, // 155:00
    endTime: 9450, // 157:30
    warning: "Prison Release + Aftermath",
    summary: "Frank is released from prison after serving his sentence and cooperating with authorities, facing an uncertain future as he attempts to rebuild his life while reflecting on the consequences of his choices."
  }
];

// Store all advertisement image paths
const advertisementImages = [
  '/assets/images/advertisment_1.png',
  '/assets/images/advertisment_2.png',
  '/assets/images/advertisment_3.png',
];

let video;
let currentWarning = null;
let timerInterval;
let enabledWarnings = [];
let previewTimer = 10; // Default preview timer (10 seconds)
let positionSetting = 'top-right'; // Default position for the popup
let isActive = true; // Default to active
let isPaused = false; // To track the paused state of the video
let remainingTime; // Declare remainingTime at the top level



function findVideoElement() {
  // Locate video by specific ID
  let video = document.querySelector(`[id="7ad170e3-cd6a-42f0-a8d0-38598eb1e587"]`);
  if (video && video.style.display !== "none") return video;

  // Directly target the `hivePlayer` ID if available
  video = document.getElementById("hivePlayer");
  if (video && video.style.display !== "none") return video;

  // Generic fallback for video elements
  video = document.querySelector("video:not([style*='display: none'])");
  if (video) return video;

  // Check for video inside iframes
  const iframes = document.querySelectorAll("iframe");
  for (let i = 0; i < iframes.length; i++) {
    try {
      const iframeDoc = iframes[i].contentDocument || iframes[i].contentWindow.document;
      video = iframeDoc.querySelector("video:not([style*='display: none'])");
      if (video) return video;
    } catch (error) {
      console.warn("Unable to access iframe content:", error);
    }
  }

  // Check for video in shadow DOMs
  const shadowRoots = document.querySelectorAll("*");
  for (let i = 0; i < shadowRoots.length; i++) {
    try {
      if (shadowRoots[i].shadowRoot) {
        video = shadowRoots[i].shadowRoot.querySelector("video:not([style*='display: none'])");
        if (video) return video;
      }
    } catch (error) {
      console.warn("Error accessing shadow DOM:", error);
    }
  }

  return null; // Return null if no video element is found
}

function initialize() {
  // Load settings from storage
  chrome.storage.sync.get(['triggerWarnings', 'customWarnings', 'previewTimer', 'positionSetting', 'isActivated'], (data) => {
    if (data.triggerWarnings) {
      enabledWarnings = data.triggerWarnings;
    }
    if (data.customWarnings) {
      enabledWarnings = enabledWarnings.concat(data.customWarnings);
    }
    if (data.previewTimer) {
      previewTimer = data.previewTimer; // Update preview timer based on user setting
    }
    if (data.positionSetting) {
      positionSetting = data.positionSetting; // Update position based on user setting
    }
    if (typeof data.isActivated !== 'undefined') {
      isActive = data.isActivated; // Update the activation status based on user setting
    }
    

    // Check if we are on the Criminal Minds S01E01 episode page
    if (window.location.href.includes("vZ3WjUR9fks0d0fZHpqVrJonvIQ2V58O")) {
      triggerWarnings = criminalMindsS1E1TriggerWarnings;
    } 
    // Check if we are on the Inside Out movie page on Disney Plus (same pattern for below movies)
    else if (window.location.href.includes("d4b87168-7d0b-49bc-b138-457ab7723feb")) {
      triggerWarnings = insideOutTriggerWarnings;
    } 

    else if (window.location.href.includes("81609393")) {
      triggerWarnings = TheMenuTriggerWarnings;
    } 

    else if (window.location.href.includes("80157969")) {
      triggerWarnings = barbieTriggerWarnings;
    } 

    else if (window.location.href.includes("pJTmThcDOcg")) {
      triggerWarnings = mississippiBurningTriggerWarnings;
    } 

    else if (window.location.href.includes("80238910")) {
      triggerWarnings = HereditaryTriggerWarnings;
    } 

    else if (window.location.href.includes("80095314")) {
      triggerWarnings =  theSecretLifeOfPetsTriggerWarnings;
    } 

    else if (window.location.href.includes("ttPi99BJpIg")) {
      triggerWarnings = eternalSunshineOfTheSpotlessMindTriggerWarnings;
    } 

    else if (window.location.href.includes("70299275")) {
      triggerWarnings = whiplashTriggerWarnings;
    }

    else if (window.location.href.includes("81476963")) {
      triggerWarnings = CarryOnTriggerWarnings;
    }

    else if (window.location.href.includes("81776693")) {
      triggerWarnings = despicableMeTriggerWarnings;
    }

    else if (window.location.href.includes("70109893")) {
      triggerWarnings = HowToTrainYourDragonTriggerWarnings;
    }

    else if (window.location.href.includes("ptrCBlS6cw4")) {
      triggerWarnings = theSubstituteTriggerWarnings;
    }

    else if (window.location.href.includes("80177770")) {
      triggerWarnings = ITTriggerWarnings;
    }

    else if (window.location.href.includes("60036359")) {
      triggerWarnings = schindlersListTriggerWarnings;
    }

    else if (window.location.href.includes("81728818")) {
      triggerWarnings = womanOfTheHourTriggerWarnings;
    }

    else if (window.location.href.includes("70300205")) {
      triggerWarnings = babadook2014TriggerWarnings;
    }

    else if (window.location.href.includes("70033005")) {
      triggerWarnings = matildaTriggerWarnings;
    }

    else if (window.location.href.includes("330210")) {
      triggerWarnings = theBreakfastClubTriggerWarnings;
    }

    else if (window.location.href.includes("80117526")) {
      triggerWarnings = singTriggerWarnings;
    }

    else if (window.location.href.includes("81260280")) {
      triggerWarnings = allQuietOnTheWesternFrontTriggerWarnings;
    }

    else if (window.location.href.includes("81700507")) {
      triggerWarnings = talkToMeTriggerWarnings;
    }

    else if (window.location.href.includes("70060009")) {
      triggerWarnings = americanGangsterTriggerWarnings;
    }

    else {
      triggerWarnings = []; // Add trigger warnings here for other shows or fallback cases if needed
    }

    const intervalId = setInterval(() => {
      video = findVideoElement();
      if (video) {
        clearInterval(intervalId);
        video.addEventListener('timeupdate', onTimeUpdate);
        video.addEventListener('pause', onVideoPause);
        video.addEventListener('play', onVideoPlay);
        console.log("Video element found:", video);
      } else {
        console.log("Video element not found");
      }
    }, 1000);
  });
}

function onVideoPause() {
  isPaused = true;
  clearInterval(timerInterval); // Stop the countdown
}

function onVideoPlay() {
  isPaused = false;
  if (remainingTime > 0) {
    startTimer(remainingTime); // Resume the countdown with the remaining time
  }
}

function onTimeUpdate() {
  if (!isActive) return;

  let currentTime = Math.floor(video.currentTime);

  triggerWarnings.forEach((warning) => {
    let adjustedStartTime = warning.startTime;
    let adjustedEndTime = warning.endTime;

    if (window.location.hostname.includes("paramountplus.com")) {
      adjustedStartTime += 37.5;
      adjustedEndTime += 37.5;
    }

    let warningParts = warning.warning.split(" + ");

    if (warningParts.some(w => enabledWarnings.includes(w))) {
      if (currentTime === Math.floor(adjustedStartTime) - previewTimer) {
        if (!currentWarning || currentWarning.startTime !== warning.startTime) {
          showPopup(warning, adjustedEndTime);
          startTimer(previewTimer);
          remainingTime = previewTimer; // Set the initial remaining time
          currentWarning = warning;
        }
      } else if (currentTime >= adjustedStartTime && currentTime <= adjustedEndTime) {
        clearInterval(timerInterval);
      } else if (currentTime > adjustedEndTime && currentWarning === warning) {
        currentWarning = null;
      }
    }
  });
}


function showPopup(warning, adjustedEndTime) {
  if (!isActive) return; // Ensure no popup is shown if the extension is disabled

  let popup = document.createElement('div');
  popup.id = 'trigger-warning-popup';
  popup.style.position = 'fixed';

  // Apply the user-selected position
  switch (positionSetting) {
    case 'top-left':
      popup.style.top = '10px';
      popup.style.left = '10px';
      break;
    case 'top-right':
      popup.style.top = '10px';
      popup.style.right = '10px';
      break;
    case 'bottom-left':
      popup.style.bottom = '10px';
      popup.style.left = '10px';
      break;
    case 'bottom-right':
      popup.style.bottom = '10px';
      popup.style.right = '10px';
      break;
  }

  popup.style.backgroundColor = 'rgba(51, 78, 172, 1)';
  popup.style.color = 'white';
  popup.style.padding = '20px';
  popup.style.zIndex = '10000';
  popup.style.textAlign = 'center';
  popup.style.width = '500px';
  popup.style.borderRadius = '10px';

  let messageContainer = document.createElement('div');
  messageContainer.style.display = 'flex';
  messageContainer.style.justifyContent = 'space-between';
  messageContainer.style.alignItems = 'center';

  let viewButton = document.createElement('img');
  viewButton.src = chrome.runtime.getURL('/assets/images/view_button.png');
  viewButton.alt = 'View';
  viewButton.style.width = '160px';
  viewButton.style.height = 'auto';
  viewButton.style.cursor = 'pointer';
  viewButton.onclick = () => {
    // Show the relevant warning(s) when "View" is clicked
    message.innerHTML = generateWarningText(warning.warning);
  };

  let message = document.createElement('p');
  message.innerHTML = ''; // Initially show nothing here
  message.style.fontSize = '25px';
  message.style.marginBottom = '20px';

  let timer = document.createElement('p');
  timer.id = 'trigger-timer'; // Ensure this element is created with the popup
  timer.style.fontSize = '25px';
  timer.style.marginBottom = '20px';
  timer.textContent = `${previewTimer} seconds`;

  messageContainer.appendChild(viewButton);
  messageContainer.appendChild(message);
  messageContainer.appendChild(timer);
  popup.appendChild(messageContainer);

  let buttonContainer = document.createElement('div');
  buttonContainer.style.display = 'flex';
  buttonContainer.style.justifyContent = 'center';
  buttonContainer.style.alignItems = 'center';
  buttonContainer.style.marginTop = '10px';

  let skipButton = document.createElement('img');
  skipButton.src = chrome.runtime.getURL('/assets/images/skipit_logo.png');
  skipButton.alt = 'Skip It!';
  skipButton.style.width = '185px';
  skipButton.style.height = 'auto';
  skipButton.style.cursor = 'pointer';
  skipButton.style.marginRight = '10px';

  skipButton.onclick = () => {
    // Remove the original popup immediately when the skip button is clicked
    document.body.removeChild(popup);
  
    if (window.location.hostname.includes("netflix.com")) {
      try {
        // Function to find the video element and increase its playback rate
        const findFirstVideoTag = () => {
          var allVideos = document.getElementsByTagName("video");
          if (allVideos.length > 0) {
            return allVideos[0];
          } else {
            // Search for video elements inside iframes
            const frames = document.getElementsByTagName("iframe");
            for (let i = 0; i < frames.length; i++) {
              try {
                const childDocument = frames[i].contentDocument;
                const allVideosInFrame = childDocument.getElementsByTagName("video");
                if (allVideosInFrame.length > 0) {
                  return allVideosInFrame[0];
                }
              } catch (e) {
                continue; // Skip iframes we can't access
              }
            }
          }
          return null;
        };
  
        // Find the video element on Netflix and triple the speed
        const videoElement = findFirstVideoTag();
        if (videoElement) {
          // Increase playback speed here in the future if needed (this is recommended)
          videoElement.playbackRate = 16;
  
          // Create the blue semi-transparent popup
          const overlay = document.createElement('div');
          overlay.style.position = 'absolute';
          overlay.style.top = '0';
          overlay.style.left = '0';
          overlay.style.width = '100%';
          overlay.style.height = '100%';
          overlay.style.backgroundColor = 'rgba(0, 0, 255, 0.7)'; 
          overlay.style.display = 'flex';
          overlay.style.justifyContent = 'center';
          overlay.style.alignItems = 'center';
          overlay.style.zIndex = '9999';
          overlay.style.borderRadius = '10px'; // Rounded corners
          overlay.style.pointerEvents = 'none'; // Ensure the popup doesn't interfere with video interaction
  
          // Create the summary text
          const summaryText = document.createElement('div');
          summaryText.style.color = 'white';
          summaryText.style.fontSize = '25px';
          summaryText.style.fontWeight = 'bold';
          summaryText.style.textAlign = 'center';
          summaryText.textContent = warning.summary;
  
          // Append the summary text to the overlay
          overlay.appendChild(summaryText);
  
          // Append the overlay to the video element's parent container
          videoElement.parentNode.appendChild(overlay);
  
          // Check video time every 500ms to reset speed and display summary when it reaches the adjusted end time
          const intervalId = setInterval(() => {
            if (videoElement.currentTime >= adjustedEndTime) {
              videoElement.playbackRate = 1; // Reset playback speed to normal
              clearInterval(intervalId); // Stop the interval
  
              // Remove the overlay popup when the speed reset happens
              if (overlay && overlay.parentNode) {
                overlay.parentNode.removeChild(overlay);
              }
  
              showSummary(warning.summary); // Show summary of skipped content
            }
          }, 500); // Check every 500ms
        } else {
          console.error("No video element found.");
        }
  
      } catch (error) {
        console.error("Error speeding up Netflix video:", error);
      }
    } else {
      // Default behavior for non-Netflix videos
      video.currentTime = adjustedEndTime; // Use the adjusted end time
      showSummary(warning.summary);
    }
  };

  let playButton = document.createElement('img');
  playButton.src = chrome.runtime.getURL('/assets/images/play_button.png');
  playButton.alt = 'Play';
  playButton.style.width = '160px';
  playButton.style.height = 'auto';
  playButton.style.cursor = 'pointer';
  playButton.onclick = () => {
    document.body.removeChild(popup);
  };

  buttonContainer.appendChild(skipButton);
  buttonContainer.appendChild(playButton);

  popup.appendChild(buttonContainer);
  document.body.appendChild(popup); // Append the popup to the document

}

function generateWarningText(warning) {
  // Split the warning into its components
  let warningParts = warning.split(" + ");

  // Filter out the selected warning parts
  let selectedWarnings = warningParts.filter(part => enabledWarnings.includes(part));

  // Join the selected warnings with " + " and return with "Trigger Warning:" in bold
  return `<strong>Trigger Warning:</strong><br>${selectedWarnings.join("<br>")}`; 
}

function generateSummaryText(warning) {
  // Split the warning into its components
  let warningParts = warning.warning.split(" + ");
  let summaries = [];

  // Get summaries for each selected warning part
  warningParts.forEach(part => {
    if (enabledWarnings.includes(part)) {
      summaries.push(warning.summary); // This is ssuming warning.summary covers all combined cases, needs to be adjusted to include various
    }
  });

  return summaries.join("\n");
}

function startTimer(seconds) {
  remainingTime = seconds; // Initialize the remaining time
  timerInterval = setInterval(() => {
    if (isPaused) return; // Pause the countdown if the video is paused

    const timerElement = document.getElementById('trigger-timer');
    if (!timerElement) {
      clearInterval(timerInterval); // Stop the timer if the element is not found
      return;
    }

    if (remainingTime > 0) {
      timerElement.textContent = `${Math.floor(remainingTime)} seconds`;
      remainingTime -= 1;
    } else {
      clearInterval(timerInterval);
      timerElement.textContent = 'Trigger starting!';
    }
  }, 1000);
}

function showSummary(summary) {
  let summaryPopup = document.createElement('div');
  summaryPopup.id = 'summary-popup';
  summaryPopup.style.position = 'fixed';

  switch (positionSetting) {
    case "top-left":
      summaryPopup.style.top = "10px";
      summaryPopup.style.left = "10px";
      break;
    case "top-right":
      summaryPopup.style.top = "10px";
      summaryPopup.style.right = "10px";
      break;
    case "bottom-left":
      summaryPopup.style.bottom = "10px";
      summaryPopup.style.left = "10px";
      break;
    case "bottom-right":
      summaryPopup.style.bottom = "10px";
      summaryPopup.style.right = "10px";
      break;
    default:
      summaryPopup.style.top = "10px";
      summaryPopup.style.right = "10px";
  }

  summaryPopup.style.backgroundColor = 'rgba(39, 39, 202, 0.74)';
  summaryPopup.style.color = 'white';
  summaryPopup.style.padding = '40px';
  summaryPopup.style.zIndex = '10000';
  summaryPopup.style.textAlign = 'center';
  summaryPopup.style.width = '400px';
  summaryPopup.style.borderRadius = '10px';

  const summaryMessage = document.createElement('p');
  summaryMessage.textContent = summary;
  summaryMessage.style.fontSize = '24px';
  summaryMessage.style.marginBottom = '20px';
  summaryPopup.appendChild(summaryMessage);

  document.body.appendChild(summaryPopup);

  setTimeout(() => {
    document.body.removeChild(summaryPopup);
  }, 5000);
}

// Listen for position setting changes
document.querySelectorAll('.position-button').forEach((button) => {
  button.addEventListener('click', () => {
    document.querySelectorAll('.position-button').forEach((btn) => btn.classList.remove('active'));
    button.classList.add('active');
    positionSetting = button.id.replace('-button', '');
    chrome.storage.sync.set({ positionSetting });
  });
});

// Toggle Activation Switch
chrome.storage.sync.get('isActivated', (data) => {
  const intervalId = setInterval(() => {
    const activateSwitch = document.getElementById('activate-switch');
    if (activateSwitch) {
      clearInterval(intervalId); // Stop checking once the element is found

      isActive = data.isActivated !== false; // Default to true if not set
      activateSwitch.checked = isActive;

      activateSwitch.addEventListener('change', () => {
        isActive = activateSwitch.checked;
        chrome.storage.sync.set({ isActivated: isActive }, () => {
          if (isActive) {
            alert('SKIP IT. Enabled');
          } else {
            alert('SKIP IT. Disabled');
          }
        });
      });
    }
  }, 500); // Check every 500ms
});

initialize();