document.addEventListener('DOMContentLoaded', () => {
    // Load the theme and language settings from storage
    chrome.storage.sync.get('theme', (data) => {
        const theme = data.theme || 'dark'; // Default to dark mode
        if (theme === 'light') {
          document.body.classList.add('light-mode');
        } else {
          document.body.classList.remove('light-mode');
        }
    });
    
    // Load the language setting and initialize i18next
    chrome.storage.sync.get('language', (data) => {
        const language = data.language || 'en'; // Default to English
        if (typeof i18next !== 'undefined') {
            initializeI18Next(language);
        } else {
            console.error("i18next is not loaded");
        }
    });

    // Define the initializeI18Next function here
    function initializeI18Next(language) {
        i18next.init({
            lng: language,
            resources: {
                en: {
                    translation: {
                        "Dashboard": "Dashboard",
                        "Trigger Warning Settings": "Trigger Warning Settings",
                        "About": "About",
                        "Login": "Login",
                        "Get Help": "Get Help",
                        // pricing page
                        "Pricing Plans": "Pricing Plans",
                        "Back to Account": "Back to Account"
                    }
                },
                es: {
                    translation: {
                        "Dashboard": "Tablero",
                        "Trigger Warning Settings": "Configuración de Advertencias",
                        "About": "Acerca de",
                        "Login": "Iniciar Sesión",
                        "Get Help": "Obtener Ayuda",
                      
                        "Pricing Plans": "Planes de Precios",
                        "Back to Account": "Volver a la Cuenta"
                    }
                },
                fr: {
                    translation: {
                        "Dashboard": "Tableau de Bord",
                        "Trigger Warning Settings": "Paramètres d'Avertissement",
                        "About": "À Propos",
                        "Login": "Connexion",
                        "Get Help": "Obtenir de l'Aide",
                    
                        "Pricing Plans": "Plans Tarifaires",
                        "Back to Account": "Retour au Compte"
                    }
                }
            }
        }, () => {
            updateContent(); // Update content once i18next is initialized
        });
    }

    // Ensure Sidebar Highlighting for Login Page
    function highlightActiveSidebar() {
        const currentPath = window.location.pathname;
        document.querySelectorAll('.nav-items a, .bottom-links a').forEach((link) => {
            const linkPath = link.getAttribute('href');

            if (linkPath && linkPath.includes('login.html')) {
                link.classList.add('active'); // Highlight the login link
                const icon = link.querySelector('.material-symbols-outlined');
                if (icon) {
                    icon.classList.add('active');
                }
            } else {
                link.classList.remove('active');
                const icon = link.querySelector('.material-symbols-outlined');
                if (icon) {
                    icon.classList.remove('active');
                }
            }
        });
    }

    highlightActiveSidebar(); // Run it initially

    // Get plan elements
    const freePlan = document.querySelector('.free-plan');
    const personalPlan = document.querySelector('.personal-plan');
    const familyPlan = document.querySelector('.family-plan');
    const organizationPlan = document.querySelector('.organization-plan');
    const personalButton = document.querySelector('.personal-btn');
    const familyButton = document.querySelector('.family-btn');
    const organizationButton = document.querySelector('.organization-btn');
    const backButton = document.querySelector('.back-button');
    const loadingIndicator = document.querySelector('.loading-indicator');

    // Check if the user has already purchased a plan
    function checkSubscriptionStatus() {
        chrome.storage.sync.get(['userId', 'subscriptionPlan'], (data) => {
            const userId = data.userId;
            const currentPlan = data.subscriptionPlan || 'free';
            
            console.log("Checking subscription status for user:", userId);
            console.log("Current subscription plan:", currentPlan);
            
            // Reset all plans
            freePlan.classList.remove('selected');
            personalPlan.classList.remove('selected');
            familyPlan.classList.remove('selected');
            organizationPlan.classList.remove('selected');
            
            // Reset all buttons to "Select Plan"
            if (personalButton && !personalButton.classList.contains('current-plan-btn')) {
                personalButton.textContent = 'Select Plan';
                personalButton.classList.add('select-plan-btn');
                personalButton.classList.remove('current-plan-btn');
            }
            
            if (familyButton && !familyButton.classList.contains('current-plan-btn')) {
                familyButton.textContent = 'Select Plan';
                familyButton.classList.add('select-plan-btn');
                familyButton.classList.remove('current-plan-btn');
            }
            
            if (organizationButton && !organizationButton.classList.contains('current-plan-btn')) {
                organizationButton.textContent = 'Select Plan';
                organizationButton.classList.add('select-plan-btn');
                organizationButton.classList.remove('current-plan-btn');
            }
            
            // Mark the current plan
            if (currentPlan === 'free') {
                freePlan.classList.add('selected');
            } else if (currentPlan === 'personal') {
                personalPlan.classList.add('selected');
                // Update button text
                if (personalButton) {
                    personalButton.textContent = 'Current Plan';
                    personalButton.classList.add('current-plan-btn');
                    personalButton.classList.remove('select-plan-btn');
                }
            } else if (currentPlan === 'family') {
                familyPlan.classList.add('selected');
                // Update button text
                if (familyButton) {
                    familyButton.textContent = 'Current Plan';
                    familyButton.classList.add('current-plan-btn');
                    familyButton.classList.remove('select-plan-btn');
                }
            } else if (currentPlan === 'organization') {
                organizationPlan.classList.add('selected');
                // Update button text
                if (organizationButton) {
                    organizationButton.textContent = 'Current Plan';
                    organizationButton.classList.add('current-plan-btn');
                    organizationButton.classList.remove('select-plan-btn');
                }
            }
            
            // If we have a userId, check with Firestore directly for the latest status
            if (userId && typeof firebase !== 'undefined' && firebase.firestore) {
                const db = firebase.firestore();
                db.collection('users').doc(userId).get()
                    .then((doc) => {
                        if (doc.exists) {
                            const userData = doc.data();
                            const firestorePlan = userData.subscriptionPlan || 'free';
                            const isActive = userData.subscriptionStatus === 'active';
                            
                            console.log("Firestore plan:", firestorePlan, "Active:", isActive);
                            
                            // Update local storage with latest info from Firestore
                            if (firestorePlan !== currentPlan || !isActive) {
                                chrome.storage.sync.set({ 
                                    subscriptionPlan: isActive ? firestorePlan : 'free',
                                    isGoldUpgraded: isActive 
                                }, () => {
                                    // If plan changed, refresh the UI
                                    if (firestorePlan !== currentPlan) {
                                        checkSubscriptionStatus();
                                    }
                                });
                            }
                        }
                    })
                    .catch((error) => {
                        console.error("Error checking Firestore for subscription:", error);
                    });
            }
        });
    }

    // Call on page load
    checkSubscriptionStatus();

    // Function to handle plan selection and redirection to Stripe
    function handlePlanSelection(planType) {
        if (loadingIndicator) {
            loadingIndicator.style.display = 'flex';
        }
        
        // Get user email and ID for the payment process
        chrome.storage.sync.get(['userEmail', 'userId'], (data) => {
            const userEmail = data.userEmail;
            const userId = data.userId;
            
            if (!userId) {
                alert("You must be logged in to purchase a subscription.");
                if (loadingIndicator) {
                    loadingIndicator.style.display = 'none';
                }
                return;
            }
            
            // Use direct Stripe payment links
            const stripePaymentLinks = {
                personal: "https://buy.stripe.com/test_8wM8y2eEGcr2gJq4gg",
                family: "https://buy.stripe.com/test_14k3dIgMO62EgJq001",
                organization: "https://buy.stripe.com/test_7sIcOifIKdv61Ow9AC"
            };
            
            let finalUrl = stripePaymentLinks[planType];
            
            // Create success URL
            const successUrl = chrome.runtime.getURL('html/payment-success.html') + `?plan=${planType}`;
            
            // Construct the URL with parameters
            let params = new URLSearchParams();
            
            // Add email if available
            if (userEmail) {
                params.append('prefilled_email', userEmail);
            }
            
            // Add success URL
            params.append('success_url', successUrl);
            
            // Create final URL
            finalUrl = `${finalUrl}${finalUrl.includes('?') ? '&' : '?'}${params.toString()}`;
            
            // Remember which plan was selected for verification later
            chrome.storage.sync.set({ pendingPlanPurchase: planType }, () => {
                console.log("Pending plan purchase set:", planType);
                
                // Open the Stripe payment page in a new tab
                chrome.tabs.create({ url: finalUrl });
                
                if (loadingIndicator) {
                    loadingIndicator.style.display = 'none';
                }
            });
        });
    }
    // Handle Single Person plan selection
    if (personalButton) {
        personalButton.addEventListener('click', () => {
            handlePlanSelection('personal');
        });
    }

    // Handle Family plan selection
    if (familyButton) {
        familyButton.addEventListener('click', () => {
            handlePlanSelection('family');
        });
    }

    // Handle Organization plan selection
    if (organizationButton) {
        organizationButton.addEventListener('click', () => {
            handlePlanSelection('organization');
        });
    }

    // Handle back button click
    if (backButton) {
        backButton.addEventListener('click', () => {
            window.location.href = 'login.html';
        });
    }

    // Function to update content based on the selected language
    function updateContent() {
        document.querySelectorAll('[data-i18n]').forEach((element) => {
            const key = element.getAttribute('data-i18n');
            const translation = i18next.t(key);

            const iconSpan = element.querySelector('.material-symbols-outlined');
            if (iconSpan) {
                const iconHTML = iconSpan.outerHTML;
                element.innerHTML = `${iconHTML} ${translation}`;
            } else {
                element.textContent = translation;
            }
        });

        highlightActiveSidebar(); // Reapply sidebar highlight after translation updates
    }

    // Function to verify payment with Stripe (simulated for testing)
    function verifyPayment(planType) {
        return new Promise((resolve) => {
            // Check with Firestore directly
            chrome.storage.sync.get(['userId'], (data) => {
                const userId = data.userId;
                
                if (!userId) {
                    resolve(false);
                    return;
                }
                
                if (typeof firebase !== 'undefined' && firebase.firestore) {
                    const db = firebase.firestore();
                    db.collection('users').doc(userId).get()
                        .then((doc) => {
                            if (doc.exists) {
                                const userData = doc.data();
                                const isActive = userData.subscriptionStatus === 'active';
                                const planMatches = userData.subscriptionPlan === planType;
                                
                                console.log("Verification result:", isActive && planMatches);
                                resolve(isActive && planMatches);
                            } else {
                                resolve(false);
                            }
                        })
                        .catch((error) => {
                            console.error("Error verifying payment:", error);
                            resolve(false);
                        });
                } else {
                    // Fallback to simulated verification
                    setTimeout(() => {
                        console.log("Payment verified for plan (simulated):", planType);
                        resolve(true);
                    }, 1000);
                }
            });
        });
    }

    // Check for payment success parameters from Stripe redirect
    const urlParams = new URLSearchParams(window.location.search);
    
    // Handle payment success
    if (urlParams.has('payment_success') && urlParams.get('payment_success') === 'true') {
        const planType = urlParams.get('plan');
        
        if (loadingIndicator) {
            loadingIndicator.style.display = 'flex';
        }
        
        if (planType) {
            // Verify the payment with Stripe
            verifyPayment(planType)
                .then(success => {
                    if (success) {
                        // Update subscription in storage
                        chrome.storage.sync.set({ 
                            subscriptionPlan: planType,
                            pendingPlanPurchase: null 
                        }, () => {
                            // Refresh UI to show current plan
                            checkSubscriptionStatus();
                            
                            // Show success message
                            setTimeout(() => {
                                if (loadingIndicator) {
                                    loadingIndicator.style.display = 'none';
                                }
                                
                                alert('Thank you for your purchase! Your account has been upgraded to the ' + 
                                      planType.charAt(0).toUpperCase() + planType.slice(1) + ' plan.');
                                
                                // Clean URL
                                window.history.replaceState({}, document.title, window.location.pathname);
                            }, 500);
                        });
                    } else {
                        // In case of verification failure, query Firestore again after a delay
                        setTimeout(() => {
                            checkSubscriptionStatus();
                            
                            if (loadingIndicator) {
                                loadingIndicator.style.display = 'none';
                            }
                            
                            // Clean URL
                            window.history.replaceState({}, document.title, window.location.pathname);
                        }, 3000);
                    }
                });
        }
    }
    
    // Alternative approach? - check for session ID in URL (depends on Stripe setup)
    else if (urlParams.has('session_id')) {
        const sessionId = urlParams.get('session_id');
        
        // Get the pending plan from storage
        chrome.storage.sync.get(['pendingPlanPurchase'], (data) => {
            if (data.pendingPlanPurchase) {
                // Verify payment with session ID
                if (loadingIndicator) {
                    loadingIndicator.style.display = 'flex';
                }
                
                verifyPayment(data.pendingPlanPurchase)
                    .then(success => {
                        if (success) {
                            // Update subscription in storage
                            chrome.storage.sync.set({ 
                                subscriptionPlan: data.pendingPlanPurchase,
                                pendingPlanPurchase: null 
                            }, () => {
                                // Refresh UI to show current plan
                                checkSubscriptionStatus();
                                
                                setTimeout(() => {
                                    if (loadingIndicator) {
                                        loadingIndicator.style.display = 'none';
                                    }
                                    
                                    alert('Thank you for your purchase! Your account has been upgraded to the ' + 
                                          data.pendingPlanPurchase.charAt(0).toUpperCase() + 
                                          data.pendingPlanPurchase.slice(1) + ' plan.');
                                    
                                    // Clean URL
                                    window.history.replaceState({}, document.title, window.location.pathname);
                                }, 500);
                            });
                        } else {
                            setTimeout(() => {
                                checkSubscriptionStatus();
                                
                                if (loadingIndicator) {
                                    loadingIndicator.style.display = 'none';
                                }
                                
                                // Clean URL
                                window.history.replaceState({}, document.title, window.location.pathname);
                            }, 3000);
                        }
                    });
            }
        });
    }
});