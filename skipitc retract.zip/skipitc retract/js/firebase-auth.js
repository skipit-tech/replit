// firebase-auth.js
(function() {
    // Firebase configuration
    const firebaseConfig = {
      apiKey: "AIzaSyBrAtUSIMqpqKyr37KUMjxjnuFllsO2RHY",
      authDomain: "skip-it-de152.firebaseapp.com",
      projectId: "skip-it-de152",
      storageBucket: "skip-it-de152.firebasestorage.app",
      messagingSenderId: "884682586679",
      appId: "1:884682586679:web:76daf7ef05ae1904cb9db2"
    };
  
    // Initialize Firebase
    if (typeof firebase !== 'undefined' && firebase.apps.length === 0) {
      firebase.initializeApp(firebaseConfig);
    } else if (typeof firebase === 'undefined') {
      console.error('Firebase SDK not loaded');
      return;
    }
  
    const auth = firebase.auth();
    const db = firebase.firestore();
    const functions = firebase.functions();
  
    // Sign in with Google via Chrome Identity API, then link to Firebase
    function signInWithGoogle() {
      return new Promise((resolve, reject) => {
        // First get token from Chrome Identity
        chrome.identity.getAuthToken({ interactive: true }, function(token) {
          if (chrome.runtime.lastError) {
            console.error('Chrome identity error:', chrome.runtime.lastError);
            reject(chrome.runtime.lastError);
            return;
          }
          
          // Get user info to create a custom Firebase token
          fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
            headers: { 'Authorization': 'Bearer ' + token }
          })
          .then(response => response.json())
          .then(userInfo => {
            // Create a custom credential for Firebase
            const credential = firebase.auth.GoogleAuthProvider.credential(null, token);
            
            // Sign in to Firebase with credential
            return auth.signInWithCredential(credential)
              .then(userCredential => {
                const user = userCredential.user;
                
                // Store user data in Firestore
                return db.collection('users').doc(user.uid).set({
                  uid: user.uid,
                  email: user.email,
                  displayName: user.displayName,
                  photoURL: user.photoURL,
                  lastLogin: firebase.firestore.FieldValue.serverTimestamp()
                }, { merge: true })
                .then(() => {
                  // Check subscription status and update Chrome storage
                  return checkSubscriptionStatus(user.uid)
                    .then(({ isSubscribed, plan }) => {
                      // Update Chrome storage with auth status and subscription info
                      chrome.storage.sync.set({
                        isAuthenticated: true,
                        userId: user.uid,
                        userEmail: user.email,
                        userName: user.displayName,
                        userPhoto: user.photoURL,
                        subscriptionPlan: plan || 'free',
                        isGoldUpgraded: isSubscribed
                      });
                      
                      resolve(user);
                    });
                });
              });
          })
          .catch(error => {
            console.error("Authentication error:", error);
            reject(error);
          });
        });
      });
    }
  
    // Sign out from both Chrome Identity and Firebase
    function signOut() {
      return new Promise((resolve, reject) => {
        // First get the current token
        chrome.identity.getAuthToken({ interactive: false }, function(token) {
          // Revoke the token
          if (token) {
            chrome.identity.removeCachedAuthToken({ token }, function() {
              // Then sign out from Firebase
              auth.signOut()
                .then(() => {
                  // Clear authentication data from Chrome storage
                  chrome.storage.sync.set({
                    isAuthenticated: false,
                    userId: null,
                    userEmail: null,
                    userName: null,
                    userPhoto: null,
                    isGoldUpgraded: false,
                    subscriptionPlan: 'free'
                  });
                  
                  resolve({ success: true });
                })
                .catch(error => {
                  console.error("Sign-out error:", error);
                  reject(error);
                })
                .catch(error => {
                  console.error("Sign-out error:", error);
                  reject(error);
                });
            });
          } else {
            // No token, just sign out from Firebase
            auth.signOut()
              .then(() => {
                chrome.storage.sync.set({
                  isAuthenticated: false,
                  userId: null,
                  userEmail: null,
                  userName: null,
                  userPhoto: null,
                  isGoldUpgraded: false,
                  subscriptionPlan: 'free'
                });
                
                resolve({ success: true });
              })
              .catch(reject);
          }
        });
      });
    }
  
    // Check subscription status using Firebase
    function checkSubscriptionStatus(userId) {
      return new Promise((resolve, reject) => {
        if (!userId) {
          resolve({ isSubscribed: false, plan: 'free' });
          return;
        }
        
        db.collection('users').doc(userId).get()
          .then(doc => {
            if (doc.exists) {
              const userData = doc.data();
              const isSubscribed = userData.subscriptionStatus === 'active';
              const plan = isSubscribed ? (userData.subscriptionPlan || 'free') : 'free';
              
              // Update storage with subscription status
              chrome.storage.sync.set({ 
                isGoldUpgraded: isSubscribed,
                subscriptionPlan: plan
              });
              
              resolve({ isSubscribed, plan, userData });
            } else {
              chrome.storage.sync.set({ 
                isGoldUpgraded: false,
                subscriptionPlan: 'free'
              });
              resolve({ isSubscribed: false, plan: 'free' });
            }
          })
          .catch(error => {
            console.error('Error checking subscription:', error);
            resolve({ isSubscribed: false, plan: 'free', error: error.message });
          });
      });
    }
    
    // Listen for authentication state changes
    auth.onAuthStateChanged((user) => {
      if (user) {
        // User is signed in to Firebase
        checkSubscriptionStatus(user.uid).then(({ isSubscribed, plan }) => {
          chrome.storage.sync.set({
            isAuthenticated: true,
            userId: user.uid,
            userEmail: user.email,
            userName: user.displayName,
            userPhoto: user.photoURL,
            isGoldUpgraded: isSubscribed,
            subscriptionPlan: plan
          });
        });
      } else {
        // User is signed out of Firebase
        chrome.storage.sync.set({
          isAuthenticated: false,
          userId: null,
          userEmail: null,
          userName: null,
          userPhoto: null,
          isGoldUpgraded: false,
          subscriptionPlan: 'free'
        });
      }
    });
  
    // Export functions to window object
    window.authFunctions = {
      signInWithGoogle,
      signOut,
      checkSubscriptionStatus,
      getCurrentUser: () => auth.currentUser
    };
})();