// Sign in with Google
function signInWithGoogle() {
    return auth.signInWithPopup(googleProvider)
      .then((result) => {
        // Store user data in Firestore
        const user = result.user;
        return db.collection('users').doc(user.uid).set({
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
          photoURL: user.photoURL,
          lastLogin: firebase.firestore.FieldValue.serverTimestamp()
        }, { merge: true })
        .then(() => {
          // Update Chrome storage with auth status
          chrome.storage.sync.set({
            isAuthenticated: true,
            userId: user.uid,
            userEmail: user.email,
            userName: user.displayName,
            userPhoto: user.photoURL
          });
          return user;
        });
      })
      .catch((error) => {
        console.error("Sign-in error:", error);
        throw error;
      });
  }
  
  // Sign out
  function signOut() {
    return auth.signOut()
      .then(() => {
        // Clear authentication data from Chrome storage
        chrome.storage.sync.set({
          isAuthenticated: false,
          userId: null,
          userEmail: null,
          userName: null,
          userPhoto: null,
          isGoldUpgraded: false
        });
      })
      .catch((error) => {
        console.error("Sign-out error:", error);
        throw error;
      });
  }
  
  // Get current user
  function getCurrentUser() {
    return new Promise((resolve, reject) => {
      const unsubscribe = auth.onAuthStateChanged(user => {
        unsubscribe();
        resolve(user);
      }, reject);
    });
  }
  
  // Check if user has active subscription
  function checkSubscriptionStatus() {
    return getCurrentUser()
      .then(user => {
        if (!user) {
          return { isSubscribed: false };
        }
        
        return db.collection('users').doc(user.uid).get()
          .then(doc => {
            if (doc.exists) {
              const userData = doc.data();
              // Check subscription status
              return {
                isSubscribed: userData.subscriptionStatus === 'active',
                userData: userData
              };
            }
            return { isSubscribed: false };
          });
      })
      .catch(error => {
        console.error("Error checking subscription:", error);
        return { isSubscribed: false, error: error.message };
      });
  }
  
  // Update Chrome storage with subscription status
  function updateSubscriptionStatus() {
    return checkSubscriptionStatus()
      .then(result => {
        chrome.storage.sync.set({ isGoldUpgraded: result.isSubscribed });
        return result;
      });
  }