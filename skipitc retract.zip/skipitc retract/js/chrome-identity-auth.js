// chrome-identity-auth.js
(function() {
    // Define auth functions for the window
    window.authFunctions = {
      // Sign in with Google using Chrome Identity API
      signInWithGoogle: function() {
        return new Promise((resolve, reject) => {
          chrome.identity.getAuthToken({ interactive: true }, function(token) {
            if (chrome.runtime.lastError) {
              console.error('Chrome identity error:', chrome.runtime.lastError);
              reject(chrome.runtime.lastError);
              return;
            }
            
            // Get user info from Google
            fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
              headers: { 'Authorization': 'Bearer ' + token }
            })
            .then(response => response.json())
            .then(userInfo => {
              // Create a user object similar to Firebase user
              const user = {
                uid: userInfo.sub,
                email: userInfo.email,
                displayName: userInfo.name,
                photoURL: userInfo.picture
              };
              
              // Store user data in Chrome storage
              chrome.storage.sync.set({
                isAuthenticated: true,
                userId: user.uid,
                userEmail: user.email,
                userName: user.displayName,
                userPhoto: user.photoURL,
                authToken: token
              }, function() {
                // If Firebase Firestore is available, store user data there too
                if (typeof firebase !== 'undefined' && firebase.firestore) {
                  const db = firebase.firestore();
                  db.collection('users').doc(user.uid).set({
                    uid: user.uid,
                    email: user.email,
                    displayName: user.displayName,
                    photoURL: user.photoURL,
                    lastLogin: new Date().toISOString()
                  }, { merge: true })
                  .then(() => {
                    // Check subscription status
                    return checkSubscriptionStatus(user.uid);
                  })
                  .then(() => {
                    // Return the user object
                    resolve(user);
                  })
                  .catch((error) => {
                    console.error('Error updating Firestore:', error);
                    // Still resolve with the user since auth succeeded
                    resolve(user);
                  });
                } else {
                  // Return the user object
                  resolve(user);
                }
              });
            })
            .catch(error => {
              console.error('Failed to fetch user info:', error);
              reject(error);
            });
          });
        });
      },
      
      // Sign out
      signOut: function() {
        return new Promise((resolve, reject) => {
          chrome.storage.sync.get('authToken', function(data) {
            if (data.authToken) {
              // Revoke the token
              chrome.identity.removeCachedAuthToken({ token: data.authToken }, function() {
                // Clear auth data from storage
                chrome.storage.sync.set({
                  isAuthenticated: false,
                  userId: null,
                  userEmail: null,
                  userName: null,
                  userPhoto: null,
                  authToken: null,
                  isGoldUpgraded: false,
                  subscriptionPlan: 'free'
                }, function() {
                  resolve({ success: true });
                });
              });
            } else {
              // No token found, just clear the storage
              chrome.storage.sync.set({
                isAuthenticated: false,
                userId: null,
                userEmail: null,
                userName: null,
                userPhoto: null,
                isGoldUpgraded: false,
                subscriptionPlan: 'free'
              }, function() {
                resolve({ success: true });
              });
            }
          });
        });
      },
      
      // Get current user
      getCurrentUser: function() {
        return new Promise((resolve) => {
          chrome.storage.sync.get(['isAuthenticated', 'userId', 'userEmail', 'userName', 'userPhoto'], function(data) {
            if (data.isAuthenticated) {
              resolve({
                uid: data.userId,
                email: data.userEmail,
                displayName: data.userName,
                photoURL: data.userPhoto
              });
            } else {
              resolve(null);
            }
          });
        });
      },
      
      // Check subscription status
      checkSubscriptionStatus: function(userId) {
        return new Promise((resolve) => {
          if (!userId) {
            chrome.storage.sync.get(['userId'], function(data) {
              userId = data.userId;
              checkStatus(userId);
            });
          } else {
            checkStatus(userId);
          }
          
          function checkStatus(uid) {
            if (!uid) {
              resolve({ isSubscribed: false, plan: 'free' });
              return;
            }
            
            if (typeof firebase !== 'undefined' && firebase.firestore) {
              const db = firebase.firestore();
              db.collection('users').doc(uid).get()
                .then(doc => {
                  if (doc.exists) {
                    const userData = doc.data();
                    const isSubscribed = userData.subscriptionStatus === 'active';
                    const plan = isSubscribed ? (userData.subscriptionPlan || 'free') : 'free';
                    
                    // Update storage with subscription status
                    chrome.storage.sync.set({ 
                      isGoldUpgraded: isSubscribed,
                      subscriptionPlan: plan
                    });
                    
                    resolve({ isSubscribed, plan, userData });
                  } else {
                    chrome.storage.sync.set({ 
                      isGoldUpgraded: false,
                      subscriptionPlan: 'free'
                    });
                    resolve({ isSubscribed: false, plan: 'free' });
                  }
                })
                .catch(error => {
                  console.error('Error checking subscription:', error);
                  resolve({ isSubscribed: false, plan: 'free', error: error.message });
                });
            } else {
              // Firebase not available, use storage value
              chrome.storage.sync.get(['isGoldUpgraded', 'subscriptionPlan'], function(data) {
                resolve({ 
                  isSubscribed: !!data.isGoldUpgraded,
                  plan: data.subscriptionPlan || 'free'
                });
              });
            }
          }
        });
      }
    };
})();