const express = require('express');
const path = require('path');
const fs = require('fs');
const cors = require('cors');  

const app = express();
const PORT = 3000;

// Enable CORS for all routes
app.use(cors());  
// Serve static files from the root directory
app.use(express.static(path.join(__dirname)));

// Serve the about page directly
app.get('/html/about.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'html', 'about.html'));
});

// API endpoint to get the last modified date of any file in the directory
app.get('/api/last-updated', (req, res) => {
    const directoryPath = path.join(__dirname);

    // Read all files and directories in the root path
    fs.readdir(directoryPath, { withFileTypes: true }, (err, files) => {
        if (err) {
            return res.status(500).json({ error: 'Unable to scan directory' });
        }

        let lastModifiedTime = 0;

        // Iterate through each file to determine the last modified date
        files.forEach((file) => {
            if (file.isFile()) {
                const filePath = path.join(directoryPath, file.name);
                const stats = fs.statSync(filePath);

                if (stats.mtimeMs > lastModifiedTime) {
                    lastModifiedTime = stats.mtimeMs;
                }
            }
        });

        const lastModifiedDate = new Date(lastModifiedTime);
        res.json({ lastUpdated: lastModifiedDate.toDateString() });
    });
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});