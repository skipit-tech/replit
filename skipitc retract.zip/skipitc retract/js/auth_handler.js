// auth-handler.js - This file handles the Google sign-in for the onboarding page
// Since March 2025, Skip It. uses Chrome Identity API instead of Firebase

// Handle Google authentication using Chrome Identity
function setupGoogleSignIn() {
    const googleSigninButton = document.getElementById('google-signin-button');
    const loadingIndicator = document.getElementById('loading-indicator');
    const authError = document.getElementById('auth-error');
    
    if (!googleSigninButton) return;
    
    // Add click event listener to the Google sign-in button
    googleSigninButton.addEventListener('click', function() {
        // Show loading indicator
        if (loadingIndicator) {
            loadingIndicator.style.display = 'flex';
        }
        
        // Hide any previous error message
        if (authError) {
            authError.style.display = 'none';
        }
        
        // Check if authFunctions exists from chrome-identity-auth.js
        if (window.authFunctions && typeof window.authFunctions.signInWithGoogle === 'function') {
            console.log('Using Chrome Identity for authentication');
            
            // Call the signInWithGoogle function from chrome-identity-auth.js
            window.authFunctions.signInWithGoogle()
                .then(function(user) {
                    console.log('Authentication successful with Chrome Identity');
                    
                    // Hide loading indicator
                    if (loadingIndicator) {
                        loadingIndicator.style.display = 'none';
                    }
                    
                    // Move to the next step
                    if (typeof nextStep === 'function') {
                        nextStep();
                    } else {
                        console.error('nextStep function not found in onboarding.js');
                    }
                })
                .catch(function(error) {
                    console.error('Authentication failed with Chrome Identity:', error);
                    
                    // Hide loading indicator
                    if (loadingIndicator) {
                        loadingIndicator.style.display = 'none';
                    }
                    
                    // Show error message
                    if (authError) {
                        authError.textContent = 'Authentication failed: ' + (error.message || 'Please try again later.');
                        authError.style.display = 'block';
                    }
                });
        } else {
            // Fall back to messaging the background script
            console.log('Chrome Identity auth not available, using background script');
            chrome.runtime.sendMessage({ action: 'signInWithGoogle' }, function(response) {
                // Hide loading indicator
                if (loadingIndicator) {
                    loadingIndicator.style.display = 'none';
                }
                
                if (response && response.success) {
                    console.log('Authentication successful with background script');
                    
                    // Move to the next step
                    if (typeof nextStep === 'function') {
                        nextStep();
                    } else {
                        console.error('nextStep function not found in onboarding.js');
                    }
                } else {
                    console.error('Authentication failed with background script:', response ? response.error : 'No response');
                    
                    // Show error message
                    if (authError) {
                        authError.textContent = 'Authentication failed: ' + 
                            (response && response.error ? response.error : 'Please try again later.');
                        authError.style.display = 'block';
                    }
                }
            });
        }
    });
}

// Initialize the auth handler when the DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Set up Google sign-in button
    setupGoogleSignIn();
    
    // Set up the skip button for auth
    const skipButton = document.getElementById('skip-auth-button');
    if (skipButton && typeof skipAuth === 'function') {
        skipButton.addEventListener('click', skipAuth);
    }
});