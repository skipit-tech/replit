// popup-auth.js (updated version)
document.addEventListener('DOMContentLoaded', () => {
  // First check if onboarding is completed and access is verified
  chrome.storage.local.get(['accessVerified'], (localData) => {
    chrome.storage.sync.get(['onboardingCompleted'], (syncData) => {
      // If onboarding is not completed or access is not verified
      if (!syncData.onboardingCompleted || !localData.accessVerified) {
        // Replace the entire body content with a message
        document.body.innerHTML = `
          <div id="onboarding-required" style="
            background-color: #1e88e5;
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            font-family: Arial, sans-serif;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
          ">
            <h2 style="margin-bottom: 15px;">Please complete the onboarding process first!</h2>
            <button id="goto-onboarding" style="
              background-color: white;
              color: #1e88e5;
              border: none;
              padding: 10px 15px;
              border-radius: 4px;
              font-weight: bold;
              cursor: pointer;
            ">Go to Onboarding</button>
          </div>
        `;
        
        // Add event listener for the button
        document.getElementById('goto-onboarding').addEventListener('click', () => {
          chrome.tabs.create({ url: 'html/onboarding.html' });
          window.close(); // Close the popup
        });
        
        return; // Stop execution here
      }
      
      // If we get here, onboarding is completed and access is verified
      // Continue with the normal authentication process
      initializeAuth();
    });
  });
  
  // Function to initialize the authentication process
  function initializeAuth() {
    // Check authentication status immediately
    checkAuthStatus();
    
    // Add click handler for the auth button
    const authButton = document.getElementById('auth-button');
    if (authButton) {
      authButton.addEventListener('click', () => {
        const action = authButton.getAttribute('data-action');
        if (action === 'login') {
          handleLogin();
        } else if (action === 'logout') {
          handleLogout();
        }
      });
    }
    
    // Add click handler for login prompt
    const loginPrompt = document.getElementById('login-prompt');
    if (loginPrompt) {
      loginPrompt.addEventListener('click', handleLogin);
    }
    
    // Add click handler for the Google sign-in button (if it exists)
    const googleSignInButton = document.querySelector('.google-button');
    if (googleSignInButton) {
      googleSignInButton.addEventListener('click', (e) => {
        e.preventDefault();
        handleLogin();
      });
    }
  }
});

// Function to handle login
function handleLogin() {
// Check if auth functions are available
if (window.authFunctions && window.authFunctions.signInWithGoogle) {
  window.authFunctions.signInWithGoogle()
    .then((user) => {
      console.log("User signed in successfully:", user);
      checkAuthStatus(); // Refresh UI after login
    })
    .catch((error) => {
      console.error("Login error:", error);
      alert("Login failed: " + (error.message || "Please try again later."));
    });
} else {
  // If auth functions aren't available, open the login page in a new tab
  chrome.tabs.create({ url: 'html/login.html' });
  // Close the popup
  window.close();
}
}

// Function to handle logout
function handleLogout() {
// First approach: Try to use window.authFunctions if available
if (window.authFunctions && window.authFunctions.signOut) {
  console.log("Using authFunctions.signOut()");
  window.authFunctions.signOut()
    .then(() => {
      updateLocalAuthState(false);
      checkAuthStatus(); // Refresh UI after logout
    })
    .catch((error) => {
      console.error("Logout error:", error);
      alert("Logout failed. Please try again.");
    });
} 
// Second approach: Try sending a message to the background script
else {
  console.log("Sending signOut message to background");
  chrome.runtime.sendMessage({ action: 'signOut' }, (response) => {
    if (response && response.success) {
      updateLocalAuthState(false);
      checkAuthStatus(); // Refresh UI after logout
    } else {
      // If no response from background script, try direct storage manipulation
      updateLocalAuthState(false);
      checkAuthStatus();
      console.log("Manually updated auth state as fallback");
    }
  });
}
}

// Function to update the local authentication state
function updateLocalAuthState(isAuthenticated, userData = null) {
if (isAuthenticated && userData) {
  chrome.storage.sync.set({
    isAuthenticated: true,
    userName: userData.displayName || 'User',
    userPhoto: userData.photoURL || null
  });
} else {
  chrome.storage.sync.set({
    isAuthenticated: false,
    userName: null,
    userPhoto: null
  });
}
}

// Function to check the authentication status
function checkAuthStatus() {
const authContainer = document.getElementById('auth-container');
const contentContainer = document.getElementById('content-container');
const authButton = document.getElementById('auth-button');
const userDisplay = document.getElementById('user-display');
const loginPrompt = document.getElementById('login-prompt');

chrome.storage.sync.get(['isAuthenticated', 'userName', 'userPhoto'], (data) => {
  if (data.isAuthenticated) {
    // User is authenticated, show content
    if (loginPrompt) loginPrompt.style.display = 'none';
    if (contentContainer) contentContainer.style.display = 'block';
    
    // Show user info if available
    if (userDisplay) {
      if (data.userPhoto) {
        userDisplay.innerHTML = `
          <img src="${data.userPhoto}" alt="User" class="user-avatar">
          <span>${data.userName || 'User'}</span>
        `;
      } else {
        userDisplay.innerHTML = `
          <span class="material-symbols-outlined">person</span>
          <span>${data.userName || 'User'}</span>
        `;
      }
      userDisplay.style.display = 'flex';
    }
    
    // Change auth button to logout
    if (authButton) {
      authButton.innerHTML = '<span class="material-symbols-outlined">logout</span> Logout';
      authButton.setAttribute('data-action', 'logout');
    }
  } else {
    // User is not authenticated, show login prompt
    if (loginPrompt) loginPrompt.style.display = 'block';
    if (contentContainer) contentContainer.style.display = 'none';
    
    // Hide user display
    if (userDisplay) {
      userDisplay.style.display = 'none';
    }
    
    // Change auth button to login
    if (authButton) {
      authButton.innerHTML = '<span class="material-symbols-outlined">login</span> Login';
      authButton.setAttribute('data-action', 'login');
    }
  }
});
}