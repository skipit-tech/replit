// fetch and display the last modified date of this file
window.addEventListener('DOMContentLoaded', () => {
  console.log('Fetching last modified date...');
  
  const dateElement = document.getElementById('date');
  if (dateElement) {
    const lastModified = new Date(document.lastModified);
    
    // format the date for better readability
    const formattedDate = lastModified.toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });

    dateElement.textContent = ` ${formattedDate}`;
  } else {
    console.warn('Date element not found.');
  }

    // apply the theme based on saved preference from chrome.storage.sync
    chrome.storage.sync.get('theme', (data) => {
      const theme = data.theme || 'dark'; // default to dark mode
      if (theme === 'light') {
        document.body.classList.add('light-mode');
      } else {
        document.body.classList.remove('light-mode');
      }
    });
  
    // load the language setting and initialize i18next
    chrome.storage.sync.get('language', (data) => {
      const language = data.language || 'en'; // default to English
      initializeI18Next(language);
    });

       // Highlight the active sidebar link
   function highlightActiveSidebar() {
    const currentPath = window.location.pathname; // Get the current page path
    document.querySelectorAll('.nav-items a').forEach((link) => {
      if (link.getAttribute('href') === currentPath) {
        link.classList.add('active'); // add 'active' class to the matching link
      } else {
        link.classList.remove('active'); // Remove 'active' class from other links
      }
    });
  }

  highlightActiveSidebar();

  
    // Function to initialize i18next and update content
    function initializeI18Next(language) {
      i18next.init({
        lng: language,
        resources: {
          en: {
            translation: {
              "Dashboard": "Dashboard",
              "Trigger Warning Settings": "Trigger Warning Settings",
              "About": "About",
              "Login": "Login",
              "Get Help": "Get Help",
              "Last updated on": "Last updated on"
            }
          },
          es: {
            translation: {
              "Dashboard": "Tablero",
              "Trigger Warning Settings": "Configuración de Advertencias",
              "About": "Acerca de",
              "Login": "Iniciar Sesión",
              "Get Help": "Obtener Ayuda",
              "Last updated on": "Última actualización el"
            }
          },
          fr: {
            translation: {
              "Dashboard": "Tableau de Bord",
              "Trigger Warning Settings": "Paramètres d'Avertissement",
              "About": "À Propos",
              "Login": "Connexion",
              "Get Help": "Obtenir de l'Aide",
              "Last updated on": "Dernière mise à jour le"
            }
          }
        }
      }, () => {
        updateContent(); // Update content once i18next is initialized
      });
    }
  
    function updateContent() {
      document.querySelectorAll('[data-i18n]').forEach((element) => {
        const key = element.getAttribute('data-i18n');
        const translation = i18next.t(key);
    
        // Check if the element contains an icon (e.g., a <span> tag with the icon class)
        const iconSpan = element.querySelector('.material-symbols-outlined');
        if (iconSpan) {
          // Preserve the icon while updating the text content
          const iconHTML = iconSpan.outerHTML; // Extract the icon's HTML
          element.innerHTML = `${iconHTML} ${translation}`;
        } else if (element.id === 'last-updated') {
          // Special case for "Last updated on": preserve the date
          element.firstChild.textContent = `${translation} `;
        } else {
          // default case: replace the entire content with the translation
          element.textContent = translation;
        }
      });
    }
  });