document.addEventListener('DOMContentLoaded', () => {
    // Apply the correct theme on page load based on local storage
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light') {
        document.body.classList.add('light-mode');
    } else {
        document.body.classList.remove('light-mode');
    }

    // Add event listener to the back button to navigate to the support page
    document.getElementById('back-button').addEventListener('click', () => {
        window.location.href = '/html/support.html'; // Navigate back to the support page
    });
});