document.addEventListener('DOMContentLoaded', () => {
  // Load the theme and language settings from storage
  chrome.storage.sync.get(['language', 'theme'], (data) => {
    const language = data.language || 'en'; // Default to English
    const theme = data.theme || 'light'; // Default to dark mode

    initializeI18Next(language); // Initialize translations with the loaded language
    applyTheme(theme); // Apply the loaded theme
  });

   // Highlight the active sidebar link
   function highlightActiveSidebar() {
    const currentPath = window.location.pathname; // Get the current page path
    document.querySelectorAll('.nav-items a').forEach((link) => {
      if (link.getAttribute('href') === currentPath) {
        link.classList.add('active'); // Add 'active' class to the matching link
      } else {
        link.classList.remove('active'); // Remove 'active' class from other links
      }
    });
  }

  highlightActiveSidebar();

  // Function to initialize i18next and update content
  function initializeI18Next(language) {
    i18next.init({
      lng: language,
      resources: {
        en: {
          translation: {
            "Dashboard": "Dashboard",
            "Trigger Warning Settings": "Trigger Warning Settings",
            "About": "About",
            "Login": "Login",
            "Get Help": "Get Help",
            "Adjust Preview Timer": "Adjust Preview Timer",
            "Create Custom Trigger Warning Group": "Create Custom Trigger Warning Group",
            "Enter custom trigger warning": "Enter custom trigger warning",
            "Extension Positioning": "Extension Positioning",
            "Top Left": "Top Left",
            "Top Right": "Top Right",
            "Bottom Left": "Bottom Left",
            "Bottom Right": "Bottom Right",
            "Add": "Add"
          }
        },
        es: {
          translation: {
            "Dashboard": "Tablero",
            "Trigger Warning Settings": "Configuración de Advertencias",
            "About": "Acerca de",
            "Login": "Iniciar Sesión",
            "Get Help": "Obtener Ayuda",
            "Adjust Preview Timer": "Ajustar Temporizador de Vista Previa",
            "Create Custom Trigger Warning Group": "Crear Grupo de Advertencias Personalizadas",
            "Enter custom trigger warning": "Introduzca advertencia personalizada",
            "Extension Positioning": "Posicionamiento de la Extensión",
            "Top Left": "Arriba Izquierda",
            "Top Right": "Arriba Derecha",
            "Bottom Left": "Abajo Izquierda",
            "Bottom Right": "Abajo Derecha",
            "Add": "Agregar"
          }
        },
        fr: {
          translation: {
            "Dashboard": "Tableau de Bord",
            "Trigger Warning Settings": "Paramètres d'Avertissement",
            "About": "À Propos",
            "Login": "Connexion",
            "Get Help": "Obtenir de l'Aide",
            "Adjust Preview Timer": "Ajuster le Minuteur de Prévisualisation",
            "Create Custom Trigger Warning Group": "Créer un Groupe d'Avertissements Personnalisés",
            "Enter custom trigger warning": "Entrez un avertissement personnalisé",
            "Extension Positioning": "Positionnement de l'Extension",
            "Top Left": "En Haut à Gauche",
            "Top Right": "En Haut à Droite",
            "Bottom Left": "En Bas à Gauche",
            "Bottom Right": "En Bas à Droite",
            "Add": "Ajouter"
          }
        }
      }
    }, () => {
      updateContent(); // Update content once i18next is initialized
    });
  }

  function updateContent() {
    document.querySelectorAll('[data-i18n]').forEach((element) => {
      const key = element.getAttribute('data-i18n');
      const translation = i18next.t(key);
  
      // Check if the element contains an icon (e.g., a <span> tag)
      const iconSpan = element.querySelector('.material-symbols-outlined');
      if (iconSpan) {
        // Update only the text content after the icon
        const originalHTML = element.innerHTML;
        const iconHTML = iconSpan.outerHTML; // Keep the icon HTML intact
        element.innerHTML = `${iconHTML} ${translation}`;
      } else {
        // If no icon, update the entire content
        element.textContent = translation;
      }
    });
  
    // Update the placeholder text for the custom trigger input
    const customTriggerInput = document.getElementById('custom-trigger-input');
    if (customTriggerInput) {
      customTriggerInput.placeholder = i18next.t("Enter custom trigger warning");
    }
  }

  // Function to apply the theme
  function applyTheme(theme) {
    if (theme === 'light') {
      document.body.classList.add('light-mode');
    } else {
      document.body.classList.remove('light-mode');
    }
  }

  const timerElement = document.querySelector('.circle-indicator');
  const timeDisplay = document.querySelector('.time-display');
  const circle = document.querySelector('.circle');
  let isDragging = false;
  let angle = 60; // Set the angle to correspond to 10 seconds (10/60 * 360 degrees = 60 degrees)
  let previewTimer = 10; // Default preview timer set to 10 seconds

  // Function to position the red dot based on the angle
  function setTimerPosition(angle) {
    const radius = circle.getBoundingClientRect().width / 2; // Get the radius of the circle
    const radian = (angle - 90) * (Math.PI / 180); // Convert angle to radians, adjust so 0° is at the top
    
    // Calculate x and y position on the circle's circumference
    const newX = radius * Math.cos(radian);
    const newY = radius * Math.sin(radian);
    
    // Center the dot on the circle's circumference
    timerElement.style.transform = `translate(calc(${newX}px - 8px), calc(${newY}px - 8px))`;
  }

  // Load the preview timer from storage if it exists
  chrome.storage.sync.get(['previewTimer', 'positionSetting'], (data) => {
    if (data.previewTimer) {
      previewTimer = data.previewTimer;
      angle = (previewTimer / 60) * 360; // Adjust the angle based on the stored value
    }
    setTimerPosition(angle);
    updateTimeDisplay(angle);

    // Set the active button based on saved positionSetting
    if (data.positionSetting) {
      document.querySelectorAll('.position-button').forEach((btn) => btn.classList.remove('active'));
      document.getElementById(`${data.positionSetting}-button`).classList.add('active');
    }
  });

  timerElement.addEventListener('mousedown', (event) => {
    isDragging = true;
    document.body.style.userSelect = 'none'; // Prevent text selection
  });

  document.addEventListener('mousemove', (event) => {
    if (isDragging) {
      const rect = circle.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      const x = event.clientX - centerX;
      const y = event.clientY - centerY;
      angle = Math.atan2(y, x) * (180 / Math.PI) + 90;
      if (angle < 0) angle += 360;

      setTimerPosition(angle);
      updateTimeDisplay(angle);
    }
  });

  document.addEventListener('mouseup', () => {
    if (isDragging) {
      isDragging = false;
      document.body.style.userSelect = ''; // Re-enable text selection
      chrome.storage.sync.set({ previewTimer: previewTimer }); // Save the updated preview timer
    }
  });



  function updateTimeDisplay(angle) {
    previewTimer = Math.round((angle / 360) * 60);
    timeDisplay.textContent = `00:${previewTimer.toString().padStart(2, '0')}`;
  }

  // Initialize the position of the timer when the page loads
  setTimerPosition(angle); // Set the dot to the 10-second position by default
  updateTimeDisplay(angle); // Display 10 secs "00:10" as the default time

  const addCustomTriggerButton = document.getElementById('add-custom-trigger');
  const customTriggerInput = document.getElementById('custom-trigger-input');
  const customTriggerList = document.getElementById('custom-trigger-list');

  addCustomTriggerButton.addEventListener('click', () => {
    const triggerText = customTriggerInput.value.trim();
    if (triggerText) {
      const listItem = document.createElement('li');
      listItem.textContent = triggerText;

      const removeButton = document.createElement('button');
      removeButton.className = 'remove-button';
      removeButton.innerHTML = `<svg viewBox="0 0 24 24"><path d="M18.3 5.7a1 1 0 0 0-1.4 0L12 10.6 7.1 5.7a1 1 0 1 0-1.4 1.4L10.6 12l-4.9 4.9a1 1 0 0 0 1.4 1.4L12 13.4l4.9 4.9a1 1 0 0 0 1.4-1.4L13.4 12l4.9-4.9a1 1 0 0 0 0-1.4z"/></svg>`;
      removeButton.addEventListener('click', () => {
        listItem.remove();
      });

      listItem.appendChild(removeButton);
      customTriggerList.appendChild(listItem);
      customTriggerInput.value = '';
    }
  });

  // Handle position setting buttons
  document.querySelectorAll('.position-button').forEach((button) => {
    button.addEventListener('click', () => {
      document.querySelectorAll('.position-button').forEach((btn) => btn.classList.remove('active'));
      button.classList.add('active');
      const positionSetting = button.id.replace('-button', '');
      chrome.storage.sync.set({ positionSetting }); // Save the updated position setting
    });
  });
});