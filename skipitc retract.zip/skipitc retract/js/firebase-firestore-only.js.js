// firebase-firestore-only.js
import firebase from 'firebase/compat/app';
import 'firebase/compat/firestore';

// Make Firebase available globally
window.firebase = firebase;

// Your Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBrAtUSIMqpqKyr37KUMjxjnuFllsO2RHY",
  authDomain: "skip-it-de152.firebaseapp.com",
  projectId: "skip-it-de152",
  storageBucket: "skip-it-de152.firebasestorage.app",
  messagingSenderId: "884682586679",
  appId: "1:884682586679:web:76daf7ef05ae1904cb9db2", 
  measurementId: "G-4CQF5GLC3W"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Export Firestore for convenience
window.db = firebase.firestore();