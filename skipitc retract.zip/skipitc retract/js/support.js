document.addEventListener('DOMContentLoaded', () => {
    const searchBar = document.getElementById('search-bar');
    const supportCategories = document.querySelectorAll('.support-category');
    const headerTitle = document.querySelector('.header h1');
    
    // Apply the correct theme on page load
    chrome.storage.sync.get('theme', (data) => {
        const theme = data.theme || 'dark'; // Default to dark mode
        if (theme === 'light') {
            document.body.classList.add('light-mode');
        } else {
            document.body.classList.remove('light-mode');
        }
    });

 
    // Load the language setting and initialize i18next
    chrome.storage.sync.get('language', (data) => {
        const language = data.language || 'en'; // Default to English
        initializeI18Next(language);
    });

     //Ensure Sidebar Highlighting for Login Page**
     function highlightActiveSidebar() {
        const currentPath = window.location.pathname;
        document.querySelectorAll('.nav-items a, .bottom-links a').forEach((link) => {
            const linkPath = link.getAttribute('href');

            if (linkPath && linkPath.includes('support.html')) {
                link.classList.add('active'); // Highlight the login link
                const icon = link.querySelector('.material-symbols-outlined');
                if (icon) {
                    icon.classList.add('active'); // Highlight icon
                }
            } else {
                link.classList.remove('active');
                const icon = link.querySelector('.material-symbols-outlined');
                if (icon) {
                    icon.classList.remove('active');
                }
            }
        });
    }

    highlightActiveSidebar(); // Run it initially   

    // Function to initialize i18next and update content
    function initializeI18Next(language) {
        i18next.init({
            lng: language,
            resources: {
                en: {
                    translation: {
                        "Dashboard": "Dashboard",
                        "Trigger Warning Settings": "Trigger Warning Settings",
                        "About": "About",
                        "Login": "Login",
                        "Get Help": "Get Help",
                        "Search": "Search",
                        "How can we help?": "How can we help?",
                        "Search Account Management, Payment, etc.": "Search Account Management, Payment, etc.",
                        "SKIP IT. Help Desk": "SKIP IT. Help Desk",
                        "Account Management": "Account Management",
                        "Manage your account settings and preferences.": "Manage your account settings and preferences.",
                        "View Articles": "View Articles",
                        "Payment": "Payment",
                        "Get help with billing, subscriptions, and refunds.": "Get help with billing, subscriptions, and refunds.",
                        "Troubleshooting": "Troubleshooting",
                        "Fix technical issues and errors.": "Fix technical issues and errors.",
                        "Privacy and Security": "Privacy and Security",
                        "Learn how SKIP IT. keeps your data safe.": "Learn how SKIP IT. keeps your data safe.",
                        "FAQ": "FAQ",
                        "Find answers to frequently asked questions.": "Find answers to frequently asked questions.",
                        "Contact Support": "Contact Support",
                        "Get in touch with our support team for more help.": "Get in touch with our support team for more help.",
                        "Accessibility": "Accessibility",
                        "Explore accessibility features that make SKIP IT. more inclusive for all users.": "Explore accessibility features that make SKIP IT. more inclusive for all users.",
                        "Updates": "Updates",
                        "Stay up to date with the latest updates and improvements to SKIP IT.": "Stay up to date with the latest updates and improvements to SKIP IT.",
                        "Version": "Version",
                        "Learn about our commitment to fostering an inclusive and diverse environment for all users.": "Learn about our commitment to fostering an inclusive and diverse environment for all users."
                    }
                },
                es: {
                    translation: {
                        "Dashboard": "Tablero",
                        "Trigger Warning Settings": "Configuración de Advertencias",
                        "About": "Acerca de",
                        "Login": "Iniciar Sesión",
                        "Get Help": "Obtener Ayuda",
                        "Search": "Buscar",
                        "How can we help?": "¿Cómo podemos ayudar?",
                        "Search Account Management, Payment, etc.": "Buscar Gestión de Cuenta, Pago, etc.",
                        "SKIP IT. Help Desk": "SKIP IT. Mesa de Ayuda",
                        "Account Management": "Gestión de Cuenta",
                        "Manage your account settings and preferences.": "Administra la configuración y preferencias de tu cuenta.",
                        "View Articles": "Ver Artículos",
                        "Payment": "Pago",
                        "Get help with billing, subscriptions, and refunds.": "Obtén ayuda con facturación, suscripciones y reembolsos.",
                        "Troubleshooting": "Solución de Problemas",
                        "Fix technical issues and errors.": "Soluciona problemas técnicos y errores.",
                        "Privacy and Security": "Privacidad y Seguridad",
                        "Learn how SKIP IT. keeps your data safe.": "Descubre cómo SKIP IT. protege tus datos.",
                        "FAQ": "Preguntas Frecuentes",
                        "Find answers to frequently asked questions.": "Encuentra respuestas a preguntas frecuentes.",
                        "Contact Support": "Contactar Soporte",
                        "Get in touch with our support team for more help.": "Ponte en contacto con nuestro equipo de soporte para más ayuda.",
                        "Accessibility": "Accesibilidad",
                        "Explore accessibility features that make SKIP IT. more inclusive for all users.": "Explora las funciones de accesibilidad que hacen SKIP IT. más inclusivo para todos los usuarios.",
                        "Updates": "Actualizaciones",
                        "Stay up to date with the latest updates and improvements to SKIP IT.": "Mantente al día con las últimas actualizaciones y mejoras de SKIP IT.",
                        "Version": "Versión",
                        "Learn about our commitment to fostering an inclusive and diverse environment for all users.": "Conoce nuestro compromiso con un entorno inclusivo y diverso para todos los usuarios."
                    }
                },
                fr: {
                    translation: {
                        "Dashboard": "Tableau de Bord",
                        "Trigger Warning Settings": "Paramètres d'Avertissement",
                        "About": "À Propos",
                        "Login": "Connexion",
                        "Get Help": "Obtenir de l'Aide",
                        "Search": "Rechercher",
                        "How can we help?": "Comment pouvons-nous vous aider?",
                        "Search Account Management, Payment, etc.": "Rechercher Gestion de Compte, Paiement, etc.",
                        "SKIP IT. Help Desk": "SKIP IT. Service d'Assistance",
                        "Account Management": "Gestion du Compte",
                        "Manage your account settings and preferences.": "Gérez les paramètres et préférences de votre compte.",
                        "View Articles": "Voir les Articles",
                        "Payment": "Paiement",
                        "Get help with billing, subscriptions, and refunds.": "Obtenez de l'aide pour la facturation, les abonnements et les remboursements.",
                        "Troubleshooting": "Dépannage",
                        "Fix technical issues and errors.": "Résolvez les problèmes techniques et les erreurs.",
                        "Privacy and Security": "Confidentialité et Sécurité",
                        "Learn how SKIP IT. keeps your data safe.": "Découvrez comment SKIP IT. protège vos données.",
                        "FAQ": "FAQ",
                        "Find answers to frequently asked questions.": "Trouvez des réponses aux questions fréquemment posées.",
                        "Contact Support": "Contacter le Support",
                        "Get in touch with our support team for more help.": "Contactez notre équipe de support pour plus d'aide.",
                        "Accessibility": "Accessibilité",
                        "Explore accessibility features that make SKIP IT. more inclusive for all users.": "Explorez les fonctionnalités d'accessibilité qui rendent SKIP IT. plus inclusif pour tous les utilisateurs.",
                        "Updates": "Mises à Jour",
                        "Stay up to date with the latest updates and improvements to SKIP IT.": "Restez informé des dernières mises à jour et améliorations de SKIP IT.",
                        "Version": "Version",
                        "Learn about our commitment to fostering an inclusive and diverse environment for all users.": "Découvrez notre engagement envers un environnement inclusif et diversifié pour tous les utilisateurs."
                    }
                }
            }
        }, () => {
            updateContent(); // Update content once i18next is initialized
        });
    }

    // Function to update content based on the selected language
    function updateContent() {
        document.querySelectorAll('[data-i18n]').forEach((element) => {
            const key = element.getAttribute('data-i18n');
            const translation = i18next.t(key);

            // Ensure icons are not removed when updating text
            const iconSpan = element.querySelector('.material-symbols-outlined');
            if (iconSpan) {
                const iconHTML = iconSpan.outerHTML;
                element.innerHTML = `${iconHTML} ${translation}`;
            } else {
                element.textContent = translation;
            }
        });

        // Update header title and search bar placeholder text
        headerTitle.textContent = i18next.t("How can we help?");
        searchBar.placeholder = i18next.t("Search Account Management, Payment, etc.");

        highlightActiveSidebar(); // Reapply sidebar highlight after translation updates
    }

    // Event listener for the search bar
    searchBar.addEventListener('input', () => {
        const query = searchBar.value.toLowerCase();

        // Iterate over each support category and check if its title matches the search query
        supportCategories.forEach((category) => {
            const title = category.querySelector('h3').textContent.toLowerCase();

            if (title.startsWith(query)) {
                category.style.display = 'block'; // Show matching sections
            } else {
                category.style.display = 'none'; // Hide non-matching sections
            }
        });

        // Handle placeholder disappearance when typing
        if (searchBar.value.length > 0) {
            searchBar.placeholder = '';
        } else {
            searchBar.placeholder = i18next.t("Search Account Management, Payment, etc.");
        }
    });

    // Add event listener to "View Articles" for Privacy and Security
    const privacySecurityLink = document.querySelector('.support-category:nth-child(4) a');
    privacySecurityLink.addEventListener('click', (e) => {
        e.preventDefault();  // Prevent default link behavior
        window.location.href = '/html/privacy_security.html';  // Redirect to Privacy and Security page
    });

        const accountManagementLink = document.querySelector('.support-category:nth-child(1) a'); // Adjust the selector as needed
        accountManagementLink.addEventListener('click', (e) => {
            e.preventDefault(); // Prevent default link behavior
            window.location.href = '/html/account_management.html'; // Redirect to Account Management page
        });

        // Add event listener to "View Articles" for Payment
        const paymentLink = document.querySelector('.support-category:nth-child(2) a');
        paymentLink.addEventListener('click', (e) => {
            e.preventDefault();  // Prevent default link behavior
            window.location.href = '/html/payment.html';  // Redirect to Payment page
        });

        // Add event listener to "View Articles" for Troubleshooting
        const troubleshootingLink = document.querySelector('.support-category:nth-child(3) a');
        troubleshootingLink.addEventListener('click', (e) => {
            e.preventDefault(); // Prevent default link behavior
            window.location.href = '/html/troubleshooting.html'; // Redirect to Troubleshooting page
        });
        // Add event listener to "View Articles" for FAQ
        const faqLink = document.querySelector('.support-category:nth-child(5) a'); // Adjust the selector as needed
        faqLink.addEventListener('click', (e) => {
            e.preventDefault();
            window.location.href = '/html/faq.html'; // Redirect to FAQ page
        });

        const contactSupportLink = document.querySelector('.support-category:nth-child(6) a'); // Adjust the selector as needed
        contactSupportLink.addEventListener('click', (e) => {
            e.preventDefault();
            window.location.href = '/html/contact_support.html'; // Redirect to Contact Support page
        });

        const accessibilityLink = document.querySelector('.support-category:nth-child(7) a'); // Adjust selector as needed
        accessibilityLink.addEventListener('click', (e) => {
            e.preventDefault(); // Prevent default link behavior
            window.location.href = '/html/accessibility.html'; // Redirect to Accessibility page
        });

        const updatesLink = document.querySelector('.support-category:nth-child(8) a'); // Adjust selector as needed
        updatesLink.addEventListener('click', (e) => {
            e.preventDefault(); // Prevent default link behavior
            window.location.href = '/html/updates.html'; // Redirect to Updates page
        });

        const versionLink = document.querySelector('.support-category:nth-child(9) a'); // Adjust selector as needed
        versionLink.addEventListener('click', (e) => {
            e.preventDefault(); // Prevent default link behavior
            window.location.href = '/html/version.html'; // Redirect to Version page
        });

    });
    