// Initialize Firebase
const firebaseConfig = {
  apiKey: "AIzaSyBrAtUSIMqpqKyr37KUMjxjnuFllsO2RHY",
  authDomain: "skip-it-de152.firebaseapp.com",
  projectId: "skip-it-de152",
  storageBucket: "skip-it-de152.firebasestorage.app",
  messagingSenderId: "884682586679",
  appId: "1:884682586679:web:76daf7ef05ae1904cb9db2",
  measurementId: "G-4CQF5GLC3W"
};

// Initialize Firebase if it exists
function initFirebase() {
  // Check if Firebase SDK is loaded
  if (typeof firebase === 'undefined') {
    console.error('Firebase SDK is not loaded. Please check your script inclusions.');
    return false;
  }

  try {
    // Initialize Firebase if it hasn't been already
    if (firebase.apps.length === 0) {
      firebase.initializeApp(firebaseConfig);
    }
    
    // Initialize services
    const auth = firebase.auth();
    const db = firebase.firestore();
    
    // Google Auth Provider setup
    const googleProvider = new firebase.auth.GoogleAuthProvider();
    googleProvider.setCustomParameters({
      prompt: 'select_account'
    });
    
    // Export auth functions for use across the extension
    window.authFunctions = {
      // Sign in with Google
      signInWithGoogle: () => {
        return auth.signInWithPopup(googleProvider)
          .then((result) => {
            // Store user data in Firestore
            const user = result.user;
            return db.collection('users').doc(user.uid).set({
              uid: user.uid,
              email: user.email,
              displayName: user.displayName,
              photoURL: user.photoURL,
              lastLogin: firebase.firestore.FieldValue.serverTimestamp()
            }, { merge: true })
            .then(() => {
              // Update Chrome storage with auth status
              chrome.storage.sync.set({
                isAuthenticated: true,
                userId: user.uid,
                userEmail: user.email,
                userName: user.displayName,
                userPhoto: user.photoURL
              });
              return user;
            });
          })
          .catch((error) => {
            console.error("Sign-in error:", error);
            throw error;
          });
      },
      
      // Sign out
      signOut: () => {
        return auth.signOut()
          .then(() => {
            // Clear authentication data from Chrome storage
            chrome.storage.sync.set({
              isAuthenticated: false,
              userId: null,
              userEmail: null,
              userName: null,
              userPhoto: null,
              isGoldUpgraded: false
            });
          })
          .catch((error) => {
            console.error("Sign-out error:", error);
            throw error;
          });
      },
      
      // Get current user
      getCurrentUser: () => {
        return new Promise((resolve, reject) => {
          const unsubscribe = auth.onAuthStateChanged(user => {
            unsubscribe();
            resolve(user);
          }, reject);
        });
      },
      
      // Check if user has active subscription
      checkSubscriptionStatus: () => {
        return auth.currentUser
          .then(user => {
            if (!user) {
              return { isSubscribed: false };
            }
            
            return db.collection('users').doc(user.uid).get()
              .then(doc => {
                if (doc.exists) {
                  const userData = doc.data();
                  return {
                    isSubscribed: userData.subscriptionStatus === 'active',
                    userData: userData
                  };
                }
                return { isSubscribed: false };
              });
          })
          .catch(error => {
            console.error("Error checking subscription:", error);
            return { isSubscribed: false, error: error.message };
          });
      }
    };
    
    return true;
  } catch (error) {
    console.error('Firebase initialization error:', error);
    return false;
  }
}

// Try to initialize Firebase when the script loads
document.addEventListener('DOMContentLoaded', () => {
  initFirebase();
});

// Allow manual initialization
window.initFirebase = initFirebase;