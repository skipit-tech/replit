document.addEventListener('DOMContentLoaded', () => {
  // First check if onboarding is completed and access is verified
  chrome.storage.local.get(['accessVerified'], (localData) => {
    chrome.storage.sync.get(['onboardingCompleted'], (syncData) => {
      // If onboarding is not completed or access is not verified
      if (!syncData.onboardingCompleted || !localData.accessVerified) {
        // Replace the entire body content with a message
        document.body.innerHTML = `
          <div id="onboarding-required" style="
            background-color: #1e88e5;
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            font-family: Arial, sans-serif;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
          ">
            <h2 style="margin-bottom: 15px;">Please complete the onboarding process first!</h2>
            <button id="goto-onboarding" style="
              background-color: white;
              color: #1e88e5;
              border: none;
              padding: 10px 15px;
              border-radius: 4px;
              font-weight: bold;
              cursor: pointer;
            ">Go to Onboarding</button>
          </div>
        `;
        
        // Add event listener for the button
        document.getElementById('goto-onboarding').addEventListener('click', () => {
          chrome.tabs.create({ url: 'html/onboarding.html' });
          window.close(); // Close the popup
        });
        
        return; // Stop execution here
      }
      
      // If we get here, onboarding is completed and access is verified
      // Continue with the normal popup initialization
      initializePopup();
    });
  });

  // Function to initialize the normal popup
  function initializePopup() {
    const abuseCheckbox = document.getElementById('abuse-checkbox');
    const violenceCheckbox = document.getElementById('violence-checkbox');
    const mentalIllnessCheckbox = document.getElementById('mental-illness-checkbox');
    const substanceUseCheckbox = document.getElementById('substance-use-checkbox');
    const illnessInjuryCheckbox = document.getElementById('illness-injury-checkbox');
    const discriminationCheckbox = document.getElementById('discrimination-checkbox');
    const clearButton = document.getElementById('clear-button');
    const saveButton = document.getElementById('save-button');
    const addCustomButton = document.getElementById('add-custom-button');
    const removeCustomButton = document.getElementById('remove-custom-button');
    const customWarningInput = document.getElementById('custom-warning-input');
    const checkboxContainer = document.querySelector('.checkbox-container');
    const dashboardButton = document.getElementById('dashboard-button');

    // Function to create a custom checkbox
    function createCheckbox(id, label) {
      const checkboxLabel = document.createElement('label');
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.id = id;
      checkbox.classList.add('custom-checkbox');
      checkboxLabel.appendChild(checkbox);
      checkboxLabel.appendChild(document.createTextNode(` ${label}`));
      return checkboxLabel;
    }

    // Load saved settings and apply font size
    chrome.storage.sync.get(['triggerWarnings', 'customWarnings', 'fontSize'], (data) => {
      // Check saved warnings
      if (data.triggerWarnings) {
        abuseCheckbox.checked = data.triggerWarnings.includes('Abuse');
        violenceCheckbox.checked = data.triggerWarnings.includes('Violence');
        mentalIllnessCheckbox.checked = data.triggerWarnings.includes('Mental Illness');
        substanceUseCheckbox.checked = data.triggerWarnings.includes('Substance Use');
        illnessInjuryCheckbox.checked = data.triggerWarnings.includes('Illness/Injury');
        discriminationCheckbox.checked = data.triggerWarnings.includes('Discrimination');
      }

      // Add custom warnings
      if (data.customWarnings) {
        data.customWarnings.forEach(customWarning => {
          const checkboxLabel = createCheckbox(customWarning, customWarning);
          checkboxContainer.appendChild(checkboxLabel);
          document.getElementById(customWarning).checked = true;
        });
      }

      // Apply the saved font size
      if (data.fontSize) {
        applyFontSize(data.fontSize);
      }
    });

    // Add custom warning
    addCustomButton.addEventListener('click', () => {
      const customWarning = customWarningInput.value.trim();
      if (customWarning) {
        const checkboxLabel = createCheckbox(customWarning, customWarning);
        checkboxContainer.appendChild(checkboxLabel);
        customWarningInput.value = '';
      }
    });

    // Remove selected custom warnings
    removeCustomButton.addEventListener('click', () => {
      const customCheckboxes = document.querySelectorAll('.custom-checkbox');
      customCheckboxes.forEach(checkbox => {
        if (checkbox.checked) {
          checkbox.parentElement.remove();
        }
      });
    });

    // Clear settings
    clearButton.addEventListener('click', () => {
      abuseCheckbox.checked = false;
      violenceCheckbox.checked = false;
      mentalIllnessCheckbox.checked = false;
      substanceUseCheckbox.checked = false;
      illnessInjuryCheckbox.checked = false;
      discriminationCheckbox.checked = false;

      const customCheckboxes = document.querySelectorAll('.custom-checkbox');
      customCheckboxes.forEach(checkbox => {
        checkbox.checked = false;
      });
    });

    // Save settings
    saveButton.addEventListener('click', () => {
      const selectedWarnings = [];
      const customWarnings = [];

      if (abuseCheckbox.checked) selectedWarnings.push('Abuse');
      if (violenceCheckbox.checked) selectedWarnings.push('Violence');
      if (mentalIllnessCheckbox.checked) selectedWarnings.push('Mental Illness');
      if (substanceUseCheckbox.checked) selectedWarnings.push('Substance Use');
      if (illnessInjuryCheckbox.checked) selectedWarnings.push('Illness/Injury');
      if (discriminationCheckbox.checked) selectedWarnings.push('Discrimination');

      const customCheckboxes = document.querySelectorAll('.custom-checkbox');
      customCheckboxes.forEach(checkbox => {
        if (checkbox.checked && !selectedWarnings.includes(checkbox.id)) {
          customWarnings.push(checkbox.id);
        }
      });

      chrome.storage.sync.set({ triggerWarnings: selectedWarnings, customWarnings: customWarnings }, () => {
        alert('Settings saved');
      });
    });

    // Open dashboard
    dashboardButton.addEventListener('click', () => {
      chrome.runtime.openOptionsPage();
    });

    // Apply font size class to the popup
    function applyFontSize(size) {
      document.body.classList.remove('small-text', 'medium-text', 'large-text');
      document.body.classList.add(`${size}-text`);
    }
  }
});