document.addEventListener('DOMContentLoaded', () => {
  const activateSwitch = document.getElementById('activate-switch');
  const addWebsiteButton = document.getElementById('add-website-button');
  const websiteInput = document.getElementById('website-input');
  const addWebsiteConfirmButton = document.getElementById('add-website-confirm-button');
  const streamingPlatformsList = document.getElementById('streaming-platforms-list');
  const themeSwitch = document.getElementById('theme-switch');
  const languageSelect = document.getElementById('language-select');

  const smallButton = document.querySelector('.size-button.small');
  const mediumButton = document.querySelector('.size-button.medium');
  const largeButton = document.querySelector('.size-button.large');

  // Apply styles to language select dropdown
  languageSelect.style.width = addWebsiteButton.offsetWidth + 'px';
  languageSelect.style.height = addWebsiteButton.offsetHeight + 'px';
  languageSelect.style.borderRadius = '5px'; 
  languageSelect.style.backgroundColor = '#4444cc'; 
  languageSelect.style.color = 'white'; 
  languageSelect.style.border = '2px solid black';

  // Initialize i18next
  i18next.init({
    lng: 'en', // Default language
    resources: {
      en: {
        translation: {
          "Dashboard": "Dashboard",
          "Trigger Warning Settings": "Trigger Warning Settings",
          "About": "About",
          "Login": "Login",
          "Get Help": "Get Help",
          "Activate Trigger Warning": "Activate Trigger Warning",
          "Streaming Platforms": "Streaming Platforms",
          "Supported Movies": "Supported Movies",
          "Title": "Title",
          "Year": "Year",
          "Top Triggers": "Top Triggers",
          "Platforms": "Platforms",
          "Play": "Play",
          "Add Website": "+ Add Website",
          "Add": "Add",
          "Dark Mode / Light Mode": "Dark Mode / Light Mode",
          "Size Scalability": "Size Scalability",
          "Language": "Language",
          "Sort by Date Ascending": "Sort by Date ⬆",
          "Sort by Date Descending": "Sort by Date ⬇",
          "Sort by Title A-Z": "Sort by Title A ⮕ Z",
          "Sort by Title Z-A": "Sort by Title Z ⮕ A",
        }
      },
      es: {
        translation: {
          "Dashboard": "Tablero",
          "Trigger Warning Settings": "Configuración de Advertencias",
          "About": "Acerca de",
          "Login": "Iniciar Sesión",
          "Get Help": "Obtener Ayuda",
          "Activate Trigger Warning": "Activar Advertencia",
          "Streaming Platforms": "Plataformas de Streaming",
          "Supported Movies": "Películas compatibles",
          "Title": "Título",
          "Year": "Año",
          "Top Triggers": "Activadores principales",
          "Platforms": "Plataformas",
          "Play": "Reproducir",
          "Add Website": "+ Agregar Sitio Web",
          "Add": "Agregar",
          "Dark Mode / Light Mode": "Modo Oscuro / Modo Claro",
          "Size Scalability": "Escalabilidad de Tamaño",
          "Language": "Idioma",
          "Sort by Date Ascending": "Ordenar por Fecha ⬆",
          "Sort by Date Descending": "Ordenar por Fecha ⬇",
          "Sort by Title A-Z": "Ordenar por Título A ⮕ Z",
          "Sort by Title Z-A": "Ordenar por Título Z ⮕ A",
        }
      },
      fr: {
        translation: {
          "Dashboard": "Tableau de Bord",
          "Trigger Warning Settings": "Paramètres d'Avertissement",
          "About": "À Propos",
          "Login": "Connexion",
          "Get Help": "Obtenir de l'Aide",
          "Activate Trigger Warning": "Activer Avertissement",
          "Streaming Platforms": "Plateformes de Streaming",
          "Supported Movies": "Films pris en charge",
          "Title": "Titre",
          "Year": "Année",
          "Top Triggers": "Principaux Déclencheurs",
          "Platforms": "Plateformes",
          "Play": "Jouer",
          "Add Website": "+ Ajouter Site Web",
          "Add": "Ajouter",
          "Dark Mode / Light Mode": "Mode Sombre / Mode Clair",
          "Size Scalability": "Évolutivité de Taille",
          "Language": "Langue",
          "Sort by Date Ascending": "Trier par Date ⬆",
          "Sort by Date Descending": "Trier par Date ⬇",
          "Sort by Title A-Z": "Trier par Titre A ⮕ Z",
          "Sort by Title Z-A": "Trier par Titre Z ⮕ A"
        }
      }
    }
  }, () => {
    updateContent(); 
  });

  // Function to update content based on the selected language
  function updateContent() {
    document.querySelectorAll('[data-i18n]').forEach((element) => {
      const key = element.getAttribute('data-i18n');
      const translatedText = i18next.t(key);
      
      // Check if the element contains an icon (like the Dashboard link)
      const iconSpan = element.querySelector('.material-symbols-outlined');
      if (iconSpan) {
        // Keep the icon while updating the text
        iconSpan.nextSibling.nodeValue = ` ${translatedText}`;
      } 
      // Check if the element is a select option
      else if (element.tagName === 'OPTION') {
        element.textContent = translatedText;
      }
      else {
        // If no icon exists, replace entire text
        element.textContent = translatedText;
      }
    });
  }

  // Handle language change
  languageSelect.addEventListener('change', (event) => {
    const selectedLanguage = event.target.value;
    i18next.changeLanguage(selectedLanguage, () => {
      chrome.storage.sync.set({ language: selectedLanguage });
      updateContent(); // Update the content when the language changes
    });
  });

  // Load saved settings and apply them
  chrome.storage.sync.get(['isActivated', 'enabledMessageShown', 'fontSize', 'language', 'theme'], (data) => {
    const isActivated = data.isActivated !== undefined ? data.isActivated : true;
    const enabledMessageShown = data.enabledMessageShown || false;
    const fontSize = data.fontSize || 'medium';
    const language = data.language || 'en'; // Default language is English
    const theme = data.theme || 'dark'; // Default to dark mode

    activateSwitch.checked = isActivated;
    applyFontSize(fontSize);
    languageSelect.value = language; // Set the dropdown to the saved language
    i18next.changeLanguage(language, updateContent); // Change language and update content

    // Apply the saved theme
    applyTheme(theme);
    themeSwitch.checked = theme === 'light';

    if (isActivated && !enabledMessageShown) {
      alert('SKIP IT. Enabled');
      chrome.storage.sync.set({ enabledMessageShown: true });
    } else if (!isActivated) {
      alert('SKIP IT. Disabled');
    }
  });

  // Toggle activation status
  if (activateSwitch) {
    activateSwitch.addEventListener('change', () => {
      const isActivated = activateSwitch.checked;
      chrome.storage.sync.set({ isActivated });

      if (isActivated) {
        chrome.storage.sync.get('enabledMessageShown', (data) => {
          if (!data.enabledMessageShown) {
            alert('SKIP IT. Enabled');
            chrome.storage.sync.set({ enabledMessageShown: true });
          }
        });
      } else {
        alert('SKIP IT. Disabled');
      }
    });
  }

  // Show input field and add button when 'Add Website' is clicked
  if (addWebsiteButton) {
    addWebsiteButton.addEventListener('click', () => {
      addWebsiteButton.style.display = 'none';
      websiteInput.style.display = 'inline-block';
      addWebsiteConfirmButton.style.display = 'inline-block';
    });
  }

  // Function to add website to the list
  function addWebsite() {
    const website = websiteInput.value.trim();
    if (website) {
      const listItem = document.createElement('li');
      listItem.textContent = website;

      const removeButton = document.createElement('button');
      removeButton.className = 'remove-button';
      removeButton.innerHTML = `<svg viewBox="0 0 24 24"><path d="M18.3 5.7a1 1 0 0 0-1.4 0L12 10.6 7.1 5.7a1 1 0 1 0-1.4 1.4L10.6 12l-4.9 4.9a1 1 0 0 0 1.4 1.4L12 13.4l4.9 4.9a1 1 0 0 0 1.4-1.4L13.4 12l4.9-4.9a1 1 0 0 0 0-1.4z"/></svg>`;
      removeButton.addEventListener('click', () => listItem.remove());

      listItem.appendChild(removeButton);
      streamingPlatformsList.appendChild(listItem);

      websiteInput.value = '';
      websiteInput.style.display = 'none';
      addWebsiteConfirmButton.style.display = 'none';
      addWebsiteButton.style.display = 'inline-block';
    }
    
  }

  if (addWebsiteConfirmButton) {
    addWebsiteConfirmButton.addEventListener('click', addWebsite);
  }
  if (websiteInput) {
    websiteInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') addWebsite();
    });
  }

  // Function to apply the theme
  function applyTheme(theme) {
    document.body.classList.toggle('light-mode', theme === 'light');
  }

  // Theme switch functionality
  if (themeSwitch) {
    themeSwitch.addEventListener('change', () => {
      const theme = themeSwitch.checked ? 'light' : 'dark';
      applyTheme(theme);
      chrome.storage.sync.set({ theme });
    });
  }

  // Font size scalability section
  if (smallButton) {
    smallButton.addEventListener('click', () => {
      applyFontSize('small');
      chrome.storage.sync.set({ fontSize: 'small' });
    });
  }
  if (mediumButton) {
    mediumButton.addEventListener('click', () => {
      applyFontSize('medium');
      chrome.storage.sync.set({ fontSize: 'medium' });
    });
  }
  if (largeButton) {
    largeButton.addEventListener('click', () => {
      applyFontSize('large');
      chrome.storage.sync.set({ fontSize: 'large' });
    });
  }

  // Function to apply font size
  function applyFontSize(size) {
    document.body.classList.remove('small-text', 'medium-text', 'large-text');
    document.body.classList.add(`${size}-text`);
  }

  // Define the movies with way to fetch trigger warnings
  const movies = [
    {
      title: 'The Babadook',
      year: 2014,
      movie_id: 'babadook2014TriggerWarnings',
      platform: 'Netflix',
      link: 'https://www.netflix.com/title/70300205',
    },
    {
      title: 'Eternal Sunshine of the Spotless Mind',
      year: 2004,
      movie_id: 'eternalSunshineOfTheSpotlessMindTriggerWarnings',
      platform: 'Youtube',
      link: 'https://www.youtube.com/watch?v=ttPi99BJpIg',
    },
    {
      title: 'The Substitute',
      year: 1996,
      movie_id: 'theSubstituteTriggerWarnings',
      platform: 'Youtube',
      link: 'https://www.youtube.com/watch?v=ptrCBlS6cw4',
    },
    {
      title: 'How to Train Your Dragon',
      year: 2010,
      movie_id: 'HowToTrainYourDragonTriggerWarnings',
      platform: 'Netflix',
      link: 'https://www.netflix.com/title/70109893',
    },
    {
      title: 'Carry On',
      year: 2024,
      movie_id: 'CarryOnTriggerWarnings',
      platform: 'Netflix',
      link: 'https://www.netflix.com/title/81476963',
    },
    {
      title: 'Hereditary',
      year: 2018,
      movie_id: 'HereditaryTriggerWarnings',
      platform: 'Netflix',
      link: 'https://www.netflix.com/title/80238910',
    },
    {
      title: 'Mississippi Burning',
      year: 1988,
      movie_id: 'mississippiBurningTriggerWarnings',
      platform: 'Youtube',
      link: 'https://www.youtube.com/watch?v=pJTmThcDOcg',
    },
    {
      title: 'The Secret Life of Pets',
      year: 2016,
      movie_id: 'theSecretLifeOfPetsTriggerWarnings',
      platform: 'Netflix',
      link: 'https://www.netflix.com/watch/80095314',
    },
    
    {
      title: 'Criminal Minds S1E1',
      year: 2005,
      movie_id: 'criminalMindsS1E1TriggerWarnings',
      platform: 'Paramount',
      link: 'https://www.paramountplus.com/shows/video/vZ3WjUR9fks0d0fZHpqVrJonvIQ2V58O/',
    },
    {
      title: 'Whiplash',
      year: 2014,
      movie_id: 'whiplashTriggerWarnings',
      platform: 'Netflix',
      link: 'https://www.netflix.com/watch/70299275?trackId=255824129&tctx=0%2C0%2Cfeb48fbc-3146-4267-8baf-0d4d865941a5-22480525%2Cfeb48fbc-3146-4267-8baf-0d4d865941a5-22480525%7C2%2Cunknown%2C%2C%2CtitlesResults%2C70299275%2CVideo%3A70299275%2CminiDpPlayButton',
    },
    {
      title: 'Inside Out',
      year: 2015,
      movie_id: 'insideOutTriggerWarnings',
      platform: 'Disney Plus',
      link: 'https://www.disneyplus.com/play/d4b87168-7d0b-49bc-b138-457ab7723feb',
    },
    {
      title: 'It',
      year: 2017,
      movie_id: 'ITTriggerWarnings',
      platform: 'Netflix',
      link: 'https://www.netflix.com/title/80177770',
    },
    {
      title: 'Schindlers List',
      year: 1993,
      movie_id: 'schindlersListTriggerWarnings',
      platform: 'Netflix',
      link: 'https://www.netflix.com/title/60036359',
    },
    {
      title: 'Despicable Me 4',
      year: 2024,
      movie_id: 'despicableMeTriggerWarnings',
      platform: 'Netflix',
      link: 'https://www.netflix.com/title/81776693',
    },
    {
      title: 'Woman Of The Hour',
      year: 2024,
      movie_id: 'womanOfTheHourTriggerWarnings',
      platform: 'Netflix',
      link: 'https://www.netflix.com/title/81728818',
    },
    {
      title: 'The Menu',
      year: 2022,
      movie_id: 'TheMenuTriggerWarnings',
      platform: 'Netflix',
      link: 'https://www.netflix.com/watch/81609393?trackId=260117052&tctx=17%2C4%2Cc4adde94-39ad-4ce4-90a4-2e5a1f16bf22-21865980%2CNES_3916850F4C64D340473219C4D5190D-41D0777A399F6E-F1D3E90DD1_p_1738334318985%2C%2C%2C%2C%2C%2CVideo%3A81609393%2CdetailsPagePlayButton',
    },
    {
      title: 'Barbie',
      year: 2023,
      movie_id: 'barbieTriggerWarnings',
      platform: 'Netflix',
      link: 'https://www.netflix.com/watch/80157969',
    },
    {
      title: 'Matilda',
      year: 1996,
      movie_id: 'matildaTriggerWarnings',
      platform: 'Netflix',
      link: 'https://www.netflix.com/watch/70033005',
    },
    {
      title: 'The Breakfast Club',
      year: 1985,
      movie_id: 'theBreakfastClubTriggerWarnings',
      platform: 'Netflix',
      link: 'https://www.netflix.com/watch/330210',
    },
    {
      title: 'Sing',
      year: 2016,
      movie_id: 'singTriggerWarnings',
      platform: 'Netflix',
      link: 'https://www.netflix.com/watch/80117526',
    },
    {
      title: 'All Quiet on the Western Front',
      year: 2022,
      movie_id: 'allQuietOnTheWesternFrontTriggerWarnings',
      platform: 'Netflix',
      link: 'https://www.netflix.com/watch/81260280',
    },
    {
      title: 'Talk To Me',
      year: 2022,
      movie_id: 'talkToMeTriggerWarnings',
      platform: 'Netflix',
      link: 'https://www.netflix.com/watch/81700507',
    },
    {
      title: 'American Gangster',
      year: 2007,
      movie_id: 'americanGangsterTriggerWarnings',
      platform: 'Netflix',
      link: 'https://www.netflix.com/watch/70060009',
    }
  ];

  // Function to get top trigger warnings for each movie
  function fetchTopTriggers() {
    // Request background script to get the trigger warnings data
    chrome.runtime.sendMessage({ action: 'getTopTriggers' }, response => {
      if (response && response.triggerData) {
        updateMoviesWithTriggers(response.triggerData);
      } else {
        // If we can't get trigger data from background, fallback to loading content.js
        loadContentJSAndProcessTriggers();
      }
    });
  }

  function loadContentJSAndProcessTriggers() {
    // This function will be executed if we need to directly load and parse content.js
    fetch(chrome.runtime.getURL('js/content.js'))
      .then(response => response.text())
      .then(content => {
        const triggerDataMap = extractTriggersFromContentJS(content);
        updateMoviesWithTriggers(triggerDataMap);
      })
      .catch(error => {
        console.error('Error loading content.js:', error);
        renderMoviesWithFallbackTriggers();
      });
  }

  function extractTriggersFromContentJS(content) {
    const triggerDataMap = {};
    
    // Define the regexp pattern to match the array declarations
    const movieArraysRegex = /const\s+(\w+TriggerWarnings)\s*=\s*\[([\s\S]*?)\];/g;
    
    let match;
    while ((match = movieArraysRegex.exec(content)) !== null) {
      const movieId = match[1];
      const arrayContent = match[2];
      
      // Extract all warning fields from the array objects
      const warningsRegex = /warning:\s*"([^"]*)"/g;
      const warnings = [];
      
      let warningMatch;
      while ((warningMatch = warningsRegex.exec(arrayContent)) !== null) {
        warnings.push(warningMatch[1]);
      }
      
      triggerDataMap[movieId] = countTopWarnings(warnings);
    }
    
    return triggerDataMap;
  }

  function countTopWarnings(warnings) {
    // Process warnings that have "+" in them (e.g., "Fear + Grief")
    const flattenedWarnings = [];
    
    warnings.forEach(warning => {
      // Split compound warnings
      const parts = warning.split(' + ');
      parts.forEach(part => {
        flattenedWarnings.push(part.trim());
      });
    });
    
    // Count occurrences of each warning
    const warningCounts = {};
    flattenedWarnings.forEach(warning => {
      warningCounts[warning] = (warningCounts[warning] || 0) + 1;
    });
    
    // Convert to array, sort by count descending, and take top 3
    return Object.entries(warningCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(entry => entry[0]);
  }

  function updateMoviesWithTriggers(triggerDataMap) {
    movies.forEach(movie => {
      if (triggerDataMap[movie.movie_id]) {
        movie.triggers = triggerDataMap[movie.movie_id].join(', ');
      } else {
        movie.triggers = 'N/A'; // Fallback if no triggers found
      }
    });
    
    renderMovies(sortMovies('desc'));
  }

  function renderMoviesWithFallbackTriggers() {
    // Fallback trigger warnings if we can't load the data
    const fallbackTriggers = {
      'babadook2014TriggerWarnings': 'Fear, Supernatural Peril, Violence',
      'HowToTrainYourDragonTriggerWarnings': 'Parental Conflict, Emotional Rejection, Violence',
      'CarryOnTriggerWarnings': 'Violence, Threat, Fear',
      'HereditaryTriggerWarnings': 'Death, Grief, Disturbing Imagery',
      'criminalMindsS1E1TriggerWarnings': 'Violence, Abuse, Substance Use',
      'whiplashTriggerWarnings': 'Verbal Abuse, Violence, Self-Harm',
      'insideOutTriggerWarnings': 'Depression, Abandonment, Fear',
      'ITTriggerWarnings': 'Violence, Fear, Child Endangerment',
      'TheMenuTriggerWarnings': 'Violence, Profanity, Psychological Manipulation'
    };

    movies.forEach(movie => {
      movie.triggers = fallbackTriggers[movie.movie_id] || 'Violence, Fear';
    });
    
    renderMovies(sortMovies('desc'));
  }

  const moviesList = document.getElementById('movies-list');
  const movieSearch = document.getElementById('movie-search');
  const movieFilter = document.getElementById('movie-filter');

  function renderMovies(data) {
    moviesList.innerHTML = data
      .map((movie) => {
        // Convert platform name to lowercase and replace spaces for matching the image file
        const platformIcon = `/assets/images/${movie.platform.toLowerCase().replace(/\s/g, '')}.png`;
  
        // Set play button image based on the theme
        const playButtonLight = '/assets/images/play_circle_light.png';
        const playButtonDark = '/assets/images/play_circle_dark.png';
        const playButton = themeSwitch.checked ? playButtonLight : playButtonDark;
  
        return `
          <tr>
            <td>${movie.title}</td>
            <td>${movie.year}</td>
            <td>${movie.triggers}</td>
            <td><img src="${platformIcon}" alt="${movie.platform}" style="width: 35px; height: auto;" /></td>
            <td class="play-cell">
              <a href="${movie.link}" target="_blank">
                <img src="${playButton}" alt="Play Button" style="width: 35px; height: auto;" />
              </a>
            </td>
          </tr>
        `;
      })
      .join('');
  }

  function sortMovies(order) {
    return [...movies].sort((a, b) => {
      switch(order) {
        case 'asc':
          return a.year - b.year; // Sort by year ascending
        case 'desc':
          return b.year - a.year; // Sort by year descending
        case 'alpha-asc':
          return a.title.localeCompare(b.title); // Sort by title A→Z
        case 'alpha-desc':
          return b.title.localeCompare(a.title); // Sort by title Z→A
        default:
          return b.year - a.year; // Default to descending year
      }
    });
  }

  

  function filterMovies(searchText) {
    return movies.filter((movie) =>
      movie.title.toLowerCase().includes(searchText.toLowerCase())
    );
  }

  movieSearch.addEventListener('input', () => {
    const filteredMovies = filterMovies(movieSearch.value);
    const sortedMovies = sortMovies(movieFilter.value).filter((movie) =>
      filteredMovies.includes(movie)
    );
    renderMovies(sortedMovies);
  });

  movieFilter.addEventListener('change', () => {
    const filteredMovies = filterMovies(movieSearch.value);
    const sortedMovies = sortMovies(movieFilter.value).filter((movie) =>
      filteredMovies.includes(movie)
    );
    renderMovies(sortedMovies);
  });

  themeSwitch.addEventListener('change', () => {
    renderMovies(sortMovies('desc')); // Re-render movies to update play button icon
  });

  // Initialize by fetching trigger warnings and rendering movies
  fetchTopTriggers();
});