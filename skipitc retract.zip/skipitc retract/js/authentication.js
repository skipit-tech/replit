// Firebase Authentication Module
(function() {
    // Initialize Firebase with configuration
    function initializeFirebase() {
      if (typeof firebase === 'undefined') {
        console.error('Firebase is not defined. Make sure the Firebase scripts are loaded correctly.');
        return false;
      }
      
      try {
        // Firebase configuration
        const firebaseConfig = {
          apiKey: "AIzaSyBrAtUSIMqpqKyr37KUMjxjnuFllsO2RHY",
          authDomain: "skip-it-de152.firebaseapp.com",
          projectId: "skip-it-de152",
          storageBucket: "skip-it-de152.firebasestorage.app",
          messagingSenderId: "884682586679",
          appId: "1:884682586679:web:76daf7ef05ae1904cb9db2",
          measurementId: "G-4CQF5GLC3W"
        };
        
        // Check if Firebase is already initialized
        if (firebase.apps.length === 0) {
          firebase.initializeApp(firebaseConfig);
        }
        
        const auth = firebase.auth();
        const db = firebase.firestore();
        
        // Create Google Auth Provider
        const googleProvider = new firebase.auth.GoogleAuthProvider();
        googleProvider.setCustomParameters({
          prompt: 'select_account'
        });
        
        return { auth, db, googleProvider };
      } catch (error) {
        console.error('Error initializing Firebase:', error);
        return false;
      }
    }
    
    // Check if Firebase is initialized
    const firebaseInstance = initializeFirebase();
    if (!firebaseInstance) {
      return; // Exit if Firebase initialization failed
    }
    
    const { auth, db, googleProvider } = firebaseInstance;
    
    // Auth state observer
    auth.onAuthStateChanged((user) => {
      if (user) {
        // User is signed in
        console.log('User is signed in:', user.email);
        
        // Store user info in Chrome storage
        chrome.storage.sync.set({
          isAuthenticated: true,
          userId: user.uid,
          userEmail: user.email,
          userName: user.displayName,
          userPhoto: user.photoURL
        });
        
        // Update user data in Firestore
        db.collection('users').doc(user.uid).set({
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
          photoURL: user.photoURL,
          lastLogin: firebase.firestore.FieldValue.serverTimestamp()
        }, { merge: true });
        
        // Check subscription status of te user
        checkSubscriptionStatus(user.uid);
        
      } else {
        // User is signed out
        console.log('User is signed out');
        
        chrome.storage.sync.set({
          isAuthenticated: false,
          userId: null,
          userEmail: null,
          userName: null,
          userPhoto: null,
          isGoldUpgraded: false
        });
      }
    });
    
    // Sign in with Google
    async function signInWithGoogle() {
      try {
        const result = await auth.signInWithPopup(googleProvider);
        const user = result.user;
        
        // Return the user object
        return user;
      } catch (error) {
        console.error('Google sign-in error:', error);
        throw error;
      }
    }
    
    // Sign out
    async function signOut() {
      try {
        await auth.signOut();
        return { success: true };
      } catch (error) {
        console.error('Sign-out error:', error);
        throw error;
      }
    }
    
    // Check subscription status
    async function checkSubscriptionStatus(userId) {
      try {
        const userDoc = await db.collection('users').doc(userId).get();
        
        if (!userDoc.exists) {
          chrome.storage.sync.set({ isGoldUpgraded: false });
          return { isSubscribed: false };
        }
        
        const userData = userDoc.data();
        const isSubscribed = userData.subscriptionStatus === 'active';
        
        // Update Chrome storage with subscription status
        chrome.storage.sync.set({ isGoldUpgraded: isSubscribed });
        
        // Update badge if subscribed
        if (isSubscribed) {
          chrome.action.setBadgeText({ text: "GOLD" });
          chrome.action.setBadgeBackgroundColor({ color: "#FFD700" });
        } else {
          chrome.action.setBadgeText({ text: "" });
        }
        
        return { isSubscribed, userData };
      } catch (error) {
        console.error('Error checking subscription:', error);
        return { isSubscribed: false, error: error.message };
      }
    }
    
    // Export functions to window object
    window.authFunctions = {
      signInWithGoogle,
      signOut,
      checkSubscriptionStatus,
      getCurrentUser: () => auth.currentUser
    };
  })();