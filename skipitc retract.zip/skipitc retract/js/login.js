document.addEventListener('DOMContentLoaded', () => {
    // Load the theme and language settings from storage
    chrome.storage.sync.get(['theme', 'language', 'fontSize'], (data) => {
        // Apply theme
        const theme = data.theme || 'dark'; // Default to dark mode
        applyTheme(theme);
        
        // Apply font size if available
        const fontSize = data.fontSize || 'medium';
        applyFontSize(fontSize);
        
        // Apply language
        const language = data.language || 'en'; // Default to English
        // Make sure i18next is defined before calling this
        if (typeof i18next !== 'undefined') {
            initializeI18Next(language);
        } else {
            console.error("i18next is not loaded");
        }
    });
    
    // Function to apply theme
    function applyTheme(theme) {
        document.body.classList.toggle('light-mode', theme === 'light');
    }
    
    // Function to apply font size
    function applyFontSize(size) {
        document.body.classList.remove('small-text', 'medium-text', 'large-text');
        document.body.classList.add(`${size}-text`);
    }

    // Define the initializeI18Next function here
    function initializeI18Next(language) {
        i18next.init({
            lng: language,
            resources: {
                en: {
                    translation: {
                        "Dashboard": "Dashboard",
                        "Trigger Warning Settings": "Trigger Warning Settings",
                        "About": "About",
                        "Login": "Login",
                        "Get Help": "Get Help",
                        "Email": "Email",
                        "Password": "Password",
                        "Forgot password?": "Forgot password?",
                        "Don't have an account?": "Don't have an account?",
                        "Or": "Or",
                        "Login with Facebook": "Login with Facebook",
                        "Login with Google": "Login with Google",
                        "Logout": "Logout",
                        "My Account": "My Account"
                    }
                },
                es: {
                    translation: {
                        "Dashboard": "Tablero",
                        "Trigger Warning Settings": "Configuración de Advertencias",
                        "About": "Acerca de",
                        "Login": "Iniciar Sesión",
                        "Get Help": "Obtener Ayuda",
                        "Email": "Correo electrónico",
                        "Password": "Contraseña",
                        "Forgot password?": "¿Olvidaste tu contraseña?",
                        "Don't have an account?": "¿No tienes una cuenta?",
                        "Or": "O",
                        "Login with Facebook": "Iniciar sesión con Facebook",
                        "Login with Google": "Iniciar sesión con Google",
                        "Logout": "Cerrar sesión",
                        "My Account": "Mi Cuenta"
                    }
                },
                fr: {
                    translation: {
                        "Dashboard": "Tableau de Bord",
                        "Trigger Warning Settings": "Paramètres d'Avertissement",
                        "About": "À Propos",
                        "Login": "Connexion",
                        "Get Help": "Obtenir de l'Aide",
                        "Email": "E-mail",
                        "Password": "Mot de passe",
                        "Forgot password?": "Mot de passe oublié ?",
                        "Don't have an account?": "Vous n'avez pas de compte ?",
                        "Or": "Ou",
                        "Login with Facebook": "Se connecter avec Facebook",
                        "Login with Google": "Se connecter avec Google",
                        "Logout": "Déconnexion",
                        "My Account": "Mon Compte"
                    }
                }
            }
        }, () => {
            updateContent(); // Update content once i18next is initialized
        });
    }

    // Ensure Sidebar Highlighting for Login Page
    function highlightActiveSidebar() {
        // First check if we on the login page by examining the URL
        const currentPath = window.location.pathname;
        const isLoginPage = currentPath.includes('login.html');
        
        // Remove active class from all navigation items
        document.querySelectorAll('.nav-items li a, .bottom-links a').forEach(link => {
            link.classList.remove('active');
            const icon = link.querySelector('.material-symbols-outlined');
            if (icon) {
                icon.classList.remove('active');
            }
        });
        
        // If you on the login page, add active class to login link
        if (isLoginPage) {
            const loginLink = document.querySelector('.bottom-links a[href="login.html"]');
            if (loginLink) {
                loginLink.classList.add('active');
                const icon = loginLink.querySelector('.material-symbols-outlined');
                if (icon) {
                    icon.classList.add('active');
                }
            }
        }
    }

    highlightActiveSidebar(); // Run it initially

    const loginForm = document.querySelector('.login-form form');
    const loginSection = document.getElementById('login-section');
    const accountSection = document.getElementById('account-section');
    const logoutButton = document.querySelector('.logout-button');
    const upgradeButton = document.querySelector('.upgrade-button');
    const googleLoginButton = document.querySelector('.google-button');
    const emailLoginButton = document.querySelector('button[type="submit"]');
    const userInfo = document.querySelector('.user-info');
    const loadingIndicator = document.querySelector('.loading-indicator');
    const dashboardButton = document.querySelector('.dashboard-button');

    // Password visibility toggle
    const togglePassword = document.getElementById('togglePassword');
    const passwordInputField = document.getElementById('password');

    if (togglePassword && passwordInputField) {
        togglePassword.addEventListener('click', () => {
            const isPasswordVisible = passwordInputField.type === 'text';

            if (isPasswordVisible) {
                passwordInputField.type = 'password';
                togglePassword.classList.remove('bi-eye');
                togglePassword.classList.add('bi-eye-slash');
            } else {
                passwordInputField.type = 'text';
                togglePassword.classList.remove('bi-eye-slash');
                togglePassword.classList.add('bi-eye');
            }
        });
    }

    // Check authentication state on page load
    function checkAuthState() {
        if (loadingIndicator) {
            loadingIndicator.style.display = 'flex'; // Changed to flex for better centering
        }
        
        chrome.storage.sync.get(['isAuthenticated', 'userName', 'userEmail', 'userPhoto'], (data) => {
            if (data.isAuthenticated) {
                // User is already authenticated, show account section
                if (loginSection) loginSection.style.display = 'none';
                if (accountSection) {
                    accountSection.style.display = 'block';
                    
                
                    if (userInfo) {
                        let userHtml = '';
                        if (data.userPhoto) {
                            userHtml += `<img src="${data.userPhoto}" alt="Profile Photo" class="profile-photo">`;
                        }
                        userHtml += `<div class="user-details">`;
                        userHtml += `<h3>${data.userName || 'User'}</h3>`;
                        userHtml += `<p>${data.userEmail || ''}</p>`;
                        userHtml += `</div>`;
                        
                        userInfo.innerHTML = userHtml;
                    }
                }
            } else {
                // User is not authenticated, show login section
                if (loginSection) loginSection.style.display = 'block';
                if (accountSection) accountSection.style.display = 'none';
            }
            
            if (loadingIndicator) {
                loadingIndicator.style.display = 'none';
            }
        });
    }

    // Call this function on page load
    checkAuthState();

    // Handle Google login click
    if (googleLoginButton) {
        googleLoginButton.addEventListener('click', (e) => {
            e.preventDefault();
            
            if (loadingIndicator) {
                loadingIndicator.style.display = 'flex';
            }
            
            // Use window.authFunctions.signInWithGoogle() instead of window.googleSignIn()
            if (window.authFunctions && window.authFunctions.signInWithGoogle) {
                window.authFunctions.signInWithGoogle()
                    .then((user) => {
                        checkAuthState(); // Refresh the UI after successful login
                    })
                    .catch((error) => {
                        console.error("Google login error:", error);
                        alert("Login failed: " + (error.message || "Please try again later."));
                        
                        if (loadingIndicator) {
                            loadingIndicator.style.display = 'none';
                        }
                    });
            } else {
                console.error("Auth functions not available");
                alert("Authentication system is not loaded. Please refresh the page and try again.");
                
                if (loadingIndicator) {
                    loadingIndicator.style.display = 'none';
                }
            }
        });
    }

    // Handle form submission for email/password login
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
        
            alert("Email/password login is not available yet. Please use Google login.");
        });
    }

    // Handle "Upgrade" button click - Redirect to pricing plan page
    if (upgradeButton) {
        upgradeButton.addEventListener('click', () => {
            // Navigate to the pricing plan page
            window.location.href = 'pricingplan.html';
        });
    }

    // Handle dashboard button click
    if (dashboardButton) {
        dashboardButton.addEventListener('click', () => {
            // Navigate to dashboard page
            window.location.href = 'settings.html';
        });
    }

    // Handle logout
    if (logoutButton) {
        logoutButton.addEventListener('click', () => {
            if (loadingIndicator) {
                loadingIndicator.style.display = 'flex';
            }
            
            // Use window.authFunctions.signOut() instead of window.signOut()
            if (window.authFunctions && window.authFunctions.signOut) {
                window.authFunctions.signOut()
                    .then(() => {
                        checkAuthState(); // Refresh the UI after logout
                    })
                    .catch((error) => {
                        console.error("Logout error:", error);
                        alert("Logout failed: " + (error.message || "Please try again later."));
                        
                        if (loadingIndicator) {
                            loadingIndicator.style.display = 'none';
                        }
                    });
            } else {
                console.error("Auth functions not available");
                alert("Authentication system is not loaded. Please refresh the page and try again.");
                
                if (loadingIndicator) {
                    loadingIndicator.style.display = 'none';
                }
            }
        });
    }

    // Function to update content based on the selected language
    function updateContent() {
        document.querySelectorAll('[data-i18n]').forEach((element) => {
            const key = element.getAttribute('data-i18n');
            const translation = i18next.t(key);

            const iconSpan = element.querySelector('.material-symbols-outlined');
            if (iconSpan) {
                const iconHTML = iconSpan.outerHTML;
                element.innerHTML = `${iconHTML} ${translation}`;
            } else {
                element.textContent = translation;
            }
        });
        
        // Update input placeholders
        const emailInput = document.querySelector('.input-group input[type="email"]');
        const passwordInput = document.querySelector('.input-group input[type="password"]');
        const forgotPasswordText = document.querySelector('.forgot-password');
        const dontHaveAccountText = document.querySelector('.signup-link span');
        const orText = document.querySelector('.divider span');
        const loginWithFacebookText = document.querySelector('.facebook-button span');
        const loginWithGoogleText = document.querySelector('.google-button span');
        
        if (emailInput) emailInput.placeholder = i18next.t("Email");
        if (passwordInput) passwordInput.placeholder = i18next.t("Password");
        
        // Update button texts
        if (googleLoginButton && googleLoginButton.querySelector('span')) 
            googleLoginButton.querySelector('span').textContent = i18next.t("Login with Google");
        if (loginWithFacebookText) loginWithFacebookText.textContent = i18next.t("Login with Facebook");
        if (forgotPasswordText) forgotPasswordText.textContent = i18next.t("Forgot password?");
        if (dontHaveAccountText) dontHaveAccountText.textContent = i18next.t("Don't have an account?");
        if (orText) orText.textContent = i18next.t("Or");
        if (logoutButton) logoutButton.textContent = i18next.t("Logout");

        highlightActiveSidebar(); // Reapply sidebar highlight after translation updates
    }
});