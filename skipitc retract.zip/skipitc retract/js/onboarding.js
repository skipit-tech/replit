// onboarding.js 

let currentStep = 1;
const totalSteps = 5; // Includes verification step

// Show the current step and update dots
function showStep(step) {
    // Check if trying to access steps beyond verification without being verified
    if (step > 2) {
        chrome.storage.local.get(['accessVerified'], (result) => {
            if (!result.accessVerified) {
                // Not verified, stay on verification step
                actuallyShowStep(2);
                // Show error message
                const accessError = document.getElementById('access-error');
                if (accessError) {
                    accessError.textContent = 'Please verify your access code to continue.';
                    accessError.style.display = 'block';
                }
            } else {
                // Verified, proceed normally
                actuallyShowStep(step);
            }
        });
    } else {
        // Steps 1-2 are always accessible
        actuallyShowStep(step);
    }
}

// The actual function to update the UI for steps
function actuallyShowStep(step) {
    // Hide all steps
    document.querySelectorAll('.step').forEach(el => {
        el.classList.remove('active');
    });
    
    // Show the current step
    document.getElementById(`step-${step}`).classList.add('active');
    
    // Update progress dots
    document.querySelectorAll('.dot').forEach(dot => {
        if (parseInt(dot.dataset.step) <= step) {
            dot.classList.add('active');
        } else {
            dot.classList.remove('active');
        }
    });
    
    // Update current step tracker
    currentStep = step;
}

// Move to the next step
function nextStep() {
    if (currentStep < totalSteps) {
        showStep(currentStep + 1);
    }
}

// Move to the previous step
function previousStep() {
    if (currentStep > 1) {
        showStep(currentStep - 1);
    }
}

// Skip authentication
function skipAuth() {
    // Update storage to indicate auth was skipped but prompted
    chrome.storage.sync.set({ authPrompted: true });
    nextStep();
}

// Complete onboarding
function finishOnboarding() {
    // Save trigger warning selections
    const selectedWarnings = [];
    
    if (document.getElementById('abuse-checkbox').checked) selectedWarnings.push('Abuse');
    if (document.getElementById('violence-checkbox').checked) selectedWarnings.push('Violence');
    if (document.getElementById('mental-illness-checkbox').checked) selectedWarnings.push('Mental Illness');
    if (document.getElementById('substance-use-checkbox').checked) selectedWarnings.push('Substance Use');
    if (document.getElementById('illness-injury-checkbox').checked) selectedWarnings.push('Illness/Injury');
    if (document.getElementById('discrimination-checkbox').checked) selectedWarnings.push('Discrimination');
    
    // Save settings to storage
    chrome.storage.sync.set({ 
        triggerWarnings: selectedWarnings,
        onboardingCompleted: true
    });
    
    // Redirect to dashboard
    window.location.href = 'settings.html';
}

// Initialize access codes if needed
function ensureAccessCodesInitialized() {
    chrome.storage.local.get(['validAccessCodes'], (result) => {
        if (!result.validAccessCodes || !Array.isArray(result.validAccessCodes) || result.validAccessCodes.length === 0) {
            // Access codes not found in storage, initialize them
            // This assumes that initializeAccessCodes is available from the included access_code.js
            if (typeof initializeAccessCodes === 'function') {
                initializeAccessCodes();
            } else {
                console.error('initializeAccessCodes function not found. Make sure access_code.js is loaded before onboarding.js');
            }
        }
    });
}

// Handle access code verification
function verifyAccessCode() {
    const accessCodeInput = document.getElementById('access-code-input');
    const accessError = document.getElementById('access-error');
    
    if (!accessCodeInput || !accessError) return;
    
    const enteredCode = accessCodeInput.value.trim();
    
    if (!enteredCode) {
        accessError.textContent = 'Please enter an access code.';
        accessError.style.display = 'block';
        return;
    }
    
    // Check if the entered code is valid
    chrome.storage.local.get(['validAccessCodes', 'accessCodeMetadata'], (result) => {
        const validCodes = result.validAccessCodes || [];
        const metadata = result.accessCodeMetadata || {};
        
        if (validCodes.includes(enteredCode)) {
            // Valid code - mark as verified and continue
            
            // Update metadata if it exists
            if (metadata[enteredCode]) {
                metadata[enteredCode].used = true;
                metadata[enteredCode].lastUsed = new Date().toISOString();
                
                chrome.storage.local.set({ accessCodeMetadata: metadata });
            }
            
            chrome.storage.local.set({ accessVerified: true }, () => {
                // Continue to next step
                nextStep();
            });
        } else {
            // Invalid code - show error
            accessError.textContent = 'Invalid access code. Please try again.';
            accessError.style.display = 'block';
            accessCodeInput.value = '';
            
            // Track failed attempts
            trackFailedAttempt();
        }
    });
}

// Track failed login attempts
function trackFailedAttempt() {
    chrome.storage.local.get(['failedAttempts', 'lastFailedAttempt'], (result) => {
        const now = Date.now();
        const failedAttempts = result.failedAttempts || 0;
        const lastFailedAttempt = result.lastFailedAttempt || 0;
        
        // Reset counter if last attempt was more than 30 minutes ago
        const resetThreshold = 30 * 60 * 1000; // 30 minutes in milliseconds
        const newFailedAttempts = (now - lastFailedAttempt > resetThreshold) ? 1 : failedAttempts + 1;
        
        chrome.storage.local.set({
            failedAttempts: newFailedAttempts,
            lastFailedAttempt: now
        });
        
        // Temporary lockout after too many failed attempts
        if (newFailedAttempts >= 5) {
            const lockoutDuration = 10 * 60 * 1000; // 10 minutes
            
            chrome.storage.local.set({
                lockedUntil: now + lockoutDuration
            });
            
            const accessError = document.getElementById('access-error');
            const verifyButton = document.getElementById('verify-access-button');
            const accessCodeInput = document.getElementById('access-code-input');
            
            if (accessError) accessError.textContent = 'Too many failed attempts. Please try again later.';
            if (verifyButton) verifyButton.disabled = true;
            if (accessCodeInput) accessCodeInput.disabled = true;
            
            // Enable access after lockout period
            setTimeout(() => {
                if (verifyButton) verifyButton.disabled = false;
                if (accessCodeInput) accessCodeInput.disabled = false;
                if (accessError) {
                    accessError.textContent = 'Please try again.';
                    accessError.style.display = 'none';
                }
            }, lockoutDuration);
        }
    });
}

// Check for lockout status
function checkLockoutStatus() {
    chrome.storage.local.get(['lockedUntil'], (result) => {
        const now = Date.now();
        const lockedUntil = result.lockedUntil || 0;
        
        if (lockedUntil > now) {
            // Still locked out
            const remainingTime = Math.ceil((lockedUntil - now) / (60 * 1000)); // in minutes
            
            const accessError = document.getElementById('access-error');
            const verifyButton = document.getElementById('verify-access-button');
            const accessCodeInput = document.getElementById('access-code-input');
            
            if (accessError) {
                accessError.textContent = `Too many failed attempts. Please try again in ${remainingTime} minutes.`;
                accessError.style.display = 'block';
            }
            if (verifyButton) verifyButton.disabled = true;
            if (accessCodeInput) accessCodeInput.disabled = true;
            
            // Check again after 1 minute
            setTimeout(checkLockoutStatus, 60 * 1000);
        }
    });
}

// Check if the user is already signed in
function checkAuthStatus() {
    chrome.storage.sync.get(['isAuthenticated', 'onboardingCompleted'], (data) => {
        chrome.storage.local.get(['accessVerified'], (localData) => {
            if (data.onboardingCompleted && localData.accessVerified) {
                // If onboarding was already completed and access verified, go to dashboard
                window.location.href = 'settings.html';
            } else if (data.onboardingCompleted && !localData.accessVerified) {
                // If onboarding completed but access not verified, go to verification step
                showStep(2);
            } else if (data.isAuthenticated && localData.accessVerified) {
                // If already authenticated and verified, skip to the last step
                showStep(5);
            } else if (localData.accessVerified) {
                // If access is verified but not authenticated, go to auth step
                showStep(4);
            } else {
                // Start from the beginning
                showStep(1);
            }
        });
    });
}

// Setup event listeners (excluding Google sign-in which is handled by auth-handler.js)
function setupEventListeners() {
    // Verification button
    const verifyButton = document.getElementById('verify-access-button');
    if (verifyButton) {
        verifyButton.addEventListener('click', verifyAccessCode);
    }
    
    // Next/previous buttons
    const nextButtons = document.querySelectorAll('.btn-primary');
    nextButtons.forEach(button => {
        if (button.id !== 'verify-access-button' && button.id !== 'google-signin-button') {
            button.addEventListener('click', function() {
                if (button.textContent.includes('Get Started')) {
                    finishOnboarding();
                } else {
                    nextStep();
                }
            });
        }
    });
    
    const prevButtons = document.querySelectorAll('.btn-secondary');
    prevButtons.forEach(button => {
        button.addEventListener('click', previousStep);
    });
    
    // Access code input
    const accessCodeInput = document.getElementById('access-code-input');
    if (accessCodeInput) {
        accessCodeInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                verifyAccessCode();
            }
        });
        
        // Clear error when typing
        accessCodeInput.addEventListener('input', () => {
            const accessError = document.getElementById('access-error');
            if (accessError) {
                accessError.style.display = 'none';
            }
        });
    }
}

// Initialize onboarding
document.addEventListener('DOMContentLoaded', () => {
    // Make sure access codes are initialized
    ensureAccessCodesInitialized();
    
    // Check auth status and lockout status
    checkAuthStatus();
    checkLockoutStatus();
    
    setupEventListeners();
});