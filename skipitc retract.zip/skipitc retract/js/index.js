const functions = require('firebase-functions');
const admin = require('firebase-admin');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

admin.initializeApp();
const db = admin.firestore();

// Create a checkout session
exports.createCheckoutSession = functions.https.onCall(async (data, context) => {
  // Ensure the user is authenticated
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'You must be logged in to make a payment');
  }

  const userId = context.auth.uid;
  const { planId, successUrl, cancelUrl } = data;
  
  // Map plan IDs to Stripe price IDs
  const priceMap = {
    'personal': 'price_1OuXRoLIgUV9kBkILR1vNHbm', // Replace with your actual Stripe price IDs
    'family': 'price_1OuXTBLIgUV9kBkIBH7xbMSZ',
    'organization': 'price_1OuXTwLIgUV9kBkIeCiIfJQT'
  };
  
  const priceId = priceMap[planId];
  if (!priceId) {
    throw new functions.https.HttpsError('invalid-argument', 'Invalid plan selected');
  }

  try {
    // Create the checkout session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{
        price: priceId,
        quantity: 1
      }],
      mode: 'subscription',
      success_url: successUrl,
      cancel_url: cancelUrl,
      client_reference_id: userId,
      metadata: {
        userId: userId,
        planId: planId
      }
    });

    // Store the session in Firestore
    await db.collection('customers').doc(userId).collection('checkout_sessions').doc(session.id).set({
      sessionId: session.id,
      url: session.url,
      created: admin.firestore.FieldValue.serverTimestamp(),
      planId: planId,
      status: 'created'
    });

    return { sessionId: session.id, url: session.url };
  } catch (error) {
    console.error('Error creating checkout session:', error);
    throw new functions.https.HttpsError('internal', error.message);
  }
});

// Listen for Stripe webhook events
exports.stripeWebhook = functions.https.onRequest(async (req, res) => {
  const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
  const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;
  
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    // Verify the webhook signature
    event = stripe.webhooks.constructEvent(req.rawBody, sig, endpointSecret);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // Handle the event
  switch (event.type) {
    case 'checkout.session.completed':
      const session = event.data.object;
      // Process the successful payment
      await handleSuccessfulPayment(session);
      break;
    case 'invoice.paid':
      const invoice = event.data.object;
      // Process successful subscription payment
      await handlePaidInvoice(invoice);
      break;
    case 'customer.subscription.updated':
    case 'customer.subscription.deleted':
      const subscription = event.data.object;
      // Update subscription status
      await handleSubscriptionUpdate(subscription);
      break;
    default:
      console.log(`Unhandled event type ${event.type}`);
  }

  // Return a 200 response to acknowledge receipt of the event
  res.status(200).send('Received');
});

// Helper function to handle successful checkout
async function handleSuccessfulPayment(session) {
  const userId = session.metadata.userId;
  const planId = session.metadata.planId;
  
  if (!userId) {
    console.error('No userId found in session metadata');
    return;
  }

  try {
    // Update the user's subscription status in Firestore
    await db.collection('users').doc(userId).set({
      subscriptionPlan: planId,
      subscriptionStatus: 'active',
      stripeCustomerId: session.customer,
      subscriptionId: session.subscription,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true });

    // Update the checkout session status
    if (session.id) {
      await db.collection('customers').doc(userId).collection('checkout_sessions').doc(session.id).update({
        status: 'completed',
        completed: admin.firestore.FieldValue.serverTimestamp()
      });
    }

    console.log(`Updated subscription status for user ${userId} to ${planId}`);
  } catch (error) {
    console.error('Error updating user subscription status:', error);
  }
}

// Helper function to handle paid invoices
async function handlePaidInvoice(invoice) {
  if (invoice.subscription) {
    // Look up the subscription to find the customer
    try {
      const subscription = await stripe.subscriptions.retrieve(invoice.subscription);
      const customerId = subscription.customer;
      
      // Query Firestore to find the user with this Stripe customer ID
      const usersRef = db.collection('users');
      const snapshot = await usersRef.where('stripeCustomerId', '==', customerId).get();
      
      if (snapshot.empty) {
        console.log('No matching users found for Stripe customer:', customerId);
        return;
      }
      
      // Update each matching user (should be just one)
      snapshot.forEach(doc => {
        doc.ref.update({
          subscriptionStatus: 'active',
          lastPaymentDate: admin.firestore.FieldValue.serverTimestamp()
        });
        console.log(`Updated subscription status for user ${doc.id} after invoice payment`);
      });
    } catch (error) {
      console.error('Error handling paid invoice:', error);
    }
  }
}

// Helper function to handle subscription updates
async function handleSubscriptionUpdate(subscription) {
  const customerId = subscription.customer;
  const status = subscription.status; // 'active', 'canceled', 'unpaid', etc.
  
  try {
    // Query Firestore to find the user with this Stripe customer ID
    const usersRef = db.collection('users');
    const snapshot = await usersRef.where('stripeCustomerId', '==', customerId).get();
    
    if (snapshot.empty) {
      console.log('No matching users found for Stripe customer:', customerId);
      return;
    }
    
    // Update subscription status for each matching user
    snapshot.forEach(doc => {
      doc.ref.update({
        subscriptionStatus: status,
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      });
      console.log(`Updated subscription status to ${status} for user ${doc.id}`);
    });
  } catch (error) {
    console.error('Error handling subscription update:', error);
  }
}