// Firebase configuration and authentication setup
let auth;
let db;
let functions;

// Initialize Firebase if the scripts are loaded
function initializeFirebase() {
  try {
    if (typeof firebase !== 'undefined') {
      const firebaseConfig = {
        apiKey: "AIzaSyBrAtUSIMqpqKyr37KUMjxjnuFllsO2RHY",
        authDomain: "skip-it-de152.firebaseapp.com",
        projectId: "skip-it-de152",
        storageBucket: "skip-it-de152.firebasestorage.app",
        messagingSenderId: "884682586679",
        appId: "1:884682586679:web:76daf7ef05ae1904cb9db2",
        measurementId: "G-4CQF5GLC3W"
      };

      // Initialize Firebase if not already initialized
      if (!firebase.apps || !firebase.apps.length) {
        firebase.initializeApp(firebaseConfig);
      }

      // Set up auth and firestore references
      auth = firebase.auth();
      db = firebase.firestore();
      functions = firebase.functions();
      
      // Set up auth state listener
      auth.onAuthStateChanged(handleAuthStateChange);
      
      return true;
    }
  } catch (error) {
    console.error("Firebase initialization error:", error);
  }
  return false;
}

// Handle authentication state changes
function handleAuthStateChange(user) {
  if (user) {
    console.log('User is signed in:', user.email);
    
    // Store authentication info in Chrome storage
    chrome.storage.sync.set({ 
      isAuthenticated: true,
      userId: user.uid,
      userEmail: user.email,
      userName: user.displayName,
      userPhoto: user.photoURL
    });
    
    // Check subscription status
    checkSubscriptionStatus(user.uid)
      .then(({ isSubscribed }) => {
        chrome.storage.sync.set({ isGoldUpgraded: isSubscribed });
        
        // Update badge to show subscription status
        if (isSubscribed) {
          chrome.action.setBadgeText({ text: "GOLD" });
          chrome.action.setBadgeBackgroundColor({ color: "#FFD700" });
        } else {
          chrome.action.setBadgeText({ text: "" });
        }
      })
      .catch(error => {
        console.error("Error checking subscription:", error);
      });
  } else {
    console.log('User is signed out');
    chrome.storage.sync.set({ 
      isAuthenticated: false,
      userId: null,
      userEmail: null,
      userName: null,
      userPhoto: null,
      isGoldUpgraded: false
    });
    chrome.action.setBadgeText({ text: "" });
  }
}

// Check user's subscription status
async function checkSubscriptionStatus(userId) {
  try {
    if (!db) return { isSubscribed: false };
    
    const userRef = db.collection('users').doc(userId);
    const userDoc = await userRef.get();
    
    if (!userDoc.exists) {
      return { isSubscribed: false };
    }
    
    const userData = userDoc.data();
    
    // Check for active subscription in the user data
    if (userData.subscriptionStatus === 'active') {
      return { isSubscribed: true, userData };
    }
    
    // Alternate method: check the subscriptions collection in future db implementation
    const subscriptionRef = await db.collection('subscriptions')
      .where('userId', '==', userId)
      .where('status', 'in', ['active', 'trialing'])
      .limit(1)
      .get();
    
    return { 
      isSubscribed: !subscriptionRef.empty,
      subscriptionData: subscriptionRef.empty ? null : subscriptionRef.docs[0].data(),
      userData: userData
    };
  } catch (error) {
    console.error("Error checking subscription:", error);
    return { isSubscribed: false, error: error.message };
  }
}

// Extension installation and update handling
chrome.runtime.onInstalled.addListener((details) => {
  console.log('SKIP IT. extension installed.');
  
  if (details.reason === 'install') {
    // Set default settings on first install
    chrome.storage.sync.set({
      triggerWarnings: ['Abuse', 'Violence', 'Mental Illness'],
      customWarnings: [],
      previewTimer: 10,
      positionSetting: 'top-right',
      fontSize: 'medium',
      language: 'en',
      theme: 'dark',
      isActivated: true,
      authPrompted: false,
      isAuthenticated: false,
      isGoldUpgraded: false
    });
    
    // Open onboarding page on install
    chrome.tabs.create({ url: 'html/onboarding.html' });
  } else if (details.reason === 'update') {
    console.log('SKIP IT Extension updated');
  }
  
  // Initialize by extracting and caching trigger warnings
  extractTriggersFromContentJS()
    .then(triggerData => {
      console.log('Trigger warnings extracted and cached successfully.');
    })
    .catch(error => {
      console.error('Failed to extract initial trigger warnings:', error);
    });
});

// Handle extension icon click
chrome.action.onClicked.addListener((tab) => {
  chrome.storage.local.get(['accessVerified'], (localData) => {
    chrome.storage.sync.get(['onboardingCompleted', 'authPrompted', 'isAuthenticated'], (syncData) => {
      // Always set the popup, but it'll check in the popup if verification is complete
      chrome.action.setPopup({ popup: 'html/popup.html' });
      
      // If user hasn't completed onboarding and verification, direct them there
      if (!syncData.onboardingCompleted || !localData.accessVerified) {
        chrome.tabs.create({ url: 'html/onboarding.html' });
      }
      // If user hasn't been prompted for auth yet, show auth page
      else if (!syncData.authPrompted && !syncData.isAuthenticated) {
        chrome.tabs.create({ url: 'html/login.html' });
        chrome.storage.sync.set({ authPrompted: true });
      } else {
        // Open popup
        chrome.action.openPopup();
      }
    });
  });
});

// Function to extract top trigger warnings from content.js
function extractTriggersFromContentJS() {
  return new Promise((resolve, reject) => {
    fetch(chrome.runtime.getURL('js/content.js'))
      .then(response => response.text())
      .then(content => {
        const triggerDataMap = {};
        
        // Define regexp pattern to match array declarations
        const movieArraysRegex = /const\s+(\w+TriggerWarnings)\s*=\s*\[([\s\S]*?)\];/g;
        
        let match;
        while ((match = movieArraysRegex.exec(content)) !== null) {
          const movieId = match[1];
          const arrayContent = match[2];
          
          // Extract all warning fields from array objects
          const warningsRegex = /warning:\s*"([^"]*)"/g;
          const warnings = [];
          
          let warningMatch;
          while ((warningMatch = warningsRegex.exec(arrayContent)) !== null) {
            warnings.push(warningMatch[1]);
          }
          
          triggerDataMap[movieId] = countTopWarnings(warnings);
        }
        
        // Cache results
        chrome.storage.local.set({ 
          triggerDataMap: triggerDataMap,
          triggerDataTimestamp: Date.now()
        });
        
        resolve(triggerDataMap);
      })
      .catch(error => {
        console.error('Error loading content.js:', error);
        reject(error);
      });
  });
}

function countTopWarnings(warnings) {
  // Process warnings that have "+" in them (e.g., "Fear + Grief")
  const flattenedWarnings = [];
  
  warnings.forEach(warning => {
    // Split compound warnings
    const parts = warning.split(' + ');
    parts.forEach(part => {
      flattenedWarnings.push(part.trim());
    });
  });
  
  // Count occurrences of each warning
  const warningCounts = {};
  flattenedWarnings.forEach(warning => {
    warningCounts[warning] = (warningCounts[warning] || 0) + 1;
  });
  
  // Convert to array, sort by count descending, and take top 4
  return Object.entries(warningCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4)
    .map(entry => entry[0]);
}

// Check authentication status when extension loads
function checkAuthOnStartup() {
  chrome.storage.sync.get(['isAuthenticated', 'authPrompted'], (data) => {
    if (!data.isAuthenticated && !data.authPrompted) {
      // Open login page on first run
      chrome.tabs.create({ url: 'html/login.html' });
      chrome.storage.sync.set({ authPrompted: true });
    }
  });
}

// Listen for messages from content scripts or popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // Handle getting top triggers
  if (request.action === 'getTopTriggers') {
    // Check if we have cached data that's not too old (less than 1 hour)
    chrome.storage.local.get(['triggerDataMap', 'triggerDataTimestamp'], data => {
      const cachedData = data.triggerDataMap;
      const timestamp = data.triggerDataTimestamp || 0;
      const oneHour = 60 * 60 * 1000; // milliseconds!!!!!
      
      if (cachedData && (Date.now() - timestamp < oneHour)) {
        // Use cached data if it's fresh
        sendResponse({ triggerData: cachedData });
      } else {
        // Get new fresh data
        extractTriggersFromContentJS()
          .then(triggerData => {
            sendResponse({ triggerData });
          })
          .catch(error => {
            console.error('Error extracting triggers:', error);
            sendResponse({ error: 'Failed to extract trigger warnings' });
          });
        
        // Return true to indicate we'll send a response asynchronously
        return true;
      }
    });
    
    // Return true to indicate we'll send a response asynchronously
    return true;
  }
  
  // Handle authentication status check
  else if (request.action === 'getAuthStatus') {
    // Try to initialize Firebase if it's not already initialized
    if (!auth && !initializeFirebase()) {
      // If Firebase isn't available, check storage instead
      chrome.storage.sync.get(['isAuthenticated', 'userId', 'userEmail', 'userName', 'userPhoto'], (data) => {
        sendResponse({
          isAuthenticated: data.isAuthenticated || false,
          user: data.isAuthenticated ? {
            uid: data.userId,
            email: data.userEmail,
            displayName: data.userName,
            photoURL: data.userPhoto
          } : null
        });
      });
      return true;
    }
    
    // Use Firebase auth if available
    const user = auth.currentUser;
    if (user) {
      sendResponse({
        isAuthenticated: true,
        user: {
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
          photoURL: user.photoURL
        }
      });
    } else {
      sendResponse({ isAuthenticated: false });
    }
    return true;
  }
  
  // Handle subscription status check
  else if (request.action === 'checkSubscription') {
    chrome.storage.sync.get(['isAuthenticated', 'userId', 'isGoldUpgraded'], (data) => {
      if (data.isAuthenticated && data.userId) {
        if (db) {
          // Get fresh subscription data if Firebase is available
          checkSubscriptionStatus(data.userId)
            .then(result => {
              chrome.storage.sync.set({ isGoldUpgraded: result.isSubscribed });
              sendResponse({ isSubscribed: result.isSubscribed });
            })
            .catch(error => {
              console.error("Error checking subscription:", error);
              sendResponse({ 
                isSubscribed: data.isGoldUpgraded || false,
                error: error.message
              });
            });
        } else {
          // Use cached subscription status
          sendResponse({ isSubscribed: data.isGoldUpgraded || false });
        }
      } else {
        sendResponse({ isSubscribed: false });
      }
    });
    return true;
  }
  
  // Handle Google sign-in request
  else if (request.action === 'signInWithGoogle') {
    if (!auth && !initializeFirebase()) {
      sendResponse({ 
        success: false, 
        error: "Firebase authentication not available" 
      });
      return true;
    }
    
    const googleProvider = new firebase.auth.GoogleAuthProvider();
    googleProvider.setCustomParameters({
      prompt: 'select_account'
    });
    
    auth.signInWithPopup(googleProvider)
      .then((result) => {
        // Store user data in Firestore
        const user = result.user;
        return db.collection('users').doc(user.uid).set({
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
          photoURL: user.photoURL,
          lastLogin: firebase.firestore.FieldValue.serverTimestamp()
        }, { merge: true })
        .then(() => {
          // Update Chrome storage with auth status
          chrome.storage.sync.set({
            isAuthenticated: true,
            userId: user.uid,
            userEmail: user.email,
            userName: user.displayName,
            userPhoto: user.photoURL
          });
          
          sendResponse({ 
            success: true, 
            user: {
              uid: user.uid,
              email: user.email,
              displayName: user.displayName,
              photoURL: user.photoURL
            }
          });
        });
      })
      .catch((error) => {
        console.error("Sign-in error:", error);
        sendResponse({ 
          success: false, 
          error: error.message || "Authentication failed" 
        });
      });
    
    return true;
  }
  
  // Handle sign-out request
  else if (request.action === 'signOut') {
    if (!auth && !initializeFirebase()) {
      sendResponse({ 
        success: false, 
        error: "Firebase authentication not available" 
      });
      return true;
    }
    
    auth.signOut()
      .then(() => {
        // Clear authentication data from Chrome storage
        chrome.storage.sync.set({
          isAuthenticated: false,
          userId: null,
          userEmail: null,
          userName: null,
          userPhoto: null,
          isGoldUpgraded: false
        });
        
        sendResponse({ success: true });
      })
      .catch((error) => {
        console.error("Sign-out error:", error);
        sendResponse({ 
          success: false, 
          error: error.message || "Sign-out failed" 
        });
      });
    
    return true;
  }
  
  // Handle subscription purchase request
  else if (request.action === 'startSubscription') {
    chrome.storage.sync.get(['isAuthenticated', 'userId'], (data) => {
      if (!data.isAuthenticated) {
        sendResponse({ 
          success: false, 
          error: "User not authenticated", 
          needsAuth: true 
        });
        return;
      }
      
      if (!functions) {
        if (!initializeFirebase() || !functions) {
          sendResponse({ 
            success: false, 
            error: "Firebase functions not available" 
          });
          return;
        }
      }
      
      // Get Chrome extension URL for success/cancel
      const extensionUrl = chrome.runtime.getURL('html/payment-result.html');
      
      // Call the Firebase function to create a checkout session
      const createCheckoutSession = functions.httpsCallable('createCheckoutSession');
      createCheckoutSession({
        priceId: 'skipit_temp_stripe_price_id', // Replace with ACTUAL SKIP IT. stripe ID
        successUrl: `${extensionUrl}?result=success`,
        cancelUrl: `${extensionUrl}?result=canceled`
      })
      .then((result) => {
        // Open the checkout URL in a new tab
        const sessionId = result.data.id;
        const checkoutUrl = `https://your-firebase-project.web.app/checkout.html?session=${sessionId}`;
        chrome.tabs.create({ url: checkoutUrl });
        sendResponse({ success: true });
      })
      .catch((error) => {
        console.error("Payment error:", error);
        sendResponse({ 
          success: false, 
          error: error.message 
        });
      });
    });
    return true;
  }
});

// Initialize Firebase when extension loads
initializeFirebase();

// Check authentication status on startup
chrome.runtime.onStartup.addListener(() => {
  // Check if need to prompt for authentication
  checkAuthOnStartup();
  
  // Check subscription status if already authenticated
  chrome.storage.sync.get(['isAuthenticated', 'userId'], (data) => {
    if (data.isAuthenticated && data.userId) {
      // Try to initialize Firebase if needed
      if (!db && initializeFirebase()) {
        // Check subscription status
        checkSubscriptionStatus(data.userId)
          .then(({ isSubscribed }) => {
            chrome.storage.sync.set({ isGoldUpgraded: isSubscribed });
            
            // Update badge to show subscription status
            if (isSubscribed) {
              chrome.action.setBadgeText({ text: "GOLD" });
              chrome.action.setBadgeBackgroundColor({ color: "#FFD700" });
            }
          })
          .catch(error => {
            console.error("Error checking subscription on startup:", error);
          });
      }
    }
  });
});